<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'admin') {
	header("Location:logout.php");
	exit; 
}

$errors = array();

if (isset($_POST['newuser']))
	{
		
		$fullname = trim(implode(' ', preg_split('/\s+/', $_POST['fullname'])));
		$useremail = trim($_POST['useremail']);
		$userpass = $_POST['userpass'];
		
		//..........
		if(empty($fullname)) {
			$errors[] = 'Please enter the Full English Name.'; 
		} else {
			if(!preg_match('/^[a-zA-Z ]{8,40}$/', $fullname)) {
				$errors[] = 'Name shall be between 8 - 40 char in English.';
			}
		}
		
		//.........
		if (!(filter_var($useremail, FILTER_VALIDATE_EMAIL))) {
			$errors[] = "Enter valid email address.";
		}
		else if(mysql_num_rows(mysql_query("select * from users where email = '".mysql_real_escape_string($useremail)."'")) > 0) {
			$errors[] = "Email already exist, Please change the email if the student is student another major.";
		}
		
		//..........
		if(empty($userpass)) {
			$errors[] = 'Please enter any password.'; 
		} else {
			if(!preg_match('/^[a-zA-Z0-9]{8,20}$/', $userpass)) {
				$errors[] = 'Password should be digits or alphabets of min 8 and max 20 char';
			}
		}
		
		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){
			
			$useremail = mysql_real_escape_string($useremail);
			$fullname = mysql_real_escape_string($fullname);
			$userpass = mysql_real_escape_string($userpass);
			
			$isenter = mysql_query("insert into users (email, full_name, password, profile) values ('$useremail', '$fullname', '$userpass', 'faculty')");
			if($isenter) {
				do_alert("Infomration Saved");
				nextpage("adminpanel.php");
				exit;
			} else {
				do_alert("There is some issue in saving the information, contact developer");
				nextpage("adminpanel.php");
				exit;
			}
		}
			
			
	}
//if(isset($_POST['septreg']) == 1) 
if ( isset($_POST['septreg']) == 1 || isset($_POST['janreg'])== 2 ) {
	
	if($_POST['septreg'] == 1) {
		$newbatch = 1; 
	} else if($_POST['janreg'] == 2) {
		$newbatch = 2;
	} else {
		header("Location: index.php");
		exit;
	}

	if($newbatch == 1){
		$newbatch = 'Batch'.date(Y). '- September '.date(Y);
	} else if($newbatch == 2) {
		$newbatch = 'Batch'.date(Y). '- Jan '.(date(Y) + 1);
	} else 
	{
		header("Location: index.php");
		exit;
	}
	
	$userdataquery = mysql_query("select * from batch_year where batch_name = '$newbatch'");
	
	if(mysql_num_rows($userdataquery) == 1) {
		$errors[] = "Record already exist";
	} 
	
	$l1d = $_POST["l1d"];
	$l1m = $_POST["l1m"];
	$l1y = $_POST["l1y"];
	if(!empty($l1d) && !empty($l1m) && !empty($l1y)) {
	$level1_exam = $l1d."/".$l1m."/".$l1y;
	}
	
	$l2d = $_POST["l2d"];
	$l2m = $_POST["l2m"];
	$l2y = $_POST["l2y"];
	if(!empty($l2d) && !empty($l2m) && !empty($l2y)) {
	$level2_exam = $l2d."/".$l2m."/".$l2y;
	}
	
	$l3d = $_POST["l3d"];
	$l3m = $_POST["l3m"];
	$l3y = $_POST["l3y"];
	if(!empty($l3d) && !empty($l3m) && !empty($l3y)) {
	$level3_exam = $l3d."/".$l3m."/".$l3y;
	}
	
	$l4d = $_POST["l4d"];
	$l4m = $_POST["l4m"];
	$l4y = $_POST["l4y"];
	if(!empty($l4d) && !empty($l4m) && !empty($l4y)) {
	$level4_exam = $l4d."/".$l4m."/".$l4y;
	}
	
	$l5d = $_POST["l5d"];
	$l5m = $_POST["l5m"];
	$l5y = $_POST["l5y"];
	if(!empty($l5d) && !empty($l5m) && !empty($l5y)) {
	$level5_exam = $l5d."/".$l5m."/".$l5y;
	}
	
	if(empty($level1_exam) || empty($level2_exam) || empty($level3_exam) || empty($level4_exam) || empty($level5_exam) ){
		$errors[] = 'You have to select the date of the start for all levels in hijri. Select any date if you dont have the level 5 for this batch';
	}
	
	$errors = array_filter($errors, 'strlen');
	if(empty($errors)){
		if(mysql_num_rows($userdataquery) == 0) {
			$batch_year_id_query = mysql_fetch_array(mysql_query("SELECT batch_year_id FROM batch_year ORDER BY batch_year_id DESC"));
			$batch_year_id = $batch_year_id_query[0] + 1;
			$level1_exam = mysql_real_escape_string($level1_exam);
			$level2_exam = mysql_real_escape_string($level2_exam);
			$level3_exam = mysql_real_escape_string($level3_exam);
			$level4_exam = mysql_real_escape_string($level4_exam);
			$level5_exam = mysql_real_escape_string($level5_exam);
			
			$isenter = mysql_query("INSERT INTO batch_year (batch_year_id, batch_name, level1_exam, level2_exam, level3_exam, level4_exam, level5_exam) values ('$batch_year_id', '$newbatch', '$level1_exam', '$level2_exam', '$level3_exam', '$level4_exam', '$level5_exam')");
			if($isenter) {
				do_alert("New batch has been added");
				nextpage("adminpanel.php?batch=yes");
				exit;
			} else {
				do_alert("There is some issue in saving the information, contact developer");
				nextpage("adminpanel.php");
				exit;
			}
		}
	}
}

if(!empty($_GET['rpass'])) {
	$table_id = mysql_real_escape_string($_GET['rpass']);
	$userdataquery = mysql_query("select * from users where table_id = '$table_id'");
	
	$userdata = mysql_fetch_assoc($userdataquery);
	if($userdata['profile'] != 'faculty') {
		header("Location: index.php");
		exit;
	}
	
	if(mysql_num_rows($userdataquery) != 1) {
		do_alert("Data doesn't exist");
		nextpage("adminpanel.php");
		exit;
	} else if(mysql_num_rows($userdataquery) == 1) {
			$isenter = mysql_query("update users set password = '123456' where table_id = '$table_id'");
			if($isenter) {
				do_alert("Account reset, the new password is 123456");
				nextpage("adminpanel.php");
				exit;
			} else {
				do_alert("There is some issue in saving the information, contact developer");
				nextpage("adminpanel.php");
				exit;
			}
	}
}

if(!empty($_GET['delacc'])) {
	
	$table_id = mysql_real_escape_string($_GET['delacc']);
	$userdataquery = mysql_query("select * from users where table_id = '$table_id'");
	
	$userdata = mysql_fetch_assoc($userdataquery);
	if($userdata['profile'] != 'faculty') {
		header("Location: index.php");
		exit;
	}
	
	if(mysql_num_rows($userdataquery) != 1) {
		do_alert("Data doesn't exist");
		nextpage("adminpanel.php");
		exit;
	} else if(mysql_num_rows($userdataquery) == 1) {
			$isenter = mysql_query("delete from users where table_id = '$table_id'");
			if($isenter) {
				do_alert("Account has been deleted");
				nextpage("adminpanel.php");
				exit;
			} else {
				do_alert("There is some issue in saving the information, contact developer");
				nextpage("adminpanel.php");
				exit;
			}
	}
}

if(!empty($_GET['chmar'])) {
	
	$table_id = mysql_real_escape_string($_GET['chmar']);
	$userdataquery = mysql_query("select * from users where table_id = '$table_id'");
	
	$userdata = mysql_fetch_assoc($userdataquery);
	if($userdata['profile'] != 'faculty') {
		header("Location: index.php");
		exit;
	}
	
	if($userdata['del_marks'] == 'Yes') {
		$newrules = 'No';
	} else if($userdata['del_marks'] == 'No') {
		$newrules = 'Yes';
	}
	
	if(mysql_num_rows($userdataquery) != 1) {
		do_alert("Data doesn't exist");
		nextpage("adminpanel.php");
		exit;
	} else if(mysql_num_rows($userdataquery) == 1) {
			$isenter = mysql_query("update users set del_marks = '$newrules' where table_id = '$table_id'");
			if($isenter) {
				do_alert("New permission has been alloted");
				nextpage("adminpanel.php?viewuser=yes");
				exit;
			} else {
				do_alert("There is some issue in saving the information, contact developer");
				nextpage("adminpanel.php");
				exit;
			}
	}
}

if(!empty($_GET['apcurr'])) {
	
	$curr_id = mysql_real_escape_string($_GET['apcurr']);
	$userdataquery = mysql_query("select * from curr_detail where curr_id = '$curr_id' and is_user_mark_entry = 'Yes' and is_complete_data = 'No'");
	
	if(mysql_num_rows($userdataquery) != 1) {
		do_alert("Data doesn't exist");
		nextpage("adminpanel.php");
		exit;
	} else if(mysql_num_rows($userdataquery) == 1) {
			$isenter = mysql_query("update curr_detail set is_complete_data = 'Yes' where curr_id = '$curr_id'");
			if($isenter) {
				do_alert("Curriculum has been approved");
				nextpage("adminpanel.php?pending=yes");
				exit;
			} else {
				do_alert("There is some issue in saving the information, contact developer");
				nextpage("adminpanel.php");
				exit;
			}
	}
}

if(!empty($_GET['descurr'])) {
	
	$curr_id = mysql_real_escape_string($_GET['descurr']);
	$userdataquery = mysql_query("select * from curr_detail where curr_id = '$curr_id' and is_complete_data = 'Yes'");
	
	if(mysql_num_rows($userdataquery) != 1) {
		do_alert("Data doesn't exist");
		nextpage("adminpanel.php");
		exit;
	} 
	
	$currdata = mysql_fetch_assoc($userdataquery);
	if($currdata['is_open_to_register'] == 'Yes') {
		$newrules = 'No';
	} else if($currdata['is_open_to_register'] == 'No') {
		$newrules = 'Yes';
	}
	
	if(mysql_num_rows($userdataquery) == 1) {
			$isenter = mysql_query("update curr_detail set is_open_to_register = '$newrules' where curr_id = '$curr_id'");
			if($isenter) {
				do_alert("Student registration information has been saved");
				nextpage("adminpanel.php?pending=yes");
				exit;
			} else {
				do_alert("There is some issue in saving the information, contact developer");
				nextpage("adminpanel.php");
				exit;
			}
	}
}

if(!empty($_GET['desbat'])) {
	
	$batch_year_id = mysql_real_escape_string($_GET['desbat']);
	$userdataquery = mysql_query("select * from batch_year where batch_year_id = '$batch_year_id'");
	
	if(mysql_num_rows($userdataquery) != 1) {
		do_alert("Data doesn't exist");
		nextpage("adminpanel.php");
		exit;
	} 
	
	$currdata = mysql_fetch_assoc($userdataquery);
	if($currdata['is_open_to_register'] == 'Yes') {
		$newrules = 'No';
	} else if($currdata['is_open_to_register'] == 'No') {
		$newrules = 'Yes';
	}
	
	if(mysql_num_rows($userdataquery) == 1) {
			$isenter = mysql_query("update batch_year set is_open_to_register = '$newrules' where batch_year_id = '$batch_year_id'");
			if($isenter) {
				do_alert("Student registration information has been saved");
				nextpage("adminpanel.php?batch=yes");
				exit;
			} else {
				do_alert("There is some issue in saving the information, contact developer");
				nextpage("adminpanel.php");
				exit;
			}
	}
}

if( isset($_GET['batch']) == 'yes' && !empty($_GET['edit'])) {
	$batch_year_id = mysql_real_escape_string($_GET['edit']);
	$userdataquery = mysql_query("select * from batch_year where batch_year_id = '$batch_year_id'");
	
	if(mysql_num_rows($userdataquery) != 1) {
		do_alert("Data doesn't exist");
		nextpage("adminpanel.php?batch=yes");
		exit;
	} else {
		$editconfirm = 'yes';
		$editbatch = mysql_fetch_assoc($userdataquery);
	}
	
	if ( isset($_POST['editbatch'])) {
	
	$l1d = $_POST["l1d"];
	$l1m = $_POST["l1m"];
	$l1y = $_POST["l1y"];
	if(!empty($l1d) && !empty($l1m) && !empty($l1y)) {
	$level1_exam = $l1d."/".$l1m."/".$l1y;
	}
	
	$l2d = $_POST["l2d"];
	$l2m = $_POST["l2m"];
	$l2y = $_POST["l2y"];
	if(!empty($l2d) && !empty($l2m) && !empty($l2y)) {
	$level2_exam = $l2d."/".$l2m."/".$l2y;
	}
	
	$l3d = $_POST["l3d"];
	$l3m = $_POST["l3m"];
	$l3y = $_POST["l3y"];
	if(!empty($l3d) && !empty($l3m) && !empty($l3y)) {
	$level3_exam = $l3d."/".$l3m."/".$l3y;
	}
	
	$l4d = $_POST["l4d"];
	$l4m = $_POST["l4m"];
	$l4y = $_POST["l4y"];
	if(!empty($l4d) && !empty($l4m) && !empty($l4y)) {
	$level4_exam = $l4d."/".$l4m."/".$l4y;
	}
	
	$l5d = $_POST["l5d"];
	$l5m = $_POST["l5m"];
	$l5y = $_POST["l5y"];
	if(!empty($l5d) && !empty($l5m) && !empty($l5y)) {
	$level5_exam = $l5d."/".$l5m."/".$l5y;
	}
	
	if(empty($level1_exam) || empty($level2_exam) || empty($level3_exam) || empty($level4_exam) || empty($level5_exam) ){
		$errors[] = 'You have to select the date of the start for all levels in Hijri. Select any date if you dont have the level 5 for this batch';
	}
	
	$errors = array_filter($errors, 'strlen');
	if(empty($errors)){
			$level1_exam = mysql_real_escape_string($level1_exam);
			$level2_exam = mysql_real_escape_string($level2_exam);
			$level3_exam = mysql_real_escape_string($level3_exam);
			$level4_exam = mysql_real_escape_string($level4_exam);
			$level5_exam = mysql_real_escape_string($level5_exam);
			
			$isenter = mysql_query("update batch_year set
			level1_exam = '$level1_exam', 
			level2_exam = '$level2_exam', 
			level3_exam = '$level3_exam', 
			level4_exam = '$level4_exam', 
			level5_exam = '$level5_exam' where batch_year_id = '$batch_year_id'");
			
			if($isenter) {
				do_alert("Level Starts dates has been edited");
				nextpage("adminpanel.php?batch=yes");
				exit;
			} else {
				do_alert("There is some issue in saving the information, contact developer");
				nextpage("adminpanel.php");
				exit;
			}
	}
	}
}

if (isset($_POST['changemypass'])) {
	
	$oldpass = mysql_real_escape_string($_POST['oldpass']);
	$newpass = mysql_real_escape_string($_POST['newpass']);
	$connewpass = mysql_real_escape_string($_POST['connewpass']);
	
		//..........
		if(mysql_num_rows(mysql_query("select * from users where profile = 'admin' and password = '$oldpass'")) != 1) {
			$errors[] = 'Current password is wrong'; 
		}
				
		//..........
		if(empty($newpass)) {
			$errors[] = 'Please enter new password.'; 
		} else {
			if(!preg_match('/^[a-zA-Z0-9]{8,20}$/', $newpass)) {
				$errors[] = 'New Password should be digits or alphabets of min 8 and max 20 char';
			}
		}
				
		//..........
		if($newpass != $connewpass) {
			$errors[] = 'New password and Confirm Password should be same';
		}
		
		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){ 
			$isenter = mysql_query("update users set password = '$newpass' where profile = 'admin'");
			if($isenter) {
				do_alert("Infomration Saved");
				nextpage("adminpanel.php");
				exit;
			} else {
				do_alert("There is some issue in saving the information, contact developer");
				nextpage("adminpanel.php");
				exit;
			}
		} else {
			$passactive = 'Yes';
		}

}

if (isset($_POST['emailchange']))
	{
		
		$adminemail = trim($_POST['adminemail']);

		//.........
		if (!(filter_var($adminemail, FILTER_VALIDATE_EMAIL))) {
			$errors[] = "Enter valid email address.";
		}
		else if(mysql_num_rows(mysql_query("select * from users where email = '".mysql_real_escape_string($adminemail)."'")) > 0) {
			$errors[] = "Email already exist, Please try another";
		}

		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){
			
			$adminemail = mysql_real_escape_string($adminemail);
			
			$isenter = mysql_query("update users set email = '$adminemail' where profile = 'admin'");
			if($isenter) {
				do_alert("Infomration Saved");
				nextpage("adminpanel.php");
				exit;
			} else {
				do_alert("There is some issue in saving the information, contact developer");
				nextpage("adminpanel.php");
				exit;
			}
		} else {
			$emailactive = 'Yes';
		}
			
			
	}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>

	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<div style="margin-bottom:44px;">
<nav class="navbar-inverse navbar-default navbar-fixed-top"  role="navigation" style="background-color:#16212D;  border-bottom:2px solid #fff;  height:40px;  color:#fff;">

        <div class="width1200">
            <div class="navbar-header" style="padding-left:10px;">
            <h4>THIEP Students Record Book</h4>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-ex1-collapse" style="border:0; background-color:#16212D; ">
            <!-- This is to give the spacing above the menu -->
                <ul class="nav navbar-nav">
                    <li class="dropdown">
							 <a href="#" class="dropdown-toggle" data-toggle="dropdown">Options<strong class="caret"></strong></a>
							<ul class="dropdown-menu">
                                <li>
									<a href="logout.php">Logout</a>
								</li>
							</ul>
						</li>
                </ul>

            </div>

            <!-- /.navbar-collapse -->
        </div>

        <!-- /.container -->
    </nav>
</div>
<!-- All Bottom of the Header -->   
<div class="width1200" style="margin-top:60px;">
<div class="row" style="margin-bottom:30px;">
				
                <div class="col-xs-4" style="margin:0; padding:0; margin:0 auto;">
                <div style="margin:0 auto; background-color:#fff; padding:20px; border:2px solid #CCCCCC;">
                
                <p><a href="adminpanel.php?newuser=yes">Make New Faculty</a></p><hr />
                <p><a href="adminpanel.php?viewuser=yes">View Faculty</a></p><hr />
                                <p><a href="viewlog.php?viewuser=yes">View Log</a></p><hr />
                <p><a href="adminpanel.php?pending=yes">Curriculum Actions</a></p><hr />
                <p><a href="adminpanel.php?batch=yes">Batch Actions</a></p><hr />
                <p><a href="adminpanel.php?mypaschg=yes">Change Password</a></p><hr />
                <p><a href="adminpanel.php?myemlchg=yes">Change Email</a></p>
               
                </div>
                </div>
               
                <div class="col-xs-8" style="margin:0; padding:0; margin:0 auto;">
                <div style="margin:0 auto; background-color:#fff; padding:20px; border:2px solid #CCCCCC;">
				
                
                
                  <?php 
				if($errors)
				{
					echo '<div style="color:red; font-weight:normal;">';
				foreach ($errors as $msg) 
				{ ?>
                    <?php echo "$msg<br />\n"; ?>
				<?php }
					echo '</div>';
				}
				?>

                     <?php 
					 	  if( isset($_GET['viewuser']) == 'yes' ) { ?>
                    <p class="formtitle" style="margin-bottom:20px;">View Faculty</p>
                    
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="viewfaculty">
				
                
                <?php
				$allusersquery = mysql_query("select * from users where profile = 'faculty'");
				while($allusers = mysql_fetch_assoc($allusersquery)) {
					echo '<h4>'.$allusers['full_name'].'</h4>';
                	echo '<h5>'.$allusers['email'].', <a href="adminpanel.php?rpass='.$allusers['table_id'].'">Reset Password</a>, <a href="adminpanel.php?delacc='.$allusers['table_id'].'">Delete Account</a></h5>';
					if($allusers['del_marks'] == 'Yes') {
						echo '<h5>'.'<b style="color:red;">Status:</b> Currently user can delete marks. <a href="adminpanel.php?chmar='.$allusers['table_id'].'">Remove Permission to change Marks</a></h5><hr />';
					} else {
						echo '<h5>'.'<b>Status:</b> User cannot modify marks. <a href="adminpanel.php?chmar='.$allusers['table_id'].'">Mark user to change marks</a></h5><hr />'; 
					}
					
				}
				?>

			</form>
            		<?php } 
					 else if( isset($_GET['pending']) == 'yes' ) { ?>
                    <p class="formtitle" style="margin-bottom:20px;">Curriculum Actions</p>
                    
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="pendingtaskform">
				
                <?php 
				$allcurrquery = mysql_query("select * from curr_detail where is_user_mark_entry = 'Yes' and is_complete_data = 'No'");
				if(mysql_num_rows($allcurrquery) > 0) {
					echo '<div style="background-color:#FCC; padding:10px;">';
					while($allcurr = mysql_fetch_assoc($allcurrquery)) {
					echo '<h4>Curriculum Waiting for Approval</h4>';
					echo '<h5> Name: '.$allcurr['curr_name'].'</h5>';
					echo '<h5> Levels: '.$allcurr['levels'].'</h5>'; ?>
                	<h5><a onclick="return confirm('Are you sure you want to continue')"  href="adminpanel.php?apcurr=<?php echo $allcurr['curr_id']; ?>">Approve Curriculum</a><hr> <?php
					echo '<b style="color:red;">Note: </b>, Before approval make sure you took a print of the curriculum and verify all the courses and credit hours. Once approve, cannot modify or delete the curriculum.';
				}
					echo '</div>';
				}
				?>
                
                <?php 
				$allcurrquery = mysql_query("select * from curr_detail where is_complete_data = 'Yes' ORDER BY table_id DESC");
				if(mysql_num_rows($allcurrquery) > 0) {
					while($allcurr = mysql_fetch_assoc($allcurrquery)) {
					
						echo '<h5> Curriculum Name: '.$allcurr['curr_name'].'</h5>';
						echo '<h5> Levels: '.$allcurr['levels'].'</h5>';
						if($allcurr['is_open_to_register'] == 'Yes') {
							echo '<h5> Status: Currently Open to Register New Student</h5>';
							echo '<h5><a href="adminpanel.php?descurr='.$allcurr['curr_id'].'">Stop Registration</a><hr>';
						} else {
							echo '<h5> Status: Currently Close to Register New Student</h5>';
							echo '<h5><a href="adminpanel.php?descurr='.$allcurr['curr_id'].'">Start Registration</a><hr>';
						}

					}
				}
				?>

			</form>
            		<?php } 
					 else if( isset($_GET['batch']) == 'yes' ) { ?>
                    
					 <?php 
					
					 $is_batch_jan = 'Jan '.(date('Y') + 1);
					 $is_batch_sep = 'Sep '.(date('Y') + 1);
					 if((mysql_num_rows(mysql_query("select * from batch_year where batch_name = '$is_batch_sep' or batch_name = '$is_batch_jan' ")) == 0) || (mysql_num_rows(mysql_query("select * from batch_year where batch_name = '$is_batch_sep' or batch_name = '$is_batch_jan' ")) == 1)) { ?>
                     <p class="formtitle" style="margin-bottom:20px; clear:both;">New Batch Available</p>
					 <?php }
					 $checkbatch = mysql_query("select * from batch_year where batch_name = '$is_batch_sep'");
					 $batchinfo = mysql_fetch_assoc($checkbatch);
					  
					  if(mysql_num_rows($checkbatch)  != 1) { 
					  ?>
                      <div class="col-xs-6" style="margin:0; padding:2px;">
                      <div class="padding10" style="background-color:#e5e5e5; margin-bottom:10px;">
                      <p class="formtitle"><?php echo $is_batch_sep ?></p>
                       <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])).'?batch=yes'; ?>" method="post" name="septbatch">
    	 <div class="form-group">
	<label for="fullname">Date of Level 1 Start</label><br />
                     
      <select class="form-control" name="l1d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l1d)){?>
      <option value="<?php echo $l1d; ?>" selected="selected"><?php echo $l1d;?></option>
      <?php } else if(!empty($batchinfo['level1_exam'])) { 
	  $l1all = explode('/', $batchinfo['level1_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l1all[0]; ?>"><?php echo  $l1all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l1m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l1m)){?>
      <option value="<?php echo $l1m; ?>" selected="selected"><?php echo $l1m;?></option>
      <?php } else if(!empty($batchinfo['level1_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l1all[1]; ?>"><?php echo  $l1all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l1y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l1y)){?>
        <option value="<?php echo $l1y; ?>" selected="selected"><?php echo $l1y;?></option>
        <?php } else if(!empty($batchinfo['level1_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l1all[2]; ?>"><?php echo  $l1all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
         <div class="form-group">
	<label for="fullname">Date of Level 2 Start</label><br />
                     
      <select class="form-control" name="l2d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l2d)){?>
      <option value="<?php echo $l2d; ?>" selected="selected"><?php echo $l2d;?></option>
      <?php } else if(!empty($batchinfo['level2_exam'])) { 
	  $l2all = explode('/', $batchinfo['level2_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l2all[0]; ?>"><?php echo  $l2all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l2m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l2m)){?>
      <option value="<?php echo $l2m; ?>" selected="selected"><?php echo $l2m;?></option>
      <?php } else if(!empty($batchinfo['level2_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l2all[1]; ?>"><?php echo  $l2all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l2y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l2y)){?>
        <option value="<?php echo $l2y; ?>" selected="selected"><?php echo $l2y;?></option>
        <?php } else if(!empty($batchinfo['level2_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l2all[2]; ?>"><?php echo  $l2all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
         <div class="form-group">
	<label for="fullname">Date of Level 3 Start</label><br />
                     
      <select class="form-control" name="l3d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l3d)){?>
      <option value="<?php echo $l3d; ?>" selected="selected"><?php echo $l3d;?></option>
      <?php } else if(!empty($batchinfo['level3_exam'])) { 
	  $l3all = explode('/', $batchinfo['level3_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l3all[0]; ?>"><?php echo  $l3all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l3m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l3m)){?>
      <option value="<?php echo $l3m; ?>" selected="selected"><?php echo $l3m;?></option>
      <?php } else if(!empty($batchinfo['level3_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l3all[1]; ?>"><?php echo  $l3all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l3y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l3y)){?>
        <option value="<?php echo $l3y; ?>" selected="selected"><?php echo $l3y;?></option>
        <?php } else if(!empty($batchinfo['level3_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l3all[2]; ?>"><?php echo  $l3all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
		 <div class="form-group">
	<label for="fullname">Date of Level 4 Start</label><br />
                     
      <select class="form-control" name="l4d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l4d)){?>
      <option value="<?php echo $l4d; ?>" selected="selected"><?php echo $l4d;?></option>
      <?php } else if(!empty($batchinfo['level4_exam'])) { 
	  $l4all = explode('/', $batchinfo['level4_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l4all[0]; ?>"><?php echo  $l4all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l4m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l4m)){?>
      <option value="<?php echo $l4m; ?>" selected="selected"><?php echo $l4m;?></option>
      <?php } else if(!empty($batchinfo['level4_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l4all[1]; ?>"><?php echo  $l4all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l4y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l4y)){?>
        <option value="<?php echo $l4y; ?>" selected="selected"><?php echo $l4y;?></option>
        <?php } else if(!empty($batchinfo['level4_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l4all[2]; ?>"><?php echo  $l4all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
		 <div class="form-group">
	<label for="fullname">Date of Level 5 Start</label><br />
                     
      <select class="form-control" name="l5d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l5d)){?>
      <option value="<?php echo $l5d; ?>" selected="selected"><?php echo $l5d;?></option>
      <?php } else if(!empty($batchinfo['level5_exam'])) { 
	  $l5all = explode('/', $batchinfo['level5_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l5all[0]; ?>"><?php echo  $l5all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l5m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l5m)){?>
      <option value="<?php echo $l5m; ?>" selected="selected"><?php echo $l5m;?></option>
      <?php } else if(!empty($batchinfo['level5_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l5all[1]; ?>"><?php echo  $l5all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l5y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l5y)){?>
        <option value="<?php echo $l5y; ?>" selected="selected"><?php echo $l5y;?></option>
        <?php } else if(!empty($batchinfo['level5_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l5all[2]; ?>"><?php echo  $l5all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
<button type="submit" class="btn btn-default success" value="1" name="septreg"><?php echo 'Register '.$is_batch_sep.' Batch'; ?></button>
                     </form>
                     </div>
                     </div>
                     
                     <?php } ?>

                      <?php 
					 $checkbatch = mysql_query("select * from batch_year where batch_name = '$is_batch_jan'");
					 $batchinfo = mysql_fetch_assoc($checkbatch);
					  if(mysql_num_rows($checkbatch)  != 1) { 
					  ?>
                      
                      <div class="col-xs-6" style="margin:0; padding:2px;">
                      <div class="padding10" style="background-color:#e5e5e5; margin-bottom:10px;">
                      <p class="formtitle"><?php echo $is_batch_jan ?></p>
                       <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])).'?batch=yes'; ?>" method="post" name="janbatch">
    	 <div class="form-group">
	<label for="fullname">Date of Level 1 Start</label><br />
                     
      <select class="form-control" name="l1d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l1d)){?>
      <option value="<?php echo $l1d; ?>" selected="selected"><?php echo $l1d;?></option>
      <?php } else if(!empty($batchinfo['level1_exam'])) { 
	  $l1all = explode('/', $batchinfo['level1_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l1all[0]; ?>"><?php echo  $l1all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l1m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l1m)){?>
      <option value="<?php echo $l1m; ?>" selected="selected"><?php echo $l1m;?></option>
      <?php } else if(!empty($batchinfo['level1_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l1all[1]; ?>"><?php echo  $l1all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l1y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l1y)){?>
        <option value="<?php echo $l1y; ?>" selected="selected"><?php echo $l1y;?></option>
        <?php } else if(!empty($batchinfo['level1_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l1all[2]; ?>"><?php echo  $l1all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
         <div class="form-group">
	<label for="fullname">Date of Level 2 Start</label><br />
                     
      <select class="form-control" name="l2d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l2d)){?>
      <option value="<?php echo $l2d; ?>" selected="selected"><?php echo $l2d;?></option>
      <?php } else if(!empty($batchinfo['level2_exam'])) { 
	  $l2all = explode('/', $batchinfo['level2_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l2all[0]; ?>"><?php echo  $l2all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l2m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l2m)){?>
      <option value="<?php echo $l2m; ?>" selected="selected"><?php echo $l2m;?></option>
      <?php } else if(!empty($batchinfo['level2_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l2all[1]; ?>"><?php echo  $l2all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l2y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l2y)){?>
        <option value="<?php echo $l2y; ?>" selected="selected"><?php echo $l2y;?></option>
        <?php } else if(!empty($batchinfo['level2_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l2all[2]; ?>"><?php echo  $l2all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
         <div class="form-group">
	<label for="fullname">Date of Level 3 Start</label><br />
                     
      <select class="form-control" name="l3d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l3d)){?>
      <option value="<?php echo $l3d; ?>" selected="selected"><?php echo $l3d;?></option>
      <?php } else if(!empty($batchinfo['level3_exam'])) { 
	  $l3all = explode('/', $batchinfo['level3_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l3all[0]; ?>"><?php echo  $l3all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l3m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l3m)){?>
      <option value="<?php echo $l3m; ?>" selected="selected"><?php echo $l3m;?></option>
      <?php } else if(!empty($batchinfo['level3_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l3all[1]; ?>"><?php echo  $l3all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l3y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l3y)){?>
        <option value="<?php echo $l3y; ?>" selected="selected"><?php echo $l3y;?></option>
        <?php } else if(!empty($batchinfo['level3_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l3all[2]; ?>"><?php echo  $l3all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
		 <div class="form-group">
	<label for="fullname">Date of Level 4 Start</label><br />
                     
      <select class="form-control" name="l4d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l4d)){?>
      <option value="<?php echo $l4d; ?>" selected="selected"><?php echo $l4d;?></option>
      <?php } else if(!empty($batchinfo['level4_exam'])) { 
	  $l4all = explode('/', $batchinfo['level4_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l4all[0]; ?>"><?php echo  $l4all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l4m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l4m)){?>
      <option value="<?php echo $l4m; ?>" selected="selected"><?php echo $l4m;?></option>
      <?php } else if(!empty($batchinfo['level4_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l4all[1]; ?>"><?php echo  $l4all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l4y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l4y)){?>
        <option value="<?php echo $l4y; ?>" selected="selected"><?php echo $l4y;?></option>
        <?php } else if(!empty($batchinfo['level4_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l4all[2]; ?>"><?php echo  $l4all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
		 <div class="form-group">
	<label for="fullname">Date of Level 5 Start</label><br />
                     
      <select class="form-control" name="l5d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l5d)){?>
      <option value="<?php echo $l5d; ?>" selected="selected"><?php echo $l5d;?></option>
      <?php } else if(!empty($batchinfo['level5_exam'])) { 
	  $l5all = explode('/', $batchinfo['level5_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l5all[0]; ?>"><?php echo  $l5all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l5m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l5m)){?>
      <option value="<?php echo $l5m; ?>" selected="selected"><?php echo $l5m;?></option>
      <?php } else if(!empty($batchinfo['level5_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l5all[1]; ?>"><?php echo  $l5all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l5y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l5y)){?>
        <option value="<?php echo $l5y; ?>" selected="selected"><?php echo $l5y;?></option>
        <?php } else if(!empty($batchinfo['level5_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l5all[2]; ?>"><?php echo  $l5all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
<button type="submit" class="btn btn-default success" value="2" name="janreg"><?php echo 'Register '.$is_batch_jan.' Batch'; ?></button>
                     </form>
                     </div>
                     </div>
                     
                     <?php } ?>
                     
				<?php if( isset($editconfirm) == 'yes') { ?>
                
                <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])).'?batch=yes&edit='.$_GET['edit'];; ?>" method="post" name="batchedit">
         <p class="formtitle" style="margin-bottom:20px; clear:both;"><?php echo '<b>Editing '.$editbatch['batch_name'].' Level Start Record</b>'; ?></p>
    	 <div class="form-group">
	<label for="fullname">Date of Level 1 Start</label><br />
                     
      <select class="form-control" name="l1d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l1d)){?>
      <option value="<?php echo $l1d; ?>" selected="selected"><?php echo $l1d;?></option>
      <?php } else if(!empty($editbatch['level1_exam'])) { 
	  $l1all = explode('/', $editbatch['level1_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l1all[0]; ?>"><?php echo  $l1all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l1m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l1m)){?>
      <option value="<?php echo $l1m; ?>" selected="selected"><?php echo $l1m;?></option>
      <?php } else if(!empty($editbatch['level1_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l1all[1]; ?>"><?php echo  $l1all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l1y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l1y)){?>
        <option value="<?php echo $l1y; ?>" selected="selected"><?php echo $l1y;?></option>
        <?php } else if(!empty($editbatch['level1_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l1all[2]; ?>"><?php echo  $l1all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
         <div class="form-group">
	<label for="fullname">Date of Level 2 Start</label><br />
                     
      <select class="form-control" name="l2d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l2d)){?>
      <option value="<?php echo $l2d; ?>" selected="selected"><?php echo $l2d;?></option>
      <?php } else if(!empty($editbatch['level2_exam'])) { 
	  $l2all = explode('/', $editbatch['level2_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l2all[0]; ?>"><?php echo  $l2all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l2m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l2m)){?>
      <option value="<?php echo $l2m; ?>" selected="selected"><?php echo $l2m;?></option>
      <?php } else if(!empty($editbatch['level2_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l2all[1]; ?>"><?php echo  $l2all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l2y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l2y)){?>
        <option value="<?php echo $l2y; ?>" selected="selected"><?php echo $l2y;?></option>
        <?php } else if(!empty($editbatch['level2_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l2all[2]; ?>"><?php echo  $l2all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }

     ?>
      </select>
					 </div>
         <div class="form-group">
	<label for="fullname">Date of Level 3 Start</label><br />
                     
      <select class="form-control" name="l3d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l3d)){?>
      <option value="<?php echo $l3d; ?>" selected="selected"><?php echo $l3d;?></option>
      <?php } else if(!empty($editbatch['level3_exam'])) { 
	  $l3all = explode('/', $editbatch['level3_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l3all[0]; ?>"><?php echo  $l3all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l3m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l3m)){?>
      <option value="<?php echo $l3m; ?>" selected="selected"><?php echo $l3m;?></option>
      <?php } else if(!empty($editbatch['level3_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l3all[1]; ?>"><?php echo  $l3all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l3y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l3y)){?>
        <option value="<?php echo $l3y; ?>" selected="selected"><?php echo $l3y;?></option>
        <?php } else if(!empty($editbatch['level3_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l3all[2]; ?>"><?php echo  $l3all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
		 <div class="form-group">
	<label for="fullname">Date of Level 4 Start</label><br />
                     
      <select class="form-control" name="l4d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l4d)){?>
      <option value="<?php echo $l4d; ?>" selected="selected"><?php echo $l4d;?></option>
      <?php } else if(!empty($editbatch['level4_exam'])) { 
	  $l4all = explode('/', $editbatch['level4_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l4all[0]; ?>"><?php echo  $l4all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l4m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l4m)){?>
      <option value="<?php echo $l4m; ?>" selected="selected"><?php echo $l4m;?></option>
      <?php } else if(!empty($editbatch['level4_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l4all[1]; ?>"><?php echo  $l4all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l4y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l4y)){?>
        <option value="<?php echo $l4y; ?>" selected="selected"><?php echo $l4y;?></option>
        <?php } else if(!empty($editbatch['level4_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l4all[2]; ?>"><?php echo  $l4all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
		 <div class="form-group">
	<label for="fullname">Date of Level 5 Start</label><br />
                     
      <select class="form-control" name="l5d" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l5d)){?>
      <option value="<?php echo $l5d; ?>" selected="selected"><?php echo $l5d;?></option>
      <?php } else if(!empty($editbatch['level5_exam'])) { 
	  $l5all = explode('/', $editbatch['level5_exam']);
	  ?>
      <option selected="selected" value="<?php echo $l5all[0]; ?>"><?php echo  $l5all[0]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Date</option>
      <?php }
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l5m" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($l5m)){?>
      <option value="<?php echo $l5m; ?>" selected="selected"><?php echo $l5m;?></option>
      <?php } else if(!empty($editbatch['level5_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l5all[1]; ?>"><?php echo  $l5all[1]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Month</option>
      <?php }
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="l5y"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($l5y)){?>
        <option value="<?php echo $l5y; ?>" selected="selected"><?php echo $l5y;?></option>
        <?php } else if(!empty($editbatch['level5_exam'])) { 
	  ?>
      <option selected="selected" value="<?php echo $l5all[2]; ?>"><?php echo  $l5all[2]; ?></option>
      <?php } else { ?>
      <option selected="selected" value="">Year</option>
      <?php }
	for ($i=1480; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
                     
<button type="submit" class="btn btn-default success" value="2" name="editbatch"><?php echo 'Edit Level Start Dates'; ?></button>
                    <br /><br />
                     </form>
                <?php } ?>
                
              <p class="formtitle" style="margin-bottom:20px; clear:both;">Batch Actions</p>
                
                <?php 
				$allcurrquery = mysql_query("select * from batch_year ORDER BY table_id DESC");
				if(mysql_num_rows($allcurrquery) > 0) {
					while($allcurr = mysql_fetch_assoc($allcurrquery)) { 
					
                        echo '<h5> <b>Batch Name: '.$allcurr['batch_name'].'</b></h5>';
						if($allcurr['is_open_to_register'] == 'Yes') {
							echo '<h5> Status: Currently Open to Register New Student</h5>';
							echo '<h5><a href="adminpanel.php?desbat='.$allcurr['batch_year_id'].'">Stop Registration</a>';
						} else {
							echo '<h5> Status: Currently Close to Register New Student</h5>';
							echo '<h5><a href="adminpanel.php?desbat='.$allcurr['batch_year_id'].'">Start Registration</a>';
						}
						echo '<br /><br />';
						echo '<h5><b>Level Start Date</b></h5>';
						echo '<h5>Level 1: '.$allcurr['level1_exam'].'</h5>';
						echo '<h5>Level 2: '.$allcurr['level2_exam'].'</h5>';
						echo '<h5>Level 3: '.$allcurr['level3_exam'].'</h5>';
						echo '<h5>Level 4: '.$allcurr['level4_exam'].'</h5>';
						echo '<h5>Level 5: '.$allcurr['level5_exam'].'</h5>';
						echo '<h5><a href="adminpanel.php?batch=yes&edit='.$allcurr['batch_year_id'].'">Edit Date</a></h5><hr />';

					}
				}
				?>
            		<?php } 
					 else if( ( isset($_GET['mypaschg']) == 'yes') || isset($passactive)  ) { ?>
                    <p class="formtitle" style="margin-bottom:20px;">Change Password</p>
                    
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="changemypassform">
				
               <div class="form-group">
					 <label for="oldpass"><?php echo 'Old Password'; ?></label>
                     
                     <input type="password" class="form-control" name="oldpass" id="oldpass" required="required" value="" placeholder="<?php echo 'Old Password'; ?>"/>
                     
				</div>
                
                <div class="form-group">
					 <label for="newpass"><?php echo 'New Password'; ?></label>
                     
                     <input type="password" class="form-control" name="newpass" id="newpass" required="required" value="" placeholder="<?php echo 'New Password'; ?>"/>
                     
				</div>
                
                <div class="form-group">
					 <label for="connewpass"><?php echo 'Confirm New Password'; ?></label>
                     
                     <input type="password" class="form-control" name="connewpass" id="connewpass" required="required" value="" placeholder="<?php echo 'Confirm New Password'; ?>"/>
                     
                      
				</div>
                
                <button type="submit" class="btn btn-default success" name="changemypass"><?php echo 'Change My Password'; ?></button>

			</form>
            		<?php } 
					 else if( (isset($_GET['myemlchg']) == 'yes') || isset($emailactive) ) { ?>
                    <p class="formtitle" style="margin-bottom:20px;">Change Email</p>
                    
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="emailchangeform">
				
                <div class="form-group">
					 <label for="adminemail"><?php echo 'Email'; ?></label>
                     
                     <input type="email" class="form-control" name="adminemail" id="adminemail" required="required" value="<?php if(isset($adminemail)) { echo htmlspecialchars($adminemail); }?>" placeholder="<?php echo 'New Email Address'; ?>"/>
                     
				</div>
 
 <button type="submit" class="btn btn-default success" name="emailchange"><?php echo 'Change My Email'; ?></button>

			</form>
            		<?php } 
					 else { ?>
                    <p class="formtitle" style="margin-bottom:20px;">Make New Faculty</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="newfacultyform">
				
                
                <div class="form-group">
					 <label for="fullname"><?php echo 'Full Name'; ?></label>
                     
                     <input type="text" class="form-control" name="fullname"  required="required" value="<?php if(isset($fullname)) { echo htmlspecialchars($fullname); }?>" placeholder="<?php echo 'Enter Faculty Full Name'; ?>"/>
                     
				</div>
                
                <div class="form-group">
					 <label for="useremail"><?php echo 'Email'; ?></label>
                     
                     <input type="email" class="form-control" name="useremail" id="useremail" required="required" value="<?php if(isset($useremail)) { echo htmlspecialchars($useremail); }?>" placeholder="<?php echo 'Email Address'; ?>"/>
                     
				</div>
                
				<div class="form-group">
					 <label for="userpass"><?php echo 'Password'; ?></label>
                     
                     <input type="text" class="form-control" name="userpass" id="userpass" required="required" value="<?php if(isset($userpass)) { echo htmlspecialchars($userpass); }?>" placeholder="<?php echo 'Choose Password'; ?>"/>
                     
				</div>
				
                <button type="submit" class="btn btn-default success" name="newuser"><?php echo 'Make New Faculty'; ?></button>
			</form>
                    <?php } 
					?>
				</div>
                </div> 
</div>

</div> 

<!-- Footer -->
<?php require('menu.php'); ?> 

</div>
</body>
</html>
