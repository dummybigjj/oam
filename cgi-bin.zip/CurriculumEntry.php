<?php
session_start();
require('includes/allincludes.php');
//print_r($allvar);

//form posting to database for curriculum start
if (isset($_POST['reglev4']))
	{
		$errors = array();
		
		$curr_name4 = trim(implode(' ', preg_split('/\s+/', $_POST['curr_name4'])));
		
		//..........
		if(empty($curr_name4)) {
			$errors[] = 'Please enter the Full Name of Curriculum for level 4.'; 
		} else if(!preg_match('/^[a-zA-Z0-9 ]{10,40}$/', $curr_name4)) {
			$errors[] = 'Curriculum name for level 4 shall be between 10 - 40 char and numbers';
		} else if (mysql_num_rows(mysql_query("select * from curr_detail where curr_name = '".mysql_real_escape_string($curr_name4)."'")) > 0 ) {
			$errors[] = 'Curriculum name already exist, please select different name';
		}
				
		//print_r($_POST);
		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){
			$curr_reg_id = mysql_fetch_array(mysql_query("SELECT curr_id FROM curr_detail ORDER BY curr_id DESC"));
			$curr_id = $curr_reg_id[0] + 1;
			$entry_user_full_name = 'Alvin Desalva';
			$entry_time = date("U");
			$curr_name = mysql_real_escape_string($curr_name4);
			
			$issubmit = mysql_query("insert into curr_detail (curr_name, curr_id, levels, entry_time, entry_user_full_name) values ('$curr_name', '$curr_id', '4', '$entry_time', '$entry_user_full_name')");
			
			if($issubmit) {
				do_alert("Curriculum for level 4 has been registered, now you have to enter the courses in each level");
				nextpage("CurriculumEntry.php");
				exit;
			}
			
		}
		
	}
	
if (isset($_POST['reglev5']))
	{
		$errors = array();
		
		$curr_name5 = trim(implode(' ', preg_split('/\s+/', $_POST['curr_name5'])));
		
		//..........
		if(empty($curr_name5)) {
			$errors[] = 'Please enter the Full Name of Curriculum for level 5'; 
		} else if(!preg_match('/^[a-zA-Z0-9 ]{10,40}$/', $curr_name5)) {
			$errors[] = 'Curriculum name for level 5 shall be between 10 - 40 char and numbers';
		} else if (mysql_num_rows(mysql_query("select * from curr_detail where curr_name = '".mysql_real_escape_string($curr_name5)."'")) > 0 ) {
			$errors[] = 'Curriculum name already exist, please select different name';
		}
				
		//print_r($_POST);
		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){
			$curr_reg_id = mysql_fetch_array(mysql_query("SELECT curr_id FROM curr_detail ORDER BY curr_id DESC"));
			$curr_id = $curr_reg_id[0] + 1;
			$entry_user_full_name = 'Alvin Desalva';
			$entry_time = date("U");
			$curr_name = mysql_real_escape_string($curr_name5);
			
			$issubmit = mysql_query("insert into curr_detail (curr_name, curr_id, levels, entry_time, entry_user_full_name) values ('$curr_name', '$curr_id', '5', '$entry_time', '$entry_user_full_name')");
						
			if($issubmit) {
				do_alert("Curriculum for level 5 has been registered, now you have to enter the courses in each level");
				nextpage("CurriculumEntry.php");
				exit;
			}
			
		}
		
	}
//form posting to database for curriculum end

//deleting levels from get varaibles
if(isset($_GET['dellvl']) == 'Yes') {
	$curr_id = mysql_real_escape_string($_GET['curr']);
	$major_id = mysql_real_escape_string($_GET['major']);
	$level_no = mysql_real_escape_string($_GET['level']);
	
	$is_complete_data = mysql_fetch_array(mysql_query("select is_complete_data from curr_detail where curr_id = '$curr_id'"));
	if($is_complete_data[0] == 'Yes')
	{
		do_alert("You cannot delete this curriculum, as its already completed");
		nextpage("index.php");
		exit;
	} else {
		if(mysql_num_rows(mysql_query("select * from courses where curr_id = '$curr_id' and major_id = '$major_id' and level_no = '$level_no'")) > 0)
		{
			$deletequery = mysql_query("delete from courses where curr_id = '$curr_id' and major_id = '$major_id' and level_no = '$level_no'");
			if($deletequery)
			{
				do_alert("Level record has been deleted");
				nextpage("CurriculumEntry.php");
				exit;
			} else {
				do_alert("There is something wrong, contact web developer");
				nextpage("CurriculumEntry.php");
				exit;
			}
		} else {
			do_alert("Level information is not available");
			nextpage("CurriculumEntry.php");
			exit;
		}
	}
	
	
}

if(isset($_GET['markcomplete']) == 'Yes') {
	$curr_id = mysql_real_escape_string($_GET['curr']);
	$is_user_mark_entry = mysql_fetch_array(mysql_query("select is_user_mark_entry from curr_detail where curr_id = '$curr_id' and is_complete_data = 'No'"));
	if($is_user_mark_entry[0] == 'Yes')
	{
		do_alert("The curriculum is already marked as completed, waiting for admin approval");
		nextpage("CurriculumEntry.php");
		exit;
	} else if($is_user_mark_entry[0] == 'No') {
			$is_entry_change = mysql_query("update curr_detail set is_user_mark_entry = 'Yes' where curr_id = '$curr_id'");
			if($is_entry_change) {
				do_alert("Curriculum has been marked as completed. Contact admin for approval");
				nextpage("CurriculumEntry.php");
				exit;
				} else {
					do_alert("There is something wrong, contact web developer");
					nextpage("CurriculumEntry.php");
					exit;
				}
			}
		else {
			do_alert("There is something wrong, contact web developer");
			nextpage("CurriculumEntry.php");
			exit;
		}
}

if( isset($_GET['unmarkcomplete']) == 'Yes') {
	$curr_id = mysql_real_escape_string($_GET['curr']);
	$is_user_mark_entry = mysql_fetch_array(mysql_query("select is_user_mark_entry from curr_detail where curr_id = '$curr_id' and is_complete_data = 'No'"));
	if($is_user_mark_entry[0] == 'No')
	{
		do_alert("The curriculum is already marked as NOT completed");
		nextpage("CurriculumEntry.php");
		exit;
	} else if($is_user_mark_entry[0] == 'Yes') {
			$is_entry_change = mysql_query("update curr_detail set is_user_mark_entry = 'No' where curr_id = '$curr_id'");
			if($is_entry_change) {
				do_alert("Curriculum has been marked as NOT completed");
				nextpage("CurriculumEntry.php");
				exit;
				} else {
					do_alert("There is something wrong, contact web developer");
					nextpage("CurriculumEntry.php");
					exit;
				}
			}
		else {
			do_alert("There is something wrong, contact web developer");
			nextpage("CurriculumEntry.php");
			exit;
		}
}

if( isset($_GET['delcur']) == 'Yes') {
	$curr_id = mysql_real_escape_string($_GET['curr']);
	$is_complete_data = mysql_fetch_array(mysql_query("select is_complete_data from curr_detail where curr_id = '$curr_id'"));
	if($is_complete_data[0] == 'Yes')
	{
		do_alert("The curriculum has already completed, you cannot change now");
		nextpage("index.php");
		exit;
	} else  if($is_complete_data[0] == 'No') {
			$is_del_one = mysql_query("delete from curr_detail where curr_id = '$curr_id'");
			$is_del_two = mysql_query("delete from courses where curr_id = '$curr_id'");

			if($is_del_one && $is_del_two) {
				do_alert("Curriculum and all information has been deleted");
				nextpage("CurriculumEntry.php");
				exit;
				} else {
					do_alert("There is something wrong, contact web developer");
					nextpage("CurriculumEntry.php");
					exit;
				}
			} else {
				do_alert("There is something wrong, contact web developer");
				nextpage("CurriculumEntry.php");
				exit;
			}
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>

	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 

<!-- All Bottom of the Header -->   
<div class="width1200">

<?php 
if(mysql_num_rows(mysql_query("select * from curr_detail where is_complete_data != 'Yes'")) == 0) {
?>
<!-- FOR CURRICULUM REGISTRATION START -->
<div class="row" style="margin-bottom:30px;">
<div class="col-sm-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
				<h4>Curriculum Registration</h4>
				</div>
                </div>
</div>
<div class="row" style="margin-bottom:10px;">
<div class="col-sm-12 col-md-12" style="margin:0; padding:0;">

				 <div class="boxback margin10">

					 <h4>Follow the below steps to Register a Curriculum</h4>
					 <ul>
					 <li style="color:red;">You cannot make any changes in the future. Please enter carefully</li>
					 <li>Proceed to only the colom which you need, either 4 or 5 levels of Curriculum</li>
					 <li>Define any name to the Curriculum in "Full Name of Curriculum" field only for your referance in future.Example, "4 Level Curriculum" or "Curriculum for 2015-2016" etc</li>
					 <li>After you click register, the page display the levels to enter the courses</li>
					 </ul>
					 </div>
			</div>
</div>
<!--
<div class="row" style="margin-bottom:40px;">
                
                <?php 
				if(isset($errors))
				{
					echo '<div class="padding10" style="color:red; font-weight:bold;">';
					echo 'ERRORS';
					echo '<div style="color:red; font-weight:normal;">';
				foreach ($errors as $msg) 
				{ ?>
                    <?php echo ">> $msg<br />\n"; ?>
				<?php }
					echo '</div>';
					echo '</div>';
				}
				?>
                
                <div class="col-sm-6 col-md-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4>4 Level Curriculum Registration</h4>
				 </div>
				
                <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="level4currreg">
				<div class="boxback margin10">
					 
					 <div class="form-group">
					 <label for="fullname">Full Name of level 4 Curriculum</label>
                     <input class="form-control" required="required"  type="text" name="curr_name4" value="<?php if (isset($curr_name4)){ echo htmlspecialchars($curr_name4); }  ?>" placeholder="Enter Full Name of level 4 Curriculum">
					 </div>

					 <button type="submit" class="btn btn-success btn-csuccess" name="reglev4">Register 4 Level Curriculum</button>
					 
                </div>
                </form>
                </div>              
				<div class="col-sm-6 col-md-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4>5 Level Curriculum Registration</h4>
				 </div>
				<form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="level5currreg">
				<div class="boxback margin10">
					 
					 <div class="form-group">
					 <label for="fullname">Full Name of level 5 Curriculum</label>
                     <input class="form-control" required="required"  type="text" name="curr_name5" value="<?php if (isset($curr_name5)){ echo htmlspecialchars($curr_name5); } ?>" placeholder="Enter Full Name of level 5 Curriculum">
					 </div>

					 <button type="submit" class="btn btn-success btn-csuccess" name="reglev5">Register 5 Level Curriculum</button>
					 
                </div>
                </form>
                </div>              		
	</div>
 FOR CURRICULUM REGISTRATION END -->

<?php 
} 
else  { 
	$alllevels = array();
	$totallevels = mysql_fetch_array(mysql_query("select levels, curr_id, curr_name from curr_detail where is_complete_data = 'No'"));
	$curr_id = $totallevels[1];
	if($totallevels[0] == '4') {
		$alllevels = $curr4lvls;
	} else if($totallevels[0] == '5') {
		$alllevels = $curr5lvls;
	} else {
		do_alert("There is something wrong with the codes. Contact admin");
		nextpage("index.php");
		exit;
	} ?>

<!-- FOR PENDINGS LEVELS REGISTRATION START 
<div class="row" style="margin-bottom:30px;">
<div class="col-sm-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
				<h4><?php echo $totallevels[2].' REGISTRATION'; ?></h4>
				</div>
                </div>
</div>
<div class="row" style="margin-bottom:10px;">
<div class="col-sm-12 col-md-12" style="margin:0; padding:0;">

				 <div class="boxback margin10">

					 <h4>Follow the below steps to Register a Levels</h4>
					 <ul>
					 <li style="color:red;">You cannot make any changes in the future. Please enter carefully</li>
					 <li>Select every mojor and enter the information of the levels. Using the link for "Enter Courses" beside every levels of majors</li>
					 <li>Once you complete entering all the information, you can Mark the levels complete using the link "Mark All Levels Completes"</li>
                     <li>After you "Mark All Levels Completes", admin will get notificatin to approve the curriculum. If you want to unmarks it, you can do it using the link "UnMark All Levels Completes" which will be available only after you "Mark All Levels Completes"</li>
                     <li>If you want to delete curriculum, go to the bottom on the options column and click "Delete Curriculum". If you delete curriculum, you'll loose all the majors information and has to enter the curriculum again</li>
					 </ul>
					 </div>
			</div>
</div>

<div class="row" style="margin-bottom:40px;">         
<div class="col-sm-6 col-md-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4><?php echo $glomajor['11']; ?></h4>
				 </div>
                 
				<div class="boxback margin10">

                <?php foreach ($alllevels as $key => $value) {
                      echo '<h5><b>'.$value.'</b>';
					  $countfcoures = mysql_num_rows(mysql_query("select * from courses where curr_id = '$curr_id' and 	level_no = '$key' and major_id = '11'"));
					  if($countfcoures > 0) {
						  $action = '<a href="CurriculumEntry.php?dellvl=Yes&curr='.$curr_id.'&major=11&level='.$key.'">Delete all Courses</a>';
					  } else {
						  $action = '<a href="CourseEntry.php?curr='.$curr_id.'&major=11&level='.$key.'">Enter Courses</a>';
					  }
					  echo '<br />Courses Entered = '.$countfcoures.', '.$action.'</h5>';
					 } 
					 	echo '<h5><b>Options</b><br /><a href="Curriculum.php?curr='.$curr_id.'&major=11">View your entries</a></h5>';
					 ?>

                </div>
                
                </div> 

<div class="col-sm-6 col-md-6" style="margin:0; padding:0;">						 
				<div class="boxback margin10 formtitle">
					 <h4><?php echo $glomajor['14']; ?></h4>
				 </div>
                 
				<div class="boxback margin10">

                <?php foreach ($alllevels as $key => $value) {
                      echo '<h5><b>'.$value.'</b>';
					  $countfcoures = mysql_num_rows(mysql_query("select * from courses where curr_id = '$curr_id' and 	level_no = '$key' and major_id = '14'"));
					  if($countfcoures > 0) {
						  $action = '<a href="CurriculumEntry.php?dellvl=Yes&curr='.$curr_id.'&major=14&level='.$key.'">Delete all Courses</a>';
					  } else {
						  $action = '<a href="CourseEntry.php?curr='.$curr_id.'&major=14&level='.$key.'">Enter Courses</a>';
					  }
					  echo '<br />Courses Entered = '.$countfcoures.', '.$action.'</h5>';
					 } 
					 	echo '<h5><b>Options</b><br /><a href="Curriculum.php?curr='.$curr_id.'&major=14">View your entries</a></h5>';
					 ?>

                </div>
                
                </div> 
</div> 

<div class="row" style="margin-bottom: 40px;">
<div class="col-sm-6 col-md-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4><?php echo $glomajor['12']; ?></h4>
				 </div>
                 
				<div class="boxback margin10">

                <?php foreach ($alllevels as $key => $value) {
                      echo '<h5><b>'.$value.'</b>';
					  $countfcoures = mysql_num_rows(mysql_query("select * from courses where curr_id = '$curr_id' and 	level_no = '$key' and major_id = '11'"));
					  if($countfcoures > 0) {
						  $action = '<a href="CurriculumEntry.php?dellvl=Yes&curr='.$curr_id.'&major=11&level='.$key.'">Delete all Courses</a>';
					  } else {
						  $action = '<a href="CourseEntry.php?curr='.$curr_id.'&major=11&level='.$key.'">Enter Courses</a>';
					  }
					  echo '<br />Courses Entered = '.$countfcoures.', '.$action.'</h5>';
					 } 
					 	echo '<h5><b>Options</b><br /><a href="Curriculum.php?curr='.$curr_id.'&major=11">View your entries</a></h5>';
					 ?>

                </div>
                
                </div> 

                <div class="col-sm-6 col-md-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4><?php echo $glomajor['13']; ?></h4>
				 </div>
                 
				<div class="boxback margin10">

                <?php foreach ($alllevels as $key => $value) {
                      echo '<h5><b>'.$value.'</b>';
					  $countfcoures = mysql_num_rows(mysql_query("select * from courses where curr_id = '$curr_id' and 	level_no = '$key' and major_id = '11'"));
					  if($countfcoures > 0) {
						  $action = '<a href="CurriculumEntry.php?dellvl=Yes&curr='.$curr_id.'&major=11&level='.$key.'">Delete all Courses</a>';
					  } else {
						  $action = '<a href="CourseEntry.php?curr='.$curr_id.'&major=11&level='.$key.'">Enter Courses</a>';
					  }
					  echo '<br />Courses Entered = '.$countfcoures.', '.$action.'</h5>';
					 } 
					 	echo '<h5><b>Options</b><br /><a href="Curriculum.php?curr='.$curr_id.'&major=11">View your entries</a></h5>';
					 ?>

                </div>
                
                </div> 
</div>
-->
<?php } ?>



<div class="row" style="margin-bottom:40px;">  
	<?php 
	//var_dump($_POST);
		if (isset($_POST['submit_prep'])) {
			$name = $_POST['prep_name'];
			$levels = 1;
			
			$curr_reg_id = mysql_fetch_array(mysql_query("SELECT curr_id FROM curr_detail ORDER BY curr_id DESC"));
			$curr_id = $curr_reg_id[0] + 1;
			$entry_user_full_name = 'Alvin Desalva';
			$entry_time = date("U");
			//$curr_name = mysql_real_escape_string($curr_name4);
			$is_user_mark_entry = "Yes";	
			$is_open_to_register = "Yes";
			$is_complete_data = "Yes";
			$sql = "INSERT INTO curr_detail (curr_name, curr_id, levels, is_user_mark_entry, is_open_to_register, is_complete_data, entry_time, entry_user_full_name) 
				VALUES (:name, :curr_id, :levels, :is_user_mark_entry, :is_open_to_register, :is_complete_data, :entry_time, :entry_user_full_name) ";
			$stmt = $pdo -> prepare($sql);
			$stmt -> bindParam(":name", $name);
			$stmt -> bindParam(":curr_id", $curr_id);
			$stmt -> bindParam(":levels", $levels);
			$stmt -> bindParam(":is_user_mark_entry", $is_user_mark_entry);
			$stmt -> bindParam(":is_open_to_register", $is_open_to_register);
			$stmt -> bindParam(":is_complete_data", $is_complete_data);
			$stmt -> bindParam(":entry_time", $entry_time);
			$stmt -> bindParam(":entry_user_full_name", $entry_user_full_name);
			if ($stmt -> execute()) {
				do_alert("PREP Curriculum was added!");
				nextpage("CurriculumEntry.php");
				exit();
			}
			
		}

	?>

<!-- FOR PENDINGS LEVELS REGISTRATION END -->

<div class="col-md-6" style="margin: 0; padding: 0;">
	<div class="boxback margin10 formtitle">
					 <h4>Enter PREP Level</h4>
	</div>
	<div class="boxback margin10">
		<form method="POST">
			<div class="form-group">
				<label>PREP Name</label>
				<input type="text" name="prep_name" required class="form-control"/>				
			</div>
			<div class="form-group" style="padding-bottom: 17px;">
				<button type="submit" name="submit_prep" class="btn btn-success pull-right"> Submit </button>
			</div>
		</form>
	</div>
</div>


<!-- SAFETY -->
<div class="row" style="margin-bottom:40px;">  
	<?php 
	//var_dump($_POST);
		if (isset($_POST['submit_safety'])) {
			$name = $_POST['safe_name'];
			$levels = 2;
			
			$curr_reg_id = mysql_fetch_array(mysql_query("SELECT curr_id FROM curr_detail ORDER BY curr_id DESC"));
			$curr_id = $curr_reg_id[0] + 1;
			$entry_user_full_name = 'Alvin Desalva';
			$entry_time = date("U");			
			$is_user_mark_entry = "Yes";	
			$is_open_to_register = "Yes";
			$is_complete_data = "Yes";
			$sql = "INSERT INTO curr_detail (curr_name, curr_id, levels, is_user_mark_entry, is_open_to_register, is_complete_data, entry_time, entry_user_full_name) 
				VALUES (:name, :curr_id, :levels, :is_user_mark_entry, :is_open_to_register, :is_complete_data, :entry_time, :entry_user_full_name) ";
			$stmt = $pdo -> prepare($sql);
			$stmt -> bindParam(":name", $name);
			$stmt -> bindParam(":curr_id", $curr_id);
			$stmt -> bindParam(":levels", $levels);
			$stmt -> bindParam(":is_user_mark_entry", $is_user_mark_entry);
			$stmt -> bindParam(":is_open_to_register", $is_open_to_register);
			$stmt -> bindParam(":is_complete_data", $is_complete_data);
			$stmt -> bindParam(":entry_time", $entry_time);
			$stmt -> bindParam(":entry_user_full_name", $entry_user_full_name);
			if ($stmt -> execute()) {
				do_alert("Safety was added!");
				nextpage("CurriculumEntry.php");
				exit();
			}
			
		}

	?>

<!-- FOR PENDINGS LEVELS REGISTRATION END -->

<div class="col-md-6" style="margin: 0; padding: 0;">
	<div class="boxback margin10 formtitle">
					 <h4>Enter Safety Level</h4>
	</div>
	<div class="boxback margin10">
		<form method="POST">
			<div class="form-group">
				<label>Safety Name</label>
				<input type="text" name="safe_name" required class="form-control"/>				
			</div>
			<div class="form-group" style="padding-bottom: 17px;">
				<button type="submit" name="submit_safety" class="btn btn-success pull-right"> Submit </button>
			</div>
		</form>
	</div>
</div>


<?php 
		if (isset($_POST['submit_civil'])) {
			$name = $_POST['civil_name'];			
			$levels = 5;
			$curr_reg_id = mysql_fetch_array(mysql_query("SELECT curr_id FROM curr_detail ORDER BY curr_id DESC"));
			//$curr_id = $curr_reg_id[0] + 1;
			$curr_id = $curr_reg_id[0] + 1;
			$entry_user_full_name = 'Alvin Desalva';
			$entry_time = date("U");
			//$curr_name = mysql_real_escape_string($curr_name4);
			$is_user_mark_entry = "Yes";	
			$is_open_to_register = "Yes";
			$is_complete_data = "Yes";			


			$sql = "INSERT INTO curr_detail (curr_name, curr_id, levels, is_user_mark_entry, is_open_to_register, is_complete_data, entry_time, entry_user_full_name) 
				VALUES (:name, :curr_id, :levels, :is_user_mark_entry, :is_open_to_register, :is_complete_data, :entry_time, :entry_user_full_name) ";
			$stmt = $pdo -> prepare($sql);
			$stmt -> bindParam(":name", $name);
			$stmt -> bindParam(":curr_id", $curr_id);
			$stmt -> bindParam(":levels", $levels);
			$stmt -> bindParam(":is_user_mark_entry", $is_user_mark_entry);
			$stmt -> bindParam(":is_open_to_register", $is_open_to_register);
			$stmt -> bindParam(":is_complete_data", $is_complete_data);
			$stmt -> bindParam(":entry_time", $entry_time);
			$stmt -> bindParam(":entry_user_full_name", $entry_user_full_name);
			if ($stmt -> execute()) {
				do_alert("Civil Technology Curriculum was added!");
				nextpage("CurriculumEntry.php");
				exit();
			}
			
		}

	?>
<div class="col-md-6" style="margin: 0; padding: 0;">
	<div class="boxback margin10 formtitle">
					 <h4>Enter Civil Technology</h4>
	</div>
	<div class="boxback margin10">
		<form method="POST">
			<div class="form-group">
				<label> Name Civil Technology</label>
				<input type="text" name="civil_name" required class="form-control"/>				
			</div>
			<div class="form-group" style="padding-bottom: 17px;">
				<button type="submit" name="submit_civil" class="btn btn-success pull-right"> Submit </button>
			</div>
		</form>
	</div>
</div>

<?php 
		if (isset($_POST['submit_mech'])) {
			$name = $_POST['mech_name'];			
			$levels = 4;

			$curr_reg_id = mysql_fetch_array(mysql_query("SELECT curr_id FROM curr_detail ORDER BY curr_id DESC"));
			//$curr_id = $curr_reg_id[0] + 1;
			$curr_id = $curr_reg_id[0] + 1;
			$entry_user_full_name = 'Alvin Desalva';
			$entry_time = date("U");
			//$curr_name = mysql_real_escape_string($curr_name4);
			$is_user_mark_entry = "Yes";	
			$is_open_to_register = "Yes";
			$is_complete_data = "Yes";			


			$sql = "INSERT INTO curr_detail (curr_name, curr_id, levels, is_user_mark_entry, is_open_to_register, is_complete_data, entry_time, entry_user_full_name) 
				VALUES (:name, :curr_id, :levels, :is_user_mark_entry, :is_open_to_register, :is_complete_data, :entry_time, :entry_user_full_name) ";
			$stmt = $pdo -> prepare($sql);
			$stmt -> bindParam(":name", $name);
			$stmt -> bindParam(":curr_id", $curr_id);
			$stmt -> bindParam(":levels", $levels);
			$stmt -> bindParam(":is_user_mark_entry", $is_user_mark_entry);
			$stmt -> bindParam(":is_open_to_register", $is_open_to_register);
			$stmt -> bindParam(":is_complete_data", $is_complete_data);
			$stmt -> bindParam(":entry_time", $entry_time);
			$stmt -> bindParam(":entry_user_full_name", $entry_user_full_name);
			if ($stmt -> execute()) {
				do_alert("NDT was added!");
				nextpage("CurriculumEntry.php");
				exit();
			}
			
		}

	?>
<div class="col-md-6" style="margin: 0; padding: 0;">
	<div class="boxback margin10 formtitle">
					 <h4>Enter Mechanical Inspection & NDT</h4>
	</div>
	<div class="boxback margin10">
		<form method="POST">
			<div class="form-group">
				<label> Name of Class Mechanical Inspection & NDT</label>
				<input type="text" name="mech_name" required class="form-control"/>				
			</div>
			<div class="form-group" style="padding-bottom: 17px;">
				<button type="submit" name="submit_mech" class="btn btn-success pull-right"> Submit </button>
			</div>
		</form>
	</div>
</div>
<div class="col-sm-6 col-md-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4>Options</h4>
				 </div>
				
				<div class="boxback margin10">
					 <?php 
					 $curr_id = 9;
					 	$is_user_mark_entry = mysql_fetch_array(mysql_query("select is_user_mark_entry from curr_detail where curr_id = '$curr_id'"));
						if($is_user_mark_entry[0] == 'No') { ?>
							<h5><b><a onclick="return confirm('Are you sure you want to continue')"  href="CurriculumEntry.php?markcomplete=Yes&curr=<?php echo $curr_id; ?>">Mark All Majors Completes</a></b>
                     <br />Marks only if you finish entering all the information of all the coures of all majors levels.</h5>
                     <?php
						} else { ?>
							<h5><b><a onclick="return confirm('Are you sure you want to continue')"  href="CurriculumEntry.php?unmarkcomplete=Yes&curr=<?php echo $curr_id; ?>">Unmark All Majors Completes</a></b>
                     <br />Unmarking the levels to complete will remove the notification from the admin panel</h5>
					<?php	} ?>

 
                     <h5><b><a onclick="return confirm('Are you sure you want to continue')" href="CurriculumEntry.php?delcur=Yes&curr=<?php echo $curr_id; ?>">Delete Curriculum</a></b>
                     <br />Once you Delete, you will loose all the information. You have to enter the curriculum information once again.</h5>
					 
                </div> 
</div>
</div>
</div>           		

        
<!-- Footer -->
<?php require('footer.php'); ?>  

</div>
</body>
</html>
