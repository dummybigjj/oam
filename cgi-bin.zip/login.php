<?php
session_start();
require('includes/allincludes.php');

if ( !empty($_SESSION) )
{
	header("Location: logout.php");
	exit;
}
require('includes/allincludes.php');
if (isset($_POST['loginbuttonpressed']))
	{
			$errors = array();
			//reading the values
			if(empty($_POST['username'])){
				$errors[] = 'Please enter the email address'; }
			else {
				$logusername = strtolower(trim($_POST['username']));
				if (!(filter_var($logusername, FILTER_VALIDATE_EMAIL))) {
				$errors[] = 'Please enter a valid Email address'; }
				}  
				
			if(empty($_POST['password'])){
				$errors[] = 'Please enter the Password'; }
			else {
				$logpassword = $_POST['password'];  }
			
			if(isset($_POST['rem_scl'])) {
			$rem_scl  = $_POST['rem_scl']; }

			$errors = array_filter($errors, 'strlen');
			
			if(empty($errors))
			{
				if( mysql_num_rows(mysql_query("SELECT email, password FROM users WHERE email = '".mysql_real_escape_string($logusername)."' and password = '".mysql_real_escape_string($logpassword)."'")) == 1 )
					{
							$checkmailquery = mysql_fetch_assoc(mysql_query("select * from users where email = '".mysql_real_escape_string($logusername)."'"));

							$_SESSION['email'] = $logusername;
							$_SESSION['loginas'] = $checkmailquery['profile'];
						 	if($rem_scl !="")
							{
							  setcookie("cooksclid", $logusername, time()+60*60*24*7, "/");
							  setcookie("cooksclpas", $logpassword, time()+60*60*24*7, "/");
							}
							if($checkmailquery['profile'] == 'faculty') { 
							header("Location:index.php");
							exit; 
							} else if($checkmailquery['profile'] == 'admin') {
							header("Location:adminpanel.php");
							exit; 
							}
						
					}
				else
					{
						$errors[]= 'Your login credentials does not match';
					}
			}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>

	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<div style="margin-bottom:44px;">
<nav class="navbar-inverse navbar-default navbar-fixed-top"  role="navigation" style="background-color:#16212D;  border-bottom:2px solid #fff;  height:40px;  color:#fff;">

        <div class="width1200">
            <div class="navbar-header" style="padding-left:10px;">
            <h4>THIEP Students Record Book</h4>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            

            <!-- /.navbar-collapse -->
        </div>

        <!-- /.container -->
    </nav>
</div>
<!-- All Bottom of the Header -->   
<div class="width1200" style="margin-top:60px;">
<div class="row" style="margin-bottom:30px;">
				
                <div class="col-sm-12" style="margin:0; padding:0; margin:0 auto; text-align:center;">
                <div style="padding:0 4px;">
				
                <img src="img/logo.png" />
				</div>
                </div>
</div>

<div class="row" style="margin-bottom:10px;">
                <div class="col-md-12" style="margin:0; padding:0;">
                	<div style="width:500px; margin:0 auto; background-color:#fff; padding:20px; border:2px solid #CCCCCC;">
                 <?php 
				if(isset($errors))
				{
					echo '<div style="color:red; font-weight:normal;">';
				foreach ($errors as $msg) 
				{ ?>
                    <?php echo "$msg<br />\n"; ?>
				<?php }
					echo '</div>';
				}
				?>
                	<form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="loginform">
				<div class="form-group">
					 <label for="exampleInputEmail1"><?php echo 'Email'; ?></label>
                     
                     <input type="email" class="form-control" name="username" id="username" required="required" value="<?php if(isset($logusername)) { echo htmlspecialchars($logusername); } else if(isset($_COOKIE["cooksclid"])) { echo $_COOKIE["cooksclid"]; }?>" placeholder="<?php echo 'Email Address'; ?>"/>
                     
				</div>
				<div class="form-group">
					 <label for="exampleInputPassword1"><?php echo 'Password'; ?></label>
                     
                     <input type="password" class="form-control" name="password" id="password" required="required" value="<?php if(isset($_COOKIE["cooksclpas"])) { echo $_COOKIE["cooksclpas"]; } ?>" placeholder="<?php echo 'Password'; ?>"/>
                     
				</div>
				
				<div class="checkbox">
					 <label>
                     <input name="rem_scl" id="rem_scl" type="checkbox" <?php if(isset($rem_scl)) { echo'checked="checked"'; } ?> /><?php echo 'Remember'; ?></label>  
                     
                     
				</div> 
                <button type="submit" class="btn btn-default success" name="loginbuttonpressed" id="loginbuttonpressed" ><?php echo 'Secure Login'; ?></button>
                
                 <p class="help-block" style="margin-top:20px;">
						<h6><b>*</b>Contact admin if problem in login</h6>
					</p>
			</form>
            		</div>
                </div>
                </div>

</div> 



<!-- Footer -->
<div>
<nav class="navbar-inverse navbar-default navbar-fixed-bottom"  role="navigation" style="background-color:#16212D; border-top:2px solid #FFFFFF; height:36px; color:#fff;">
        <div class="width1200">
            <div class="navbar-header" style="padding-left:10px;">
            <h5>Copyright &copy; THIEP. All Rights Reserved</h5>
            </div>
            
            <div class="navbar-header navbar-right" style="padding-right:10px;">
                <h5>Made by <a href="http://www.fedri.com" target="_blank">Fedri</a></h5>

            </div>
        </div>
    </nav>
</div>

</div>
</body>
</html>
