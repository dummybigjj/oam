<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}
//print_r($allvar);
$openbatches = array();
$completedcurr = array();

	$openbatches = all_batches_open();
	$completedcurr = all_curr_data_complete();
	
if(isset($_POST['showstudents'])) {
		$errors = array();
		
		$curriculum = $_POST['curriculum'];
		$batchyear = $_POST['batchyear'];
		$major = $_POST['major'];
		
		if(empty($batchyear)) {
			$errors[] = 'You have to select a minimum of student batch, to limit the student in a page';
		}
		
		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){
			nextpage("SearchStudents.php?curr=$curriculum&major=$major&batchid=$batchyear");
			exit;
		}
		
	
}

if (isset($_POST['showmajor']))
	{
		$errors = array();
		
		$curriculum = $_POST['curr_id'];
		$batchyear = $_POST['batchyear'];
		$major = $_POST['major'];
		
		if(empty($curriculum) || empty($batchyear) || empty($major)) {
			$errors[] = 'All fields has to selected to show the students details';
		}
		
		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){
			nextpage("Curriculum.php?curr=$curriculum&major=$major&batchid=$batchyear");
			exit;
		}
		
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>
  
	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 
<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:10px;">
				
                <div class="col-xs-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
				<h4>Print Record</h4>
				</div>
                </div>
</div>

				 
<div class="row" style="margin-bottom:40px;">
                <?php 
				if(isset($errors))
				{
					echo '<div class="padding10" style="color:red; font-weight:bold;">';
					echo 'ERRORS';
					echo '<div style="color:red; font-weight:normal;">';
				foreach ($errors as $msg) 
				{ ?>
                    <?php echo ">> $msg<br />\n"; ?>
				<?php }
					echo '</div>';
					echo '</div>';
				}
				?>
                 <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="majorrecord">
                <div class="col-xs-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4>Major Record</h4>
				 </div>
				
				<div class="boxback margin10">
					 
					 <h5 class="textjustify">This column give you the the current Status of the Major, Number of Students, Number of Levels, Number of Subjects, Credit Hours, Marks Entry Status and link to Enter the Marks. You have to select the Proper Batch Start Date, Curriculum and the Major</h5>

					 
					  <div class="form-group">
					 	<label>Curriculum</label>
					 	<select class="form-control" name="curr_id">
					 		<?php 
					 			$sql = "SELECT * FROM curr_detail WHERE is_open_to_register = 'Yes' ";
					 			$stmt = $pdo -> prepare($sql);
					 			$stmt -> execute();
					 			while ($row = $stmt -> fetch()) {
					 				$id = $row['curr_id'];
					 				$name = $row['curr_name'];
					 				echo "<option value='$id'> $name </option>";
					 			}

					 		?>

					 	</select>
					 </div>
                
                	 <div class="form-group">
					 <label for="batchyear"><?php echo 'Batch Year'; ?></label>
                     <select class="form-control" name="batchyear" required >
                    <?php 
					if(isset($batchyear))
					{
						echo '<option selected="selected" value="'.$batchyear.'">'.$openbatches[$batchyear].'</option>';
					} else {
					?>
                    <option selected="selected" value="" disabled="disabled"><?php echo 'Batch Year'; ?></option>
					<?php }
						foreach($openbatches as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>
                    </select>
				</div>
                
                	 <div class="form-group">
					 <label for="major"><?php echo 'Major'; ?></label>
                     <select class="form-control" name="major" required >
                    <?php 
					if(isset($major))
					{
						echo '<option selected="selected" value="'.$major.'">'.$glomajor[$major].'</option>';
					} else {
					?>
                    <option selected="selected" value="" disabled="disabled"><?php echo 'Major'; ?></option>
					<?php }
						foreach($glomajor as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>
                    </select>
				</div>
               

					 
					 
					 </br>
				<button type="submit" class="btn btn-success btn-csuccess" name="showmajor">Show Major Details</button>
					 
                </div>
                </div> 
                </form>
                
                 <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="studentrecord">
                  <div class="col-xs-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4>Student Record</h4>
				 </div>
				
                
				<div class="boxback margin10">
					 
					 <h5 class="textjustify">This column gives you the record of the personal and THEIP information of the student. Select proper Curriculum, Batch and Major or you can select all to give you the list of all the students in the THIEP</h5>

					 
					 <div class="form-group">
					 	<label>Curriculum</label>
					 	<select class="form-control" name="curr_id">
					 		<?php 
					 			$sql = "SELECT * FROM curr_detail WHERE is_open_to_register = 'Yes' ";
					 			$stmt = $pdo -> prepare($sql);
					 			$stmt -> execute();
					 			while ($row = $stmt -> fetch()) {
					 				$id = $row['curr_id'];
					 				$name = $row['curr_name'];
					 				echo "<option value='$id'> $name </option>";
					 			}

					 		?>

					 	</select>
					 </div>
                
                	 <div class="form-group">
					 <label for="batchyear"><?php echo 'Batch Year'; ?></label>
                     <select class="form-control" name="batchyear" required>
                    <?php 
					if(isset($batchyear))
					{
						echo '<option selected="selected" value="'.$batchyear.'">'.$openbatches[$batchyear].'</option>';
					} else {
					?>
                    <option selected="selected" value="" disabled="disabled"><?php echo 'Batch Year'; ?></option>
					<?php }
						foreach($openbatches as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>
                    </select>
				</div>
                
                	 <div class="form-group">
					 <label for="major"><?php echo 'Major'; ?></label>
                     <select class="form-control" name="major" >
                    <?php 
					if(isset($major))
					{
						echo '<option selected="selected" value="'.$major.'">'.$glomajor[$major].'</option>';
					} else {
					?>
                    <option selected="selected" value=""><?php echo 'All Major'; ?></option>
					<?php }
						foreach($glomajor as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>
                    </select>
				</div>
                

					 </br>
				<button type="submit" class="btn btn-success btn-csuccess" name="showstudents">Show Students Details</button>
					 
                </div>
                
                </div> 
              </form>
				</div>


</div> 


<!-- Footer -->
<?php require('footer.php'); ?> 

</div>
</body>
</html>
