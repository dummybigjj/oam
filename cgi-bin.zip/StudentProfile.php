<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}
//print_r($allvar);

	if(!$_GET['regid'])
	{
		header("location: index.php");
		exit;
	} else {
		$allinfoquery = mysql_query("select * from students where reg_id=".mysql_real_escape_string($_GET['regid']));
		if(mysql_num_rows($allinfoquery)!= 1)
		{
			header("location: index.php");
			exit;
		} else {
			$reg_id = $_GET['regid'];
			$allinfo = mysql_fetch_assoc($allinfoquery);
		}
	}
	
	if(isset($_POST['currchange'])) {
		$errors = array();
		$timenow = date("U");
		
		$curr_id = $_POST['curr_id'];
		$maj_id = $_POST['maj_id'];
		
		
		//.........
		if(empty($_POST['curr_id'])) {
			$errors[] = 'Please choose the curriculum.'; 
		} else {
			if( !array_key_exists($curr_id, all_curr_to_register()) ) {
				$errors[] = 'Invalid curriculum selected, Contact Developer.';
			}
		}			
		
		
		//.........
		if(empty($_POST['maj_id'])) {
			$errors[] = 'Please choose the Major.'; 
		} else {
			if( !array_key_exists($maj_id, $glomajor) ) {
				$errors[] = 'Invalid city selected, Contact Developer.';
			}
		}
		
		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){
		
			$updatecurrquery = mysql_query("update students set curr_id = '".mysql_real_escape_string($curr_id)."', major_id = '".mysql_real_escape_string($maj_id)."' where reg_id = '$reg_id'");
			if($updatecurrquery) {
				do_alert("Curriculum and major has updated");
				nextpage("StudentProfile.php?regid=$reg_id");
			}
		}
		
	}
	
	if(isset($_POST['statuschange'])) {
		$errors = array();
		$timenow = date("U");
		
		$stustatus = $_POST['stustatus'];
		$disc = trim($_POST['disc']);
		
		//.........
		if(empty($_POST['stustatus'])) {
			$errors[] = 'Please choose the Status.'; 
		} else {
			if($stustatus != 'Deleted' && $stustatus != 'Withdrawn') {
				$errors[] = 'Invalid Status selected, Contact Developer.';
			}
		}			
		
		
		//.........
		if(empty($_POST['disc'])) {
			$errors[] = 'Please discribe the reason for changing status'; 
		} else {
			if( strlen(utf8_decode($disc)) < 20)  {
				$errors[] = 'Reason should be a minimum of 20 english characters ';
			}
		}
		
		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){
			$disc = $disc.'... By: '.$loginvar['full_name'];
			$updatecurrquery = mysql_query("update students set is_active = '".mysql_real_escape_string($stustatus)."', 	inactive_reason = '".mysql_real_escape_string($disc)."' where reg_id = '$reg_id'");
			if($updatecurrquery) {
				do_alert("Student Status has been updated");
				nextpage("StudentProfile.php?regid=$reg_id");
			}
		}
		
	}

	$i = 1; 
   $stu_mar_query = mysql_query("select * from marks where reg_id = '$reg_id' and level_no = '10'");
   if(mysql_num_rows($stu_mar_query) > 0){
   	 while($stu_mar = mysql_fetch_assoc($stu_mar_query)) { 
   		$edit_num = $stu_mar['edit_num'];
   		$table_id = $stu_mar['table_id'];
   	
   	} 
   } 	else {

   	}
  
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>

	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu_edit.php'); ?> 

<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:30px;">
				
                <div class="col-sm-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
				<h4>Student Profile</h4>
				</div>
                </div>
</div>

<div class="row" >
                <?php 
				if(isset($errors))
				{
					echo '<div class="padding10" style="color:red; font-weight:bold;">';
				foreach ($errors as $msg) 
				{ ?>
                    <?php echo "- $msg<br />\n"; ?>
				<?php }
					echo '</div>';
				}
				?>
                <div class="col-md-6" style="margin:0; padding:0;">

				 <div class="boxback margin10 formtitle">
					 <h4>Personal Information المعلومات الشخصيه
</h4>
				 </div>
				<div class="margin10">
<table class="tg">
  <tr>
    <th class="tg-i9x5 textright" style="width:150px;">الاسم العربي</th>
	<td class="tg-yw4l textright" style="padding:10px;"><b><?php echo $allinfo['arabic_name']; ?></b></td>
  </tr>
	<tr>
    <th class="tg-i9x5" style=" text-align:left;">English Name</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $allinfo['english_name']; ?></td>
  </tr>
  <tr>
    <th class="tg-i9x5" style=" text-align:left;">National ID رقم الهوية
</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $allinfo['national_id']; ?></td>
  </tr>
  <tr>
    <th class="tg-i9x5" style=" text-align:left;">Nationality الجنسية
</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $country_list[$allinfo['nationality']]; ?></td>
  </tr>
  <!--
  <tr>
    <th class="tg-i9x5" style=" text-align:left;">Living City اسم المدينة 
</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $city_list[$allinfo['city']]; ?></td>
  </tr>
  
<tr>

    <th class="tg-i9x5" style=" text-align:left;">Place of Issue مكان الاصدار 
</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $allinfo['place_issue']; ?></td>
  </tr>
<tr>
-->
	<!--
    <th class="tg-i9x5" style=" text-align:left;">Date of Expires تاريخ انتهاء الهوية بالهجري
</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $allinfo['date_issue']; ?></td>
  </tr>
<tr>
    <th class="tg-i9x5" style=" text-align:left;">Date of Birth تاريخ الميلاد بالهجري
</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $allinfo['student_dob']; ?></td>
  </tr>
-->
    <tr>
    <th class="tg-i9x5" style=" text-align:left;">Email</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $allinfo['email']; ?></td>
  </tr>
  <tr>
    <th class="tg-i9x5" style=" text-align:left;">Mobile رقم الجوال 
</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $allinfo['mobile']; ?></td>
  </tr>
 


</table>
                </div>
                </div>              
				
				<div class="col-md-6" style="margin:0; padding:0;">

                <div class="boxback margin10 formtitle">
					 <h4>THIEP Information معلومات عن المعهد الفني العالي للهندسة والبترول
</h4>
				     </div>
				<div class="margin10">
					
<table class="tg">
<tr>
    <th class="tg-i9x5" style=" text-align:left; width:150px;">Reg. No</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $allinfo['reg_id']; ?></td>

  </tr>
<tr>
    <th class="tg-i9x5" style=" text-align:left;">Major</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;">
	<?php if(empty($allinfo['major_id'])) {
			echo 'Major Not Selected Yet';
		}  else {
			echo $glomajor[$allinfo['major_id']]; 
		}
		?>
    </td>
  </tr>
	<tr>
    <th class="tg-i9x5" style=" text-align:left;">Join, Batch, Exit</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo 'Join: '.$allinfo['date_reg'].', Batch: '.batch_name_from_id($allinfo['batch_year_id']).', '; if(empty($allinfo['date_exit'])) { echo '<a href="StudentProfileEdit.php?regid='.$reg_id.'">Add Exit Date</a>'; } else { echo 'Exit: '.$allinfo['date_exit'];}?></td>
  </tr>
  

  <tr>
    <th class="tg-i9x5" style=" text-align:left;">Status</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php if($allinfo['is_active'] == 'Yes' ) {echo "Active";} else { echo $allinfo['is_active']; } ?></td>
  </tr>
  <?php 
  $totlvl = mysql_fetch_array(mysql_query("select levels from curr_detail where curr_id = '".$allinfo['curr_id']."'"));
  ?>
  <tr class="no-print">
    <th class="tg-i9x5" rowspan=" <?php if($totlvl[0] == '5') { echo '7'; } else { echo '6'; };?>" style=" text-align:left;">Record</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;">Prep <b><a href="PrepRecord.php?regid=<?php echo $reg_id; ?>&level=10&view=Yes">View</a> <a href="<?php echo 'PrepEntry.php?regid='.$reg_id,'&prep=entry'; ?>">Enter</a> 
	<a href="PrepRecord.php?regid=<?php echo $reg_id; ?>&level=10&view=No">Edit</a>
	</b></td>

  </tr>
<tr class="no-print">
	<td class="tg-yw4l" style="padding:10px; text-align:left;">Level 1 <b><?php echo '<a href="AcademicTranscript.php?regid='.$allinfo['reg_id'].'&level=11&view=Yes">View</a>
	';
	
	if(mysql_num_rows(mysql_query("select * from marks where reg_id = ".$allinfo['reg_id']." and is_fresh = 'No' and level_no = '11'")) >= 1) {
		echo ', <a href="SuppTranscript.php?regid='.$allinfo['reg_id'].'&level=11&view=Yes"> Supplemantary</a>   ';
	}	
	?> 
	<a href="ViewMarks.php?regid=<?php echo $allinfo['reg_id']; ?>&curr=<?php echo $allinfo['curr_id']; ?>&level=11&major=<?php echo $allinfo['major_id']; ?>&batchid=<?php echo $allinfo['batch_year_id']; ?>">Enter</a> 

	<a href="AcademicTranscript.php?regid=<?php echo $allinfo['reg_id']; ?>&curr=<?php echo $allinfo['curr_id']; ?>&level=11&major=<?php echo $allinfo['major_id']; ?>&batchid=<?php echo $allinfo['batch_year_id']; ?>">Edit </a></b></td>

	
	
  </tr>
<tr class="no-print">
	<td class="tg-yw4l" style="padding:10px; text-align:left;">Level 2 <b><?php echo '<a href="AcademicTranscript.php?regid='.$allinfo['reg_id'].'&level=12&view=Yes"> View </a> ';
	
	if(mysql_num_rows(mysql_query("select * from marks where reg_id = ".$allinfo['reg_id']." and is_fresh = 'No' and level_no = '12'")) >= 1) {
		echo ', <a href="SuppTranscript.php?regid='.$allinfo['reg_id'].'&level=12"> Supplemantary</a>';
	}
	
	?>
	<a href="ViewMarks.php?regid=<?php echo $allinfo['reg_id']; ?>&curr=<?php echo $allinfo['curr_id']; ?>&level=12&major=<?php echo $allinfo['major_id']; ?>&batchid=<?php echo $allinfo['batch_year_id']; ?>">Enter</a> 
	<a href="AcademicTranscript.php?regid=<?php echo $allinfo['reg_id']; ?>&curr=<?php echo $allinfo['curr_id']; ?>&level=12&major=<?php echo $allinfo['major_id']; ?>&batchid=<?php echo $allinfo['batch_year_id']; ?>">Edit </a></b></td>
  </tr>
<tr class="no-print">
	<td class="tg-yw4l" style="padding:10px; text-align:left;">Level 3 <b><?php echo '<a href="AcademicTranscript.php?regid='.$allinfo['reg_id'].'&level=13&view=Yes"> View </a>';
	
	if(mysql_num_rows(mysql_query("select * from marks where reg_id = ".$allinfo['reg_id']." and is_fresh = 'No' and level_no = '13'")) >= 1) {
		echo ', <a href="SuppTranscript.php?regid='.$allinfo['reg_id'].'&level=13"> Supplemantary</a>';
	}
	
	?>
	<a href="ViewMarks.php?regid=<?php echo $allinfo['reg_id']; ?>&curr=<?php echo $allinfo['curr_id']; ?>&level=13&major=<?php echo $allinfo['major_id']; ?>&batchid=<?php echo $allinfo['batch_year_id']; ?>">Enter</a> 
	<a href="AcademicTranscript.php?regid=<?php echo $allinfo['reg_id']; ?>&curr=<?php echo $allinfo['curr_id']; ?>&level=13&major=<?php echo $allinfo['major_id']; ?>&batchid=<?php echo $allinfo['batch_year_id']; ?>">Edit </a></b></td>
  </tr>
  <tr class="no-print">
	<td class="tg-yw4l" style="padding:10px; text-align:left;">Level 4 <b><?php echo '<a href="AcademicTranscript.php?regid='.$allinfo['reg_id'].'&level=14&view=Yes"> View </a>';
	
	if(mysql_num_rows(mysql_query("select * from marks where reg_id = ".$allinfo['reg_id']." and is_fresh = 'No' and level_no = '14'")) >= 1) {
		echo ', <a href="SuppTranscript.php?regid='.$allinfo['reg_id'].'&level=14"> Supplemantary</a>';
	}	
	?>
	<a href="ViewMarks.php?regid=<?php echo $allinfo['reg_id']; ?>&curr=<?php echo $allinfo['curr_id']; ?>&level=14&major=<?php echo $allinfo['major_id']; ?>&batchid=<?php echo $allinfo['batch_year_id']; ?>">Enter</a> 
	 <a href="AcademicTranscript.php?regid=<?php echo $allinfo['reg_id']; ?>&curr=<?php echo $allinfo['curr_id']; ?>&level=14&major=<?php echo $allinfo['major_id']; ?>&batchid=<?php echo $allinfo['batch_year_id']; ?>">Edit </a></b></td>
  </tr>
  <?php
  if($totlvl[0] == '5') {
 ?>
  <tr class="no-print">
	<td class="tg-yw4l" style="padding:10px; text-align:left;">Level 5 <b><?php echo '<a href="AcademicTranscript.php?regid='.$allinfo['reg_id'].'&level=15"> Fresh Result</a>';
	
	if(mysql_num_rows(mysql_query("select * from marks where reg_id = ".$allinfo['reg_id']." and is_fresh = 'No' and level_no = '15'")) >= 1) {
		echo ', <a href="SuppTranscript.php?regid='.$allinfo['reg_id'].'&level=15"> Supplemantary</a>';
	}
	
	?> 
	<a href="ViewMarks.php?regid=<?php echo $allinfo['reg_id']; ?>&curr=<?php echo $allinfo['curr_id']; ?>&level=15&major=<?php echo $allinfo['major_id']; ?>&batchid=<?php echo $allinfo['batch_year_id']; ?>">Enter</a> 
	 <a href="AcademicTranscript.php?regid=<?php echo $allinfo['reg_id']; ?>&curr=<?php echo $allinfo['curr_id']; ?>&level=15&major=<?php echo $allinfo['major_id']; ?>&batchid=<?php echo $allinfo['batch_year_id']; ?>">Edit </a> </b></td>
  </tr>
  <?php } ?>
  
  <tr class="no-print">
	<td class="tg-yw4l" style="padding:10px; text-align:left;">Transcripts <b><a href="<?php echo 'SelectTranscript.php?regid='.$reg_id; ?>"> View </a></b></td>
  </tr>

</table>
					
                </div>
                </div> 
                             
				<?php if(empty($allinfo['curr_id']) && ($allinfo['is_active'] == 'Yes') ) { ?>
                <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])).'?regid='.$_GET['regid']; ?>" method="post" name="currchangeform">
				<div class="col-xs-6" style="margin:0; padding:0;">

                
				<div class="boxback margin10 formtitle no-print">
					 <h4>Curriculum Options</h4>
				     </div>
				<div class="boxback margin10  no-print">
					<?php if( !empty($allinfo['curr_id']) ) {
						
						} else {
							$allcurr = all_curr_to_register()
					?>

                     <div class="form-group  no-print">
                     <label for="curr_id"><?php echo 'Curriculum'; ?></label>
                     <?php if(empty($allcurr)) {echo '<em style="font-size:12px; color:red;">Please ask admin to activate the curriculum</em>';} else { ?>
                     <?php } ?>
                     <select class="form-control" name="curr_id" >
                    <?php 
					if(isset($curr_id))
					{
						echo '<option selected="selected" value="'.$curr_id.'">'.$allcurr[$curr_id].'</option>';
					} else {
					?>
                  <option selected="selected" disabled="disabled"><?php echo 'Select Curriculum'; ?></option>
					<?php }

						foreach($allcurr as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>
                    </select>
				</div>

                     <div class="form-group">
                     <label for="maj_id"><?php echo 'Select Major'; ?></label>
                     <select class="form-control" name="maj_id" >
                    <?php 
					if(isset($maj_id))
					{
						echo '<option selected="selected" value="'.$maj_id.'">'.$glomajor[$maj_id].'</option>';
					} else {
					?>
                  <option selected="selected" disabled="disabled"><?php echo 'Select Major'; ?></option>
					<?php }

						foreach($glomajor as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>
                    </select>
				</div>
                     
                     
                     
                    
					 <br>
					 <button type="submit" class="btn btn-success btn-csuccess" name="currchange">Assigned Curriculum</button>
                     <a href="<?php echo 'StudentProfileEdit.php?regid='.$reg_id; ?>">Edit Profile</a>
                     <?php } ?>
                </div>
                </div>
                </form> 
                <?php } else { ?> 
</div>
<div class="row" style="padding-bottom: 120px;">
                <div class="col-md-6" style="margin:0; padding:0;">
				<div class="boxback margin10 formtitle">
					 <h4>Curriculum Details</h4>
				     </div>
				<div class="margin10"> 
                <table class="tg">
  <tr>
    <th class="tg-i9x5" style="width:150px; text-align:left;">Curriculum</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><b><?php echo curr_name_from_id($allinfo['curr_id']); ?></b></td>
  </tr>
	<tr class="no-print">
	<td class="tg-yw4l" colspan="2" style="padding:10px; text-align:left;">Cannot modify major, batch & Curriculum now <br />  <a href="<?php echo 'StudentProfileEdit.php?regid='.$reg_id; ?>">Edit Profile</a></td>
  </tr>
</table>
				</div>
                </div>
                <?php } ?>
	
    			<?php if($allinfo['is_active'] == 'Yes') { ?>
				<form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])).'?regid='.$_GET['regid']; ?>" method="post" name="statuschangeform">
                <div class="col-xs-6" style="margin:0; padding:0;">

                
				<div class="boxback margin10 formtitle no-print">
					 <h4>Status Options</h4>
				     </div>
				<div class="boxback margin10 no-print">
					 
					 <div class="form-group">
                     <label for="stustatus"><?php echo 'Modify Status'; ?></label>
                     <select class="form-control" required name="stustatus"  >
                    <?php 
					if(isset($stustatus))
					{
						if($stustatus == 'Deleted') {
							$putvalue = 'Delete Student';
						} else if($stustatus == 'Withdrawn') {
							$putvalue = 'Student Withdrawn';
						}
						echo '<option selected="selected" value="'.$stustatus.'">'.$putvalue.'</option>';
					} else {
					?>
                  <option selected="selected" disabled="disabled"><?php echo 'Modify Status'; ?></option>
					<?php } ?>

							<option value="Deleted">Delete Student</option>
							<option value="Withdrawn">Student Withdrawn</option>
                    </select>
				</div>
                	
					 <div class="form-group">
					 <label for="disc">Reason for Delete & Withdrawn</label>
                     
					 <textarea class="form-control" required="required" style="resize:vertical; min-height:50px; max-height:200px;"  name="disc" placeholder="Enter Discription"><?php if (isset($disc)) {
					 	echo htmlspecialchars($disc);
					 }  ?></textarea>
					 </div>

					 <ul>
					 <li style="color:red;">Delete is if admin want to delete if there is any mistake</li>
                     <li style="color:red;">Withdrawn is if the student left the institute</li>
					 </ul>
                <button type="submit" onclick="return confirm('Are you sure you want to continue')"  class="btn btn-success btn-csuccess"  name="statuschange">Modify Status</button>
                </div>
                </div> 
                </form>
                
                <?php } else { ?>
                <div class="col-xs-6" style="margin:0; padding:0;">
				<div class="boxback margin10 formtitle">
					 <h4>Status Details</h4>
				     </div>
				<div class="margin10"> 
                <table class="tg">
  <tr>
    <th class="tg-i9x5" style="width:150px; text-align:left;">Status</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><b><?php echo $allinfo['is_active']; ?></b></td>
  </tr>
	<tr>
    <th class="tg-i9x5" style=" text-align:left;">Reason</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo nl2br($allinfo['inactive_reason']); ?></td>
  </tr>
</table>
				</div>
                </div>
                <?php } ?>
	</div>
</div> 





<!-- Footer -->
<?php require('footer.php'); ?> 

</div>
</body>
</html>
