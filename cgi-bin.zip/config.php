<?php

	$connection =  mysql_connect("localhost", "thiepdbb", "ayanchua") or die ('There is a problem in Username & Password ' . mysql_error());
	/**
	$connection =  mysql_connect("68.178.217.49", "thiepdb", "Original88@") or die ('There is a problem in Username & Password ' . mysql_error());
	**/
	//host name(localhost), user name (root), password(blank)
	$db = mysql_select_db("thiepapp") or die ('Databse could not be able to selected.' . mysql_error());
	if (!$db) {
		echo "DATABASE NOT CONNECT";
	}

	$servername = "localhost";
	$username = "thiepdbb";
	$password = "ayanchua";

	$pdo = new PDO("mysql:host=$servername;dbname=thiepapp", $username, $password);
   if (!$db)
   {
   echo "DATABASE NOT CONNECT";
   }
/*
	$connection =  mysql_connect("localhost", "thiepdb", "Original88$@") or die ('There is a problem in Username & Password ' . mysql_error());	
	//host name(localhost), user name (root), password(blank)
	$db = mysql_select_db("thiepdb") or die ('Databse could not be able to selected.' . mysql_error());
	if (!$db) {
		echo "DATABASE NOT CONNECT";
	}
*/
?>