<?php 
	require('includes/allincludes.php');
	$batch_year_id = 0;

	for ($i=2015; $i >= 2009; $i--) { 	
		$newbatch = htmlspecialchars("Batch ".$i." – January ".$i);
		$level1_exam = "1/12/1480";
		$level2_exam = "1/12/1480";
		$level3_exam = "1/12/1480";
		$level4_exam = "1/12/1480";
		$level5_exam = "1/12/1480";



		$isenter = mysql_query("INSERT INTO batch_year (batch_year_id, batch_name, level1_exam, level2_exam, level3_exam, level4_exam, level5_exam) values ('$batch_year_id', '$newbatch', '$level1_exam', '$level2_exam', '$level3_exam', '$level4_exam', '$level5_exam')");

	
	}


	


?>