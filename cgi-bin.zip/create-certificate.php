<?php
session_start();
error_reporting(0);
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>
  
	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    <link href="css/select2.css" rel="stylesheet" />
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 

<!-- All Bottom of the Header -->   
<div class="width1200">

<div class="row">
  <div class="contaier">
    <form method="POST" action="certificate.php">
      <div class="form-group">
        <label class="">Student Name </label>
        <select class="form-control select" name="sname">
          <option>Select Student</option>
          <?php 
            $sql = "SELECT * FROM students";
            $stmt = $pdo -> prepare($sql);
            $stmt -> execute();

            while ($row = $stmt -> fetch()) {
              $name = $row['english_name'];
              $arabic = $row['arabic_name'];

              echo "<option> $name </option>";
            }

          ?>
        </select>
      </div>     
      <div class="form-group">
        <label class="">Select Course</label>
        <select name="course" class="form-control">
          <option>PREP</option>
          <option>Civil Technology</option>
          <option>Mechanical Inspection & NDT</option>
        </select>
      </div>
      <div class="form-group">
        <label class="">Date Started </label>
        <input type="date" class="form-control" name="ds">
      </div>
      <div class="form-group">
        <label class="">Date Finished </label>
        <input type="date" class="form-control" name="df">
      </div> 
      <div class="form-group">
        <label class="">Date Given </label>
        <input type="date" class="form-control" name="dg">
      </div>
      <button type="submit" name="submit" class="btn btn-success pull-right">Submit</button>
    </form>
  </div>

</div>
<script type="text/javascript" src="js/select2.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
      $('.select').select2();
  });
</script>
<!-- Footer -->
<?php require('footer.php'); ?> 

</div>

<script type="text/javascript">
 function myFunction() {
    window.print();
}
</script>
</body>
</html>
