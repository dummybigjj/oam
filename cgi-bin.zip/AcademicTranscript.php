<?php
session_start();
error_reporting(0);
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}
//http://localhost:8012/thiepapp/AcademicTranscript.php?regid=1000000&level=11
$is_edit = $loginvar['del_marks'];

if( (count($_GET) < 2) || empty($_GET['regid']) || empty($_GET['level']) ) {
	header("location: index.php");
	
} 
else if (!empty($_GET['del'])) {
	
	 if( ($is_edit != 'Yes') || (count($_GET) < 3) ) {
		 header("Location: index.php");
		 exit;
	 } 
	 
   if (isset($_GET['del'])) {
    $table_id = mysql_real_escape_string($_GET['del']);
    $marvarquery = mysql_query("select * from marks where table_id = '$table_id'");
   
   if(mysql_num_rows($marvarquery) != 1) {

    header("Location: index.php");
    exit;
   }
   }
	 
	
	 $marvar = mysql_fetch_assoc($marvarquery);

	 if( mysql_num_rows(mysql_query("select * from marks where reg_id = '".$marvar['reg_id']."' and course_ref_no = '".$marvar['course_ref_no']."' and level_no = '".$marvar['level_no']."' and curr_id = '".$marvar['curr_id']."' and major_id = '".$marvar['major_id']."' and pass_fail = 'Passed'  and table_id != $table_id")) == 1) {
		 do_alert("Student has already passed the exam, you cannot delete the student record. If you want to delete, you have to delete the record which student has already passed");
		 nextpage("AcademicTranscript.php?regid=".$_GET['regid']."&level=".$_GET['level']);
		 exit;
	 }
	 
	
	else {
		$is_del = mysql_query("delete from marks where table_id = '$table_id'");
		if($is_del) {
			header("Location: AcademicTranscript.php?regid=".$_GET['regid']."&level=".$_GET['level']);
			exit;
		} else {
			do_alert("Cannot able to delete, contact developer");
			nextpage("index.php");
			exit;
		}
	}
	
}
else {
	$reg_id = mysql_real_escape_string($_GET['regid']);
	$level_no = mysql_real_escape_string($_GET['level']);
	$allstu_query = mysql_query("SELECT * from students where reg_id = '$reg_id'");

	if(mysql_num_rows($allstu_query) != 1) {

		nextpage("index.php");
		
	} else {
		$stuinfo = mysql_fetch_assoc($allstu_query);
		//$curr_id = $stuinfo['curr_id'];
    $curr_id = 1;
		$major_id = $stuinfo['major_id'];
		$batch_year_id = $stuinfo['batch_year_id'];
    $curr_table  = $stuinfo['curr_table'];

    echo $major_id."<br>";
    echo $curr_id."<br>";
    echo $batch_year_id."<br>";
    echo $curr_table."<br>";

	}
	$allcoursesquery = mysql_query("SELECT * from courses WHERE curr_id = '$curr_id' and level_no = '$level_no' and major_id = '$major_id'");
	
	if(mysql_num_rows($allcoursesquery) < 3){
    do_alert("No grade");
		//header("location: index.php");
		exit;
	} 
}

if (isset($_GET['view'])) {
  $view = "Yes";
} else {
  $view = "No";
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>
  
	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 

<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:10px;">
				
                <div class="col-xs-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
                <h4><?php echo $glomajor[$major_id]; ?></h4><h5><?php echo 'Batch: '.batch_name_from_id($batch_year_id).', '.$curr5lvls[$level_no].', Academic Transcript'; ?></h5>
				</div>
                
                </div>
</div>


				 
<div class="row" style="margin-bottom:40px;">
                <div class="col-xs-12" style="margin:0; padding:0;">				 

				
				<div style="margin-bottom:10px;">

<table class="tg">
  <tr>
    <th class="tg-i9x5" style="width:180px;">Arabic Name</th>
	<td class="tg-yw4l" style="padding:10px;"><?php echo $stuinfo['arabic_name']; ?></td>
  </tr>
	<tr>
    <th class="tg-i9x5" style="width:180px;">English Name</th>
	<td class="tg-yw4l" style="padding:10px;"><?php echo $stuinfo['english_name']; ?></td>
  </tr>
  <tr>
    <th class="tg-i9x5" style="width:180px;">National ID</th>
	<td class="tg-yw4l" style="padding:10px;"><?php echo '<a href="StudentProfile.php?regid='.$stuinfo['reg_id'].'">'.$stuinfo['national_id'].'</a>'; ?></td>
  </tr>

</table>

		 
                </div>
               

			   </div> 

			    <div class="col-xs-12" style="margin:0; padding:0;">
 <div style="margin-bottom:10px;">
<table class="tg">
  <tr>
    <th class="tg-i9x5" colspan="2">Fresh Record</th>
    </tr>
  <tr>
    <th class="tg-i9x5" width="100">Code</th>
    <th class="tg-i9x5">Course</th>
    <th class="tg-i9x5" width="80">Credit</th>
    <th class="tg-i9x5">Grade</th>
    <th class="tg-i9x5">Score</th>
    <th class="tg-i9x5">GPA</th>
    <th class="tg-i9x5">Points</th>

    <?php if($is_edit == 'Yes' && $view == "No") { ?>

    <th class="tg-i9x5 no-print">Edit</th>
    <th class="tg-i9x5 no-print">Delete</th>
    <?php } ?>
  </tr>
  
  <?php 
  $num_grade = 0; 
  $credit_hour = 0;
  $totalval = 0;
  while($allcourses = mysql_fetch_assoc($allcoursesquery)) {
  ?>
  <tr>

    <td class="tg-yw4l" style="text-align:left;"><?php echo $allcourses['course_code']; ?></td>
    <td class="tg-yw4l" style="text-align:left"><?php echo $allcourses['course_name']; ?></td>
    <td class="tg-yw4l"><?php echo $allcourses['credit_hour'].'.0'; ?></td>
    <?php 
      $course_ref_no = $allcourses['course_ref_no'];
      $allmarks = mysql_fetch_array(mysql_query("select let_grade, num_grade, is_fresh, table_id from marks where reg_id = '$reg_id' and course_ref_no = '$course_ref_no' and level_no = '$level_no' and curr_id = '$curr_id' and major_id = '$major_id' and is_fresh = 'Yes'"));
          
      $num_grade = $num_grade + $allmarks[1];
      $credit_hour = $credit_hour + $allcourses['credit_hour'];
      $gpa = scoretovalue($allmarks[1]);
      $totalval =  $totalval + ($allcourses['credit_hour']*$gpa);
  ?>
    
    <td class="tg-yw4l"><?php echo $allmarks[0]; ?></td>
    <td class="tg-yw4l"><?php echo $allmarks[1]; ?></td>
    <td class="tg-yw4l"><?php echo $gpa; ?></td>
    <td class="tg-yw4l"><?php echo $allcourses['credit_hour']*$gpa; ?></td>
    <?php if($is_edit == 'Yes' && $view == "No") { ?>
    <?php echo '<td class="tg-yw4l"> <a href="EditMarksEntry.php?regid='.$reg_id.'&courseid='.$allcourses['course_ref_no'].'&levelid='.$level_no.'&edit='.$allmarks[3].'">Edit</a> </td>';  ?> 
    <td class="tg-yw4l no-print">
<?php if(!empty($allmarks)) { ?>
     <a onclick="return confirm('Are you sure you want to continue')"  href="AcademicTranscript.php?regid=<?php echo $reg_id; ?>&level=<?php echo $level_no; ?>&del=<?php echo $allmarks[3]; ?>">Delete</a> <?php } ?> </td>
    <?php } ?>
  </tr>
  
  <?php } ?>

 <tr>
    <th class="tg-i9x5" colspan="2">Total</th>
    <th class="tg-i9x5"><?php echo $credit_hour.'.0'; ?></th>
	<th class="tg-i9x5" colspan="3"></th>
    <th class="tg-i9x5"><?php echo $totalval; ?></th>
    <?php if($is_edit == 'Yes' && $view == "No") { ?>
    <th class="tg-i9x5 no-print"></th>
    <th class="tg-i9x5 no-print"></th>
    <?php } ?>
  </tr>

  </table>
  </div>
 </div>

  <div class="col-xs-4" style="margin:0; padding:0;">
 <div style="margin-bottom:10px;">
 <table class="tg" style="margin:0; padding:0;">
  <tr>
    <th class="tg-i9x5" colspan="2">Term Result</th>
  </tr>
  <tr>
    <td class="tg-yw4l" style="text-align:left;">Registered Credits</td>
    <td class="tg-yw4l" style="text-align:left;"><?php echo $credit_hour.'.0'; ?></td>
  </tr>
  <tr>
    <td class="tg-yw4l" style="text-align:left;">GPA (Points/Credits)</td>
    <td class="tg-yw4l" style="text-align:left;"><?php echo round($totalval/$credit_hour, 2); ?></td>
  </tr>
</table>
</div>
 </div>

   <div class="col-xs-8" style="margin:0; padding:0;">
   <div class="padding10 centertext">
   <br><br></br></br>
   <br><h4>Signature & Stamp</h4></h4></br>
   </div>
   </div>
			    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="button" class="btn btn-success no-print pull-right" onclick="myFunction()" value="PRINT" />   <br>
			   </div>

<!-- Footer -->
<?php require('footer.php'); ?> 

</div>

<script type="text/javascript">
 function myFunction() {
    window.print();
}
</script>
</body>
</html>
