<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}

//print_r($allvar);
if(!$_GET['regid'])
	{
		header("location: index.php");
		exit;
	} else {
	
		$allinfoquery = mysql_query("select * from students where reg_id=".mysql_real_escape_string($_GET['regid'])." and is_active = 'Yes'");
		if(mysql_num_rows($allinfoquery)!= 1)
		{
			header("location: index.php");
			exit;
		} else {
			$reg_id = $_GET['regid'];
			$allinfo = mysql_fetch_assoc($allinfoquery);
			$old_national_id = $allinfo['national_id'];
		}
	}

if (isset($_POST['pofilestudent']))
	{
		$errors = array();
		$english_name = trim(implode(' ', preg_split('/\s+/', $_POST['english_name'])));
		$arabic_name = trim($_POST['arabic_name']);
		$mobile = trim($_POST['mobile']);
		$email = trim($_POST['email']);
		//$city = $_POST['city'];
		$nationality = $_POST['nationality'];
		$national_id = trim(implode(' ', preg_split('/\s+/', $_POST['national_id'])));
		//$place_issue = trim(implode(' ', preg_split('/\s+/', $_POST['place_issue'])));
		
		/**
		$dob_day = $_POST["dob_day"];
		$dob_month = $_POST["dob_month"];
		$dob_year = $_POST["dob_year"];
		$student_dob = $dob_day."/".$dob_month."/".$dob_year;
		
		$doi_day = $_POST["doi_day"];
		$doi_month = $_POST["doi_month"];
		$doi_year = $_POST["doi_year"];
		$date_issue = $doi_day."/".$doi_month."/".$doi_year;
		
		**/
		$dor_day = $_POST["dor_day"];
		$dor_month = $_POST["dor_month"];
		$dor_year = $_POST["dor_year"];
		$date_reg = $dor_day."/".$dor_month."/".$dor_year;
		
		$doe_day = $_POST["doe_day"];
		$doe_month = $_POST["doe_month"];
		$doe_year = $_POST["doe_year"];
		
		if(!empty($doe_day) && !empty($doe_month) && !empty($doe_year)) {
		$date_exit = $doe_day."/".$doe_month."/".$doe_year;
		}
		
		//..........
		if(empty($english_name)) {
			$errors[] = 'Please enter the Full English Name.'; 
		} else {
			if(!preg_match('/^[a-zA-Z ]{8,40}$/', $english_name)) {
				$errors[] = 'Name shall be between 8 - 40 char in English.';
			}
		}
		
		//..........
		if(empty($arabic_name)) {
			$errors[] = 'Please enter the Full Arabic Name.'; 
		} 
				

		//.........
		if(empty($mobile)) {
			$errors[] = 'Please enter the Mobile Number.'; 
		} else {
			$mobile = trim(implode(' ', preg_split('/\s+/', $_POST['mobile'])));
			if(!(preg_match('/^[0-9]{10,10}$/', $mobile))) {
				$errors[] = 'Mobile Number shall be of 10 Digits.';
			}
		}
		
		//.........
		/**
		if (!(filter_var($email, FILTER_VALIDATE_EMAIL))) {
			$errors[] = "Enter valid email address.";
		}
		else if ($email != $allinfo['email']) { 
			if(mysql_num_rows(mysql_query("select * from students where email = '".mysql_real_escape_string($email)."'")) == 1) {
			$errors[] = "Email already exist, Please change the email if the student is student another major.";
			}
		}
		
		**/
		
		//.........
		/**
		if(empty($_POST['city'])) {
			$errors[] = 'Please choose the city where student living.'; 
		} else {
			$city  = $_POST['city']; 
			if( !array_key_exists($city, $city_list) ) {
				$errors[] = 'Invalid city selected, Contact Developer.';
			}
		}
		**/			
		
		//.........
		if(empty($nationality)) {
			$errors[] = 'Please Select the Nationality.'; 
		} else { 
			if(!array_key_exists($nationality, $country_list)) {
				$errors[] = 'Invalid Country Selection, Contact Developer.';
			}
		}
		
		//.........
		if(empty($national_id)) {
			$errors[] = 'Please enter the National ID.'; 
		} else {
			if(!(preg_match('/^[0-9]{10,10}$/', $national_id))) {
				$errors[] = 'National ID shall be of 10 Digits.';
			}
		}
		
		
		/**
		//.........
		if(empty($_POST['place_issue'])) {
			$errors[] = 'Please enter the place of issue of ID.'; 
		} else {
			if( !array_key_exists($place_issue, $city_list) ) {
				$errors[] = 'Invalid city selected, Contact Developer.';
			}
		}	
**/
		//.........
		/**
		if(empty($dob_day) || empty($dob_month) || empty($dob_year) || empty($doi_day) || empty($doi_month) || empty($doi_year) || empty($dor_day) || empty($dor_month) || empty($dor_year))
				{
					$errors[]= "Date, Month & Years has to be selected.";
				}
		**/
		
		if (empty($dor_day) || empty($dor_month) || empty($dor_year) ) {
			$errors[]= "Date, Month & Years has to be selected.";
		}
		//.........
		/*if(empty($_POST['batch_year_id'])) {
			$errors[] = 'Please choose the batch start for the student.'; 
		} else {
			$batch_year_id  = $_POST['batch_year_id']; 
			if( !array_key_exists($batch_year_id, $allbatches) ) {
				$errors[] = 'Invalid batch selected, Contact Developer.';
			}
		}*/		
	
		//print_r($_POST);
		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){
		$edit_user_full_name = $loginvar['full_name'];
		
		$edit_time = date("U");
		
		$english_name = mysql_real_escape_string($english_name);
		$arabic_name = mysql_real_escape_string($arabic_name);
		$mobile = mysql_real_escape_string($mobile);
		$email = mysql_real_escape_string($email);
		//$city = mysql_real_escape_string($city);
		$nationality = mysql_real_escape_string($nationality);
		//$national_id = mysql_real_escape_string($national_id);
		//$place_issue = mysql_real_escape_string($place_issue);
		//$student_dob = mysql_real_escape_string($student_dob);
		//$date_issue = mysql_real_escape_string($date_issue);
		$batch_year_id = mysql_real_escape_string($batch_year_id);
		$date_reg = mysql_real_escape_string($date_reg);
		if(!empty($date_exit)) {
			$date_exit = mysql_real_escape_string($date_exit);
		} else {
			$date_exit = '';
		}
		// email = '$email',
		//student_dob = '$student_dob', 
		//date_issue = '$date_issue',
		//place_issue = '$place_issue', 
		//city = '$city', 
		$isdone = mysql_query("update students set 
					 english_name = '$english_name',
					 arabic_name = '$arabic_name', 
					 mobile = '$mobile', 										 
					 email = '$email',
					 national_id = '$national_id', 
					 nationality = '$nationality', 			 
					 date_exit = '$date_exit', 
					 date_reg = '$date_reg',
					 edit_time = '$edit_time', 
					 edit_user_full_name = '$edit_user_full_name' 
					 where 
					 reg_id	= '$reg_id'
						");
						
			if(isset($isdone)) {
				if ($old_national_id != $national_id) {
					$username = $edit_user_full_name;
					$date_changed = date("U");
					$type_of_change = "NATIONAL ID";
					$orig_data = $old_national_id;
					$new_data = $national_id;
					$log = mysql_query("INSERT INTO log_entry (username, type_of_change, orig_data, new_data) 
						VALUES ('$username', '$type_of_change', '$orig_data', '$new_data' ) ");
					header("Location:StudentProfile.php?regid=$reg_id");
					exit;
				} else {
					header("Location:StudentProfile.php?regid=$reg_id");
					exit;
				}

					
			}
		
	}

	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>

	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 
<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:30px;">
				
                <div class="col-sm-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
				<h4>Student Registration</h4>
				</div>
                </div>
</div>

<div class="row" style="margin-bottom:40px;">
                
                 <?php 
				if(isset($errors))
				{
					echo '<div class="padding10" style="color:red; font-weight:bold;">';
					echo 'ERRORS';
					echo '<div style="color:red; font-weight:normal;">';
				foreach ($errors as $msg) 
				{ ?>
                    <?php echo ">> $msg<br />\n"; ?>
				<?php }
					echo '</div>';
					echo '</div>';
				}
				?>
                
                <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])).'?regid='.$reg_id; ?>" method="post" name="studentedit">
                
                <div class="col-xs-6" style="margin:0; padding:0;">

				 <div class="boxback margin10 formtitle">
					 <h4>Personal Information المعلومات الشخصيه
</h4>
				 </div>
				<div class="boxback margin10">
					
					 
					 <div class="form-group">
					 <label for="fullname">Full Name in English الاسم الكامل بالانجليزي
</label>
                     <input class="form-control" required="required"  name="english_name"   type="text" value="<?php if(isset($english_name)) { echo htmlspecialchars($english_name);} else {echo $allinfo['english_name']; } ?>" placeholder="Enter Full Name in English">
					 </div>
					 
					 <div class="form-group">
					 <label for="fullname">Full Name in Arabic</label>
                     <input class="form-control" required="required"  name="arabic_name"   type="text" value="<?php if(isset($arabic_name)) { echo htmlspecialchars($arabic_name);} else {echo $allinfo['arabic_name']; } ?>" placeholder="Enter Full Name in Arabic">
					 </div>
					 
					  <div class="form-group">
					 <label for="fullname">Mobile Number رقم الجوال 
</label>
                     <input class="form-control" required="required"  name="mobile"   type="text" value="<?php if(isset($mobile)) { echo htmlspecialchars($mobile);} else {echo $allinfo['mobile']; } ?>" placeholder="Enter Mobile Number">
					 </div>
					 
					 <div class="form-group">
					 <label for="">Email ID</label>
                     <input class="form-control" name="email"   type="email" value="<?php if(isset($email)) { echo htmlspecialchars($email);} else {echo $allinfo['email']; } ?>" placeholder="Enter Valid Email ID">
					 </div>
					<!--
                     <div class="form-group">
					 <label for="city"><?php echo 'City of Living'; ?> اسم المدينة 
</label>
                     <select  class="form-control" name="city" required >
                    <?php 
					if(isset($city))
					{
						echo '<option selected="selected" value="'.$city.'">'.$city_list[$city].'</option>';
					} else {
					?>
                    <option selected="selected" value="<?php echo $allinfo['city']; ?>"><?php echo $city_list[$allinfo['city']]; ?></option>
					<?php }
						foreach($city_list as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>
                    </select>
				</div>
                     	-->			 
					 
                </div>
                </div>              
				
				<div class="col-xs-6" style="margin:0; padding:0;">

                <div class="boxback margin10 formtitle">
					 <h4>Official Information معلومات رسمية 
</h4>
				     </div>
				<div class="boxback margin10">
					 
					 
                     
                     <div class="form-group">
					 <label for="nationality"><?php echo 'Nationality'; ?> الجنسية
</label>
                     <select class="form-control" name="nationality" required >
                    <?php 
					if(isset($nationality))
					{
						echo '<option selected="selected" value="'.$nationality.'">'.$country_list[$nationality].'</option>';
					} else {
					?>
                    <option selected="selected" value="<?php echo $allinfo['nationality'] ?>"><?php echo $country_list[$allinfo['nationality']]; ?></option>
					<?php }
						foreach($country_list as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>
                    </select>
				</div>

					 <div class="form-group">
					 <label for="fullname">National ID رقم الهوية
</label><br />
                     
                      <input class="form-control" required="required"  name="national_id"   type="text" value="<?php if(isset($national_id)) { echo htmlspecialchars($national_id);} else {echo $allinfo['national_id']; } ?>" placeholder="Enter National ID">

					 </div>
					 <!--
					 <div class="form-group">
					 <label for="fullname">Place of Issue مكان الاصدار 
</label>                     
                     <select  class="form-control" name="place_issue" required >
                    <?php 
					if(isset($place_issue))
					{
						echo '<option selected="selected" value="'.$place_issue.'">'.$city_list[$place_issue].'</option>';
					} else {
					?>
                    <option selected="selected" value="<?php echo $allinfo['place_issue'] ?>"><?php echo $city_list[$allinfo['place_issue']]; ?></option>
					<?php }
						foreach($city_list as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>
                    </select>
                     
                     
					 </div>	
					-->
					 <!--
					 <div class="form-group">
					 <label for="fullname">Date of ID Expires in Arabic تاريخ انتهاء الهوية بالهجري
</label><br />
                     
                     <select class="form-control" name="doi_day" required style="display:inline-block; width:32%;">
      <?php 
	  if(isset($doi_day)){?>
      <option value="<?php echo $doi_day; ?>" selected="selected"><?php echo $doi_day;?></option>
      <?php }else{ 
	  $alldoi = explode('/',$allinfo['date_issue']);
	  ?>
      <option selected="selected" value="<?php echo $alldoi[0]; ?>"><?php echo  $alldoi[0]; ?></option>
      <?php } ?>
      <?php
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" required name="doi_month" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($doi_month)){?>
      <option value="<?php echo $doi_month; ?>" selected="selected"><?php echo $doi_month;?></option>
      <?php }else{ ?>
      <option selected="selected" value="<?php echo $alldoi[1]; ?>"><?php echo  $alldoi[1]; ?></option>
      <?php } ?>
      <?php
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" required name="doi_year"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($doi_year)){?>
        <option value="<?php echo $doi_year; ?>" selected="selected"><?php echo $doi_year;?></option>
        <?php }else{ ?>
        <option selected="selected" value="<?php echo $alldoi[2]; ?>"><?php echo  $alldoi[2]; ?></option>
        <?php } ?>
        <?php 
	for ($i=1490; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>	
                     -->
                     <div class="form-group">
					 <label for="fullname">Date of Registration in Arabic تاريخ تسجيل بالهجري
							</label><br />
                     
                     <select class="form-control" required name="dor_day" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($dor_day)){?>
      <option value="<?php echo $dor_day; ?>" selected="selected"><?php echo $dor_day;?></option>
      <?php }else{ 
	  $alldor = explode('/',$allinfo['date_reg']);
	  ?>
      <option selected="selected" value="<?php echo $alldor[0]; ?>"><?php echo  $alldor[0]; ?></option>
      <?php } ?>
      <?php
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" required name="dor_month" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($dor_month)){?>
      <option value="<?php echo $dor_month; ?>" selected="selected"><?php echo $dor_month;?></option>
      <?php }else{ ?>
      <option selected="selected" value="<?php echo $alldor[1]; ?>"><?php echo  $alldor[1]; ?></option>
      <?php } ?>
      <?php
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" required name="dor_year"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($dor_year)){?>
        <option value="<?php echo $dor_year; ?>" selected="selected"><?php echo $dor_year;?></option>
        <?php }else{ ?>
        <option selected="selected" value="<?php echo $alldor[2]; ?>"><?php echo  $alldor[2]; ?></option>
        <?php } ?>
        <?php 
	for ($i=1490; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
                     
                     <div class="form-group">
					 <label for="fullname">Date of Exit in Arabic</label><br />
                     
                     <select class="form-control" name="doe_day" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($doe_day)){?>
      <option value="<?php echo $doe_day; ?>" selected="selected"><?php echo $doe_day;?></option>
      <?php }else{ 
	  $alldoe = explode('/',$allinfo['date_exit']);
	  ?>
      <option selected="selected" value="<?php echo $alldoe[0]; ?>"><?php echo  $alldoe[0]; ?></option>
      <?php } ?>
      <option value="">Day</option>
      <?php
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="doe_month" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($doe_month)){?>
      <option value="<?php echo $doe_month; ?>" selected="selected"><?php echo $doe_month;?></option>
      <?php }else{ 
      	 $alldoe = explode('/',$allinfo['date_exit']);
      ?>
      <option selected="selected" value="<?php if(isset($alldoe[1])){ echo $alldoe[1]; }else {  }  ?>"><?php if(isset($alldoe[1])){ echo $alldoe[1]; }else {  }  ?></option>
      <?php } ?>
      <option value="" >Month</option>
      <?php
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" name="doe_year"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($doe_year)){?>
        <option value="<?php echo $doe_year; ?>" selected="selected"><?php echo $doe_year;?></option>
        <?php }else{ ?>
        <option selected="selected" value="<?php if(isset($alldoe[2])){ echo $alldoe[2]; }else {  }  ?>"><?php if(isset($alldoe[2])){ echo $alldoe[2]; }else {  }  ?></option>
        <?php } ?>
        <option value="">Year</option>
        <?php 
	for ($i=1490; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>
					 <!--
					 <div class="form-group">
					 <label for="fullname">Date of Birth in English تاريخ الميلاد بالهجري
</label><br />

      <select class="form-control" required name="dob_day" style="display:inline-block; width:32%;">
      <?php 
	  $alldob = explode('/',$allinfo['student_dob']);
	  if(isset($dob_day)){?>
      <option value="<?php echo $dob_day; ?>" selected="selected"><?php echo $dob_day;?></option>
      <?php }else{ ?>
      <option selected="selected" value="<?php echo $alldob[0]; ?>"><?php echo  $alldob[0]; ?></option>
      <?php } ?>
      <?php
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      <select class="form-control" required name="dob_month" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($dob_month)){?>
      <option value="<?php echo $dob_month; ?>" selected="selected"><?php echo $dob_month;?></option>
      <?php }else{ ?>
      <option selected="selected" value="<?php echo $alldob[1]; ?>"><?php echo  $alldob[1]; ?></option>
      <?php } ?>
      <?php
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      <select class="form-control" required name="dob_year" id="dob_year" style="display:inline-block; width:32%;">
        <?php 
	  if(isset($dob_year)){?>
        <option value="<?php echo $dob_year; ?>" selected="selected"><?php echo $dob_year;?></option>
        <?php }else{ ?>
        <option selected="selected" value="<?php echo $alldob[2]; ?>"><?php echo  $alldob[2]; ?></option>
        <?php } ?>
        <?php 
	for ($i=1437; $i>=1380; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
-->
					 </div>
                </div>
                </div>              
				
				  

				<div class="col-xs-6" style="margin:0; padding-bottom:100px;">

                
				<div class="boxback margin10 formtitle">
					 <h4>Submission تسليم 
</h4>
				     </div>
				<div class="boxback margin10">
					 
					 <h4>Before you save the application, make sure the below are done</h4>
					 <ul>
					 <li>You Physically varify all the documents</li>
					 </ul>
					 </br>
					 <h4>قبل حفظ هذه المعلومات، تأكد من أكمال التالي:</h4>
					 <ul>
					 	<li>عليك التأكد من كل المستندات.   </li>
					 </ul>
            <button style="margin-bottom:4px;" type="submit" class="btn btn-success btn-csuccess" name="pofilestudent">Save and go to Student Profile حفظ و ذهاب الى ملف الطالب 
</button>
					 
                </div>
                </div> 
                
                </form>
				
	</div>
</div> 

<!-- Footer -->
<?php require('footer.php'); ?> 

</div>
</body>
</html>
