<div class="printonly">
	<div class="col-xs-5 text-center">
	<h5 style="padding:0; margin:0px;">Technical Higher Institute for</h5>
	<h5 style="padding:0; margin:0px;">Engineering and Petroleum (THIEP)</h5>
	<h6 style="padding:0; margin:0px;">Under the supervision of</h6>
	<h6 style="padding:0; margin:0px;">The General Organization for Technical and</h6>
	<h6 style="padding:0; margin:0px;">Vocational Training</h6>
	<h6 style="padding:0; margin:0px;">Lic, No: 214/6777</h6>
</div>

<div class="col-xs-4">
<img class="img-responsive imagecenter" src="img/logo.png" />
</div>

<div class="col-xs-3 text-center">
<h5 style="padding:0; margin:0px;">المعهد التقني العالي</h5>
<h5 style="padding:0; margin:0px;">(للهندسة والبترول (ذيـب</h5>
<h6 style="padding:0; margin:0px;">تحت اشراف</h6>
<h6 style="padding:0; margin:0px;">المؤسسة العامة</h6>
<h6 style="padding:0; margin:0px;">للتدريب التقني والمهني</h6>
<h6 style="padding:0; margin:0px;">ترخيص رقم: 6775/214</h6>
</div>
</div>

<div class="printonly" style="margin-bottom:4px; clear:both;" ></div>

<div class="no-print" style="margin-bottom:44px;">
<nav class="navbar-inverse navbar-default navbar-fixed-top"  role="navigation" style="background-color:#16212D;  border-bottom:2px solid #fff;  height:40px;  color:#fff;">

        <div class="width1200">
            <div class="navbar-header" style="padding-left:10px;">
            	<h4>THIEP Students Record Book</h4>
            </div>

             <ul class="nav navbar-nav navbar-right">
		      <li class=""><a href="index.php">HOME</a></li>
		      <li class="dropdown">
	      		 <a href="#" class="dropdown-toggle" data-toggle="dropdown">REGISTER<strong class="caret"></strong></a>
						  <ul class="dropdown-menu">
						  	<li class=""><a href="StudentEntry.php">REGISTER STUDENT </a></li>
						  	<li class=""><a href="CurriculumEntry.php">REGISTER CURRICULUM </a></li>
						  	<li class=""><a href="input-grade.php">INPUT GRADES </a></li>
						  </ul>
		      </li>
		     <li class="dropdown">
	      		 <a href="#" class="dropdown-toggle" data-toggle="dropdown">PRINT<strong class="caret"></strong></a>
						  <ul class="dropdown-menu">
						  	<li class=""><a href="transcriptsearch.php"> TRANSCRIPT </a></li>
						  	<li class=""><a href="classrecord.php"> CLASS RECORD </a></li>
						  	<li class=""><a href="create-certificate.php"> CERTIFICATE </a></li>
						  	<li class=""><a href="studentprint.php"> STUDENT PROFILE </a></li>
						  	<li class=""><a href="individualgrade.php"> INDIVIDUAL GRADE </a></li>
						  </ul>
		      </li>
		      <li> <a href="logout.php">Logout</a></li>
		    </ul>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-ex1-collapse" style="border:0; background-color:#16212D; ">
            <!-- This is to give the spacing above the menu -->
                <ul class="nav navbar-nav">

						</li>
                </ul>

            </div>

            <!-- /.navbar-collapse -->
        </div>

        <!-- /.container -->
    </nav>
</div>

<div class="no-print" style="margin-top:100px;" ></div>