<div class="no-print">
<nav class="navbar-inverse navbar-default navbar-fixed-bottom"  role="navigation" style="background-color:#16212D; border-top:2px solid #FFFFFF; height:36px; color:#fff;">
        <div class="width1200">
            <div class="navbar-header" style="padding-left:10px;">
            <h5>Copyright &copy; THIEP. All Rights Reserved</h5>
            </div>
            
            <div class="navbar-header navbar-right" style="padding-right:10px;">
                <h5>Made by <a href="http://www.fedri.com" target="_blank">Fedri</a></h5>

            </div>
        </div>
    </nav>
</div>