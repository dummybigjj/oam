<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}
//print_r($allvar);
//SelectTranscript.php?regid=1000004

	if(!$_GET['regid'])
	{
		header("location: index.php");
		exit;
	} else {
		$allinfoquery = mysql_query("SELECT * from students where major_id != 0 AND reg_id=".mysql_real_escape_string($_GET['regid']) );
		if(mysql_num_rows($allinfoquery) != 1)
		{ 
      //do_alert("Student do not have major selected, cannot view transcript");
			//nextpage("index.php");
      $regiid = $_GET['regid'];
      nextpage("ViewTransVoc.php?regid=$regiid");
			exit;
		} else {
			$reg_id = $_GET['regid'];
			$allinfo = mysql_fetch_assoc($allinfoquery);
		}
		
		
	}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>

	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-rtl.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 

<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:30px;">
<div class="col-xs-12 text-center">
<h4><?php echo 'Diploma in '.$glomajor[$allinfo['major_id']]; ?></h4>
</div>				
<div class="col-xs-6">
<h5 style="padding:0; margin:1px;">اسم المتدرب: <?php echo $allinfo['arabic_name']; ?></h5>
<h5 style="padding:0; margin:1px;">تاريخ الميلاد: <?php echo $allinfo['student_dob']; ?></h5>
<h5 style="padding:0; margin:1px;">رقم الهوية: <?php echo $allinfo['national_id']; ?></h5>
<h5 style="padding:0; margin:1px;">تاريخ الالتحاق: <?php echo $allinfo['date_reg']; ?></h5>
</div>

<div class="col-xs-6">
<h5 style="padding:0; margin:1px;">الجنسية: <?php echo $country_list[$allinfo['nationality']]; ?></h5>

<h5 style="padding:0; margin:1px;">تاريخ التخرج: <?php echo $allinfo['date_exit']; ?></h5>
</div>

</div>


    <div style="margin-bottom:20px;" class="no-print">
<table class="tg">
  <th class="tg-i9x5"> <a style="color: white;" href="javascript:window.print()"> PRINT TRANSCRIPT OF RECORDS </a> </th>
</table>
</div>
<div class="row" style="margin-bottom:40px;">
<div class="col-xs-12" style="margin:0; padding:0;">
  
  <?php 
    $curr_id = $allinfo['curr_table']; 
    $major_id = $allinfo['major_id']; 
    $all_level_tot = array();
    
    $tollevel = mysql_fetch_array(mysql_query("SELECT levels from curr_detail where table_id = '$curr_id'"));
    

    for($j = 1; $j<= $tollevel[0]; $j++) {
  	  $level_no = '1'.$j;
  	  if($j == 1){
  		$test_date = mysql_fetch_array(mysql_query("SELECT level1_exam from batch_year where batch_year_id = ".$allinfo['batch_year_id']));
  		 echo ' الفصل التدريبي: الأول للعام التدريبي '.$test_date[0];
  	  } else if($j == 2){
  		$test_date = mysql_fetch_array(mysql_query("SELECT level2_exam from batch_year where batch_year_id = ".$allinfo['batch_year_id']));
  		 echo ' الفصل التدريبي: الثاني للعام التدريبي: '.$test_date[0];
  	  } else if($j == 3){
  		$test_date = mysql_fetch_array(mysql_query("SELECT level3_exam from batch_year where batch_year_id = ".$allinfo['batch_year_id']));
  		 echo ' الفصل التدريبي: الأول للعام التدريبي '.$test_date[0];
  	  } else if($j == 4){
  		$test_date = mysql_fetch_array(mysql_query("SELECT level4_exam from batch_year where batch_year_id = ".$allinfo['batch_year_id']));
  		 echo 'الفصل التدريبي: الثاني للعام التدريبي: '.$test_date[0];
  	  } else if($j == 5){
  		$test_date = mysql_fetch_array(mysql_query("SELECT level5_exam from batch_year where batch_year_id = ".$allinfo['batch_year_id']));
  		 echo 'Level 5 Test Date: '.$test_date[0];
  	  } 
  	  
	  ?>

<div style="margin-bottom:20px;">
<table class="tg">
  <tr>
    <th class="tg-i9x5" width="40">#</th>
    <th class="tg-i9x5" width="100">Code</th>
    <th class="tg-i9x5"> Course</th>
    <th class="tg-i9x5" width="80">Score</th>
    <th class="tg-i9x5" width="80">Credit</th>
    <th class="tg-i9x5" width="80">GPA</th>
    <th class="tg-i9x5" width="80">Points</th>
    <th class="tg-i9x5" width="80">Grade</th>
  </tr> 
      
<?php
	$curr_id = $allinfo['curr_id']; 
  $num_grade = 0; 
  $credit_hour = 0;
  $totalval = 0;
  
  $allcoursesquery = mysql_query("SELECT * FROM courses where level_no = '$level_no' and major_id = '$major_id' ");
  $i = 1;
  while($allcourses = mysql_fetch_assoc($allcoursesquery)) {
	$course_ref_no = $allcourses['course_ref_no'];
	$allmarks = mysql_fetch_array(mysql_query("SELECT let_grade, num_grade, is_fresh, table_id from marks where reg_id = '$reg_id' and course_ref_no = '$course_ref_no' and level_no = '$level_no'  and major_id = '$major_id' and pass_fail = 'Passed'"));
				
	$num_grade = $num_grade + $allmarks[1];
	$credit_hour = $credit_hour + $allcourses['credit_hour'];
	$gpa = scoretovalue($allmarks[1]);
	$totalval =  $totalval + ($allcourses['credit_hour']*$gpa);
	
  ?>
  
  <tr>
    <td class="tg-yw4l" style="text-align:right;"><?php echo $i; ?></td>
    <td class="tg-yw4l" style="text-align:center;"><?php echo $allcourses['course_code']; ?></td>
    <td class="tg-yw4l" style="text-align:center"><?php echo $allcourses['course_name']; ?></td>
    <td class="tg-yw4l"><?php echo $allmarks[1]; ?></td>
    <td class="tg-yw4l"><?php echo $allcourses['credit_hour'].'.0'; ?></td>
    <td class="tg-yw4l"><?php echo $gpa; ?></td>
    <td class="tg-yw4l"><?php echo $allcourses['credit_hour']*$gpa; ?></td>
     <td class="tg-yw4l"><?php echo strrev($allmarks[0]); ?></td>    
  </tr>
  
  <?php $i++; } ?>

 <tr>
    <th class="tg-i9x5"></th>
    <th class="tg-i9x5"></th>
    <th class="tg-i9x5"></th>
    <th class="tg-i9x5"></th>
    <th class="tg-i9x5"><?php echo $credit_hour.'.0'; ?></th>
    <th class="tg-i9x5"></th>
	  <th class="tg-i9x5"><?php echo $totalval; ?></th>
    <th class="tg-i9x5"></th>
  </tr>  
   <tr>
    <th class="tg-i9x5" colspan="2">Total</th>
	 <?php
    if ($totalval != 0) {
       $all_level_tot[] = $totalval/$credit_hour;
    }
   ?>
    <th class="tg-i9x5" colspan="6">
      <?php 
      if ($totalval !=0) {
    echo round($totalval/$credit_hour, 2);
      }
    

     ?></th>
  </tr>

  </table>
  </div>
	  <?php if($j == 3) { ?>
	  <div class="page-break"></div>
 <?php  } } ?>
 
<table class="tg">
 <tr>
    <th class="tg-i9x5">
  <?php 
  if (!empty($all_level_tot)) {
    echo ' المعدل الفصلي:  '.(round( (array_sum($all_level_tot)/count($all_level_tot)), 2)); 
  }
  ?>
  </th>
  </table>
  
  
  

 </div>
 </div>    
    
</div> 






<!-- Footer -->
<?php require('footer.php'); ?> 

</div>
</body>
</html>
