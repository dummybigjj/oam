<?php
if( isset($_SESSION['loginas']) && isset($_SESSION['email']) ) {
$loginas = $_SESSION['loginas'];
$emaillogin = $_SESSION['email'];
$loginvar = mysql_fetch_assoc(mysql_query("select * from users where email = '$emaillogin'"));
}
?>