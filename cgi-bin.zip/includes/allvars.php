<?php
$glomajor = array(
   '11'   =>   "Civil Technology", 		
   '12'   =>   "Surveying Technology",
   '13'   =>   "Oil & Gas Exploration Exploration Technology", 
   '14'   =>   "Mechanical Inspection & NDT",
   '0'   =>   "PREP",
   );
   

$batstart = array(
    '7'        =>   "Batch 2013 - January 2013", 
    '8'        =>   "Batch 2013 - September 2013", 
    '9'        =>   "Batch 2014 - January 2014", 
   '10'        =>   "Batch 2014 - September 2014", 
   '11'     	 =>   "Batch 2015 - January 2015", 
   '12'   	   =>   "Batch 2015 - September 2015", 		
   '13'   		 =>   "Batch 2016 - January 2016",
   '14'   		 =>   "Batch 2016 - September 2016", 
   '15'        =>   "Batch 2017 – January 2017", 
   '14'        =>   "Batch 2017 – September 2017", 
);


$curr4lvls = array(
   '11'     	=>   "Level 1", 
   '12'   		=>   "Level 2", 		
   '13'   		=>   "Level 3",
   '14'   		=>   "Level 4", 
   );
   
$curr5lvls = array(
   '11'     	=>   "Level 1", 
   '12'   		=>   "Level 2", 		
   '13'   		=>   "Level 3",
   '14'   		=>   "Level 4",
   '15'   		=>   "Level 5", 
   );
  
   
?>