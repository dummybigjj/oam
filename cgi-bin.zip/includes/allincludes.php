<?php
//error_reporting(0);
require_once("config.php");
require_once("switchstate.php");
require_once("includes/functions.php");
require_once("includes/allvars.php");
require_once("includes/globalvariables.php"); 

?>