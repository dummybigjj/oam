<?php
// To give the js alert message
function do_alert($msg) 
    {
        echo '<script type="text/javascript">alert("' . $msg . '"); </script>';
    }
// This is take to the next page
function nextpage($forward)
	{
		echo '<script type="text/javascript">window.location=("' . $forward . '"); </script>';
	}

//find the link in the text
function formatUrlsInText($text){
    $text = html_entity_decode($text);
        $text = " ".$text;
        
		$text = eregi_replace('(((f|ht){1}tp://)[-a-zA-Z0-9@:%_\+.~#?&//=]+)',
                '<a href="\\1" target=_blank>\\1</a>', $text);
		$text = eregi_replace('(((f|ht){1}tps://)[-a-zA-Z0-9@:%_\+.~#?&//=]+)',
                '<a href="\\1" target=_blank>\\1</a>', $text);
        $text = eregi_replace('([[:space:]()[{}])(www.[-a-zA-Z0-9@:%_\+.~#?&//=]+)',
        '\\1<a href="http://\\2" target=_blank>\\2</a>', $text);
        $text = eregi_replace('([_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3})',
        '<a href="mailto:\\1" target=_blank>\\1</a>', $text);
        return $text;
}

function lastuniqueid() {
	$lastid = mysql_fetch_array(mysql_query("SELECT last_reg_id FROM uniqueid ORDER BY last_reg_id DESC"));
	return $lastid[0];
}

function isactive($email) {
	$isactive = mysql_fetch_array(mysql_query("SELECT active FROM users where email = '$email'"));
	return $isactive[0];
}

function all_batches_to_register()
{
	$allavailbatchid = array();
	$allavailbatchname = array();
	$open_register_query = mysql_query("select * from batch_year where is_open_to_register = 'Yes' ORDER BY batch_year_id DESC");
		while($allval = mysql_fetch_assoc($open_register_query)) { 
		$allavailbatchid[] = $allval['batch_year_id'];
		$allavailbatchname[] = $allval['batch_name'];
 		}
	$allvalues = array_combine($allavailbatchid, $allavailbatchname);
	return $allvalues;
}

function all_batches_open()
{
	$allavailbatchid = array();
	$allavailbatchname = array();
	$open_register_query = mysql_query("select * from batch_year where is_open = 'Yes' ORDER BY batch_year_id DESC");
		while($allval = mysql_fetch_assoc($open_register_query)) { 
		$allavailbatchid[] = $allval['batch_year_id'];
		$allavailbatchname[] = $allval['batch_name'];
 		}
	$allvalues = array_combine($allavailbatchid, $allavailbatchname);
	return $allvalues;
}

function batch_name_from_id($batchid) {
	$batch_name = mysql_fetch_array(mysql_query("select batch_name from batch_year where batch_year_id = '$batchid'"));
	return($batch_name[0]);
}

function curr_name_from_id($currid) {
	$curr_name = mysql_fetch_array(mysql_query("select curr_name from curr_detail where curr_id = '$currid'"));
	return($curr_name[0]);
}

function all_curr_to_register()
{
	$allavailcurrid = array();
	$allavailcurrname = array();
	$open_register_query = mysql_query("select * from curr_detail where is_open_to_register = 'Yes'");
		while($allval = mysql_fetch_assoc($open_register_query)) { 
		$allavailcurrid[] = $allval['curr_id'];
		$allavailcurrname[] = $allval['curr_name'];
 		}
	$allvalues = array_combine($allavailcurrid, $allavailcurrname);
	return $allvalues;
}

function all_curr_data_complete()
{
	$allavailcurrid = array();
	$allavailcurrname = array();
	$open_register_query = mysql_query("select * from curr_detail where is_complete_data = 'Yes'");
		while($allval = mysql_fetch_assoc($open_register_query)) { 
		$allavailcurrid[] = $allval['curr_id'];
		$allavailcurrname[] = $allval['curr_name'];
 		}
	$allvalues = array_combine($allavailcurrid, $allavailcurrname);
	return $allvalues;
}

function scoretovalue($numgrade) {
		if( ($numgrade >= 95) && ($numgrade <= 100)){
				$lg = '5.0';
			} else if( ($numgrade >= 90) && ($numgrade < 95)){
				$lg = '4.5';
			} else if( ($numgrade >= 85) && ($numgrade < 90)){
				$lg = '4.0';
			} else if( ($numgrade >= 80) && ($numgrade < 85)){
				$lg = '3.5';
			} else if( ($numgrade >= 75) && ($numgrade < 80)){
				$lg = '3.0';
			} else if( ($numgrade >= 70) && ($numgrade < 75)){
				$lg = '2.5';
			} else if( ($numgrade >= 65) && ($numgrade < 70)){
				$lg = '2.0';		
			} else if( ($numgrade >= 60) && ($numgrade < 65)){
				$lg = '1.5';
			} else {
				$lg = '0';
			}
			
			return($lg);
}


?>