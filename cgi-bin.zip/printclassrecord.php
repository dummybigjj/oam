<?php 
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}
/**

$servername = "localhost";
$username = "root";
$password = "";

$pdo = new PDO("mysql:host=$servername;dbname=thiepapp", $username, $password);

**/

//var_dump($_POST);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>
  
	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<style type="text/css">
		@media print {
    	  body { font-size: 10pt }
		}
	  	@media screen {
	  	  body { font-size: 13px }
	  	}
	  	@media screen, print {
	  	  body { line-height: 1.2 }
	  	}
	</style>
</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 
<!-- All Bottom of the Header -->   
<div class="row">
<div class="container"  style="background-color: white;">
<h3 class="text-center"> COMPUTED FINAL GRADES </h3>
<h4>Course Code: 
	<?php 
	
		$subject = $_POST['subject'];
		$sql = "SELECT course_code, course_name FROM courses WHERE table_id = :subj ";
		$stmt = $pdo -> prepare($sql);
		$stmt -> bindParam(":subj", $subject);
		$stmt -> execute();
		$rowww = $stmt -> fetch();
		$subject = $rowww['course_code'] ?: "PREP-VOC";
		$course_name = $rowww['course_name'] ?: "";
		echo $subject;
?> </h4>
<h4>Course Name: <?php echo $course_name ?: "PREPARATORY VOCATIONAL"; ?> </h4>
<h4>Semester: <?php 
	$batch = $_POST['batchyear'];
	$major_id = $_POST['major'] ?: 0;
	if ($major_id != 0) {
		$sql = "SELECT batch_name FROM batch_year WHERE batch_year_id = :id ";
		$stmt = $pdo -> prepare($sql);
		$stmt -> bindParam(":id", $batch);
		$stmt -> execute();
		$rowww = $stmt -> fetch();
		$batch = $rowww['batch_name'];
		$first = substr($batch, 15, 1);
		$year = substr($batch, -4);
		//echo $first;
		if ($first === "J") {
			echo "First Semester $year";
		} else if ($first == "S") {
			echo "Second Semester $year";
		} else if ($first == "M") {
			echo "Summer $year";
		}

	} else {
		$sql = "SELECT batch_name FROM batch_year WHERE batch_year_id = :id ";
		$stmt = $pdo -> prepare($sql);
		$stmt -> bindParam(":id", $batch);
		$stmt -> execute();
		$rowww = $stmt -> fetch();
		$batch = $rowww['batch_name'];

		echo $batch;
	}
	?> </h4>
<table class="table table-bordered"> 
	<thead>
		<col>
		<colgroup span="2"></colgroup>
  		<colgroup span="2"></colgroup>
  	 <tr>
  	 	<td></td>
    	<td rowspan=""></td>
    	<th colspan="1" scope="colgroup">TERM WORK</th>    	
    	<th colspan="2" scope="colgroup">MAJOR EXAMS</th>
    	
     </tr>
  	 <tr>
  	 	<td></td>
    	<td rowspan=""></td>    	
    	<th colspan="" scope="colgroup">CW</th>
    	<th colspan="" scope="colgroup">WA</th>
    	<th colspan="" scope="colgroup">ME</th>
    	<th colspan="" scope="colgroup">FE</th>
    	<th colspan="4" scope='colgroup ' class="text-center">  COMPUTED GRADE   	</th>
     </tr>
	 <tr>
		<th> National ID</th>
		<th> Students </th>		
		<th> 30% </th>
		<th> 30%</th>
		<th> 40%	</th>
		<th> NG</th>
		<th> LG </th>
		<th> REMARKS </th>
	 </tr>
	</thead>
	<tbody>
		<?php 
			if (isset($_POST['classgrade'])) {
				/**
				if (!empty($_POST['curr_id'])) {
					$curr_id = $_POST['curr_id'];
				} else {
					$curr_id = 0;
				}**/
				
				$curr_id = $_POST['curr_id'];
				$batch = $_POST['batchyear'];
				$major = $_POST['major'];
				if ($major == 0) {
					//$curr_id = 0;
				}
				$subject = $_POST['subject'] ?: 0;

				//var_dump($_POST);

				$sql = "SELECT students.english_name, national_id, attendence
				, class_work, midterm, finalexam, num_grade, let_grade, pass_fail FROM `marks` LEFT JOIN students ON marks.reg_id = students.reg_id WHERE marks.curr_table_id = :curr_id AND marks.batch_year_id = :batch AND marks.major_id = :major AND course_ref_no = :sub";
				$stmt = $pdo -> prepare($sql);
				$stmt -> bindParam(":curr_id", $curr_id);
				$stmt -> bindParam(":batch", $batch );
				$stmt -> bindParam(":major", $major);
				$stmt -> bindParam(":sub", $subject);
				$stmt -> execute();
				$count = $stmt -> rowCount();

				if ($count > 0) {
					
					while ($row = $stmt -> fetch()) {
						$name = $row['english_name'];
						$cwork = $row['class_work'];
						$attendence = $row['attendence'];
						$md = $row['midterm'];
						$fe = $row['finalexam'];
						$num_grade = $row['num_grade'];
						$let_grade = $row['let_grade'];
						$pass_fail = $row['pass_fail'];
						$national_id = $row['national_id'];
						if ($pass_fail == "Fail") {
							$pass_fail = "Failed";
						} else {

						}
						echo " 
							<tr>
								<td>$national_id</td>
								<td>$name</td>								
								<td> $cwork </td>
								<td> $attendence </td>
								<td>$md</td>
								<td>$fe</td>
								<td><b>$num_grade</b></td>
								<td><b>$let_grade</b></td>
								<td>$pass_fail</td>
							</tr>
						";
					
					}
				} else {
					//echo " <tr> <td> NO ITEMS </td></tr>";
					do_alert("No grades encoded yet");
					//nextpage("classrecord.php");
				}
			}

		?>
	</tbody>
</table>

</div>
<div class="container" style="padding-bottom: ; background-color: white;">
	<!--
	<h4>Legends: </h4>
	<p style="padding-left: 20px;"> <b> ES</b> ENROLLED STUDENTS <br>
		<b> AT</b> ATTENDANCE <br>
		<b> CW</b> CLASS WORK <br>
		<b> ME</b> MIDTERM EXAMS <br>
		<b> FE</b> FINAL EXAMS <br>
		<b> NG</b> NUMERICAL GRADE <br>
		<b> LG</b> LETTER GRADE <br>
	</p>
	-->
	<div class="row-fluid">
		<div class="col-md-3 col-xs-3 col-sm-2 text-center">
			________________<br>
			Instructor
		</div>
		<div class="col-md-2 col-xs-3 col-sm-2 text-center">
			<?php 

				$major = $_POST['major'] ?: 0;
				if ($major == 0) {
					echo "	<b>Mr. Marlon Bravo</b> ";
				} else if ($major == 11) {
					echo "	<b>Mr. Fredel J. De Vera </b> ";
				} else if ($major == 14) {
					echo "	<b>Mr. Akbhar Khan</b> ";
				}
			?>
		<br>
			Department Head
		</div>
		<div class="col-md-3 col-xs-3 col-sm-2 text-center">
			________________<br>
			Registrar
		</div>
		<div class="col-md-2 col-xs-2 col-sm-2 text-center">
			<b>Dr. Firras Kassem </b><br>
			DEPUTY MANAGER
		</div>
	</div>
	
</div>
</div> 

<div class="no-print container" style="padding-bottom: 100px; padding-top: 30px;">
	<button class="btn btn-success btn-lg pull-right" onclick="window.print();"> PRINT</button>
</div>

<!-- Footer -->
<?php require('footer.php'); ?> 

</div>
</body>
</html>
