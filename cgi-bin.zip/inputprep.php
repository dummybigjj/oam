<?php
session_start();

require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}
error_reporting(E_ALL);
ini_set('display_errors', '1');


//http://localhost:8012/thiepapp/CourseRecord.php?need=enter&curr=1&level=12&major=12&batchid=14&courid=20
if( count($_GET) < 3 ) {
	do_alert("Error");
	header("location: index.php");
	exit;
} else {
	$curr_id = mysql_real_escape_string($_GET['curr']);
  
	$major_id = 0;
	$batch_year_id = mysql_real_escape_string($_GET['batchid']);
  $table_id = mysql_real_escape_string($_GET['table_id']);
	//$level_no = mysql_real_escape_string($_GET['level']);
	//$course_ref_no = mysql_real_escape_string($_GET['courid']);
	
	$allstu_query = mysql_query("SELECT * FROM students WHERE curr_table = '$table_id' AND major_id = '$major_id' AND batch_year_id = '$batch_year_id' AND is_active = 'Yes'");
	//var_dump($_GET);
	if(mysql_num_rows($allstu_query) < 1) {
		do_alert("No student registered yet or information doesn't exist");
		//nextpage("index.php");
		exit;
	}
	
}


if (isset($_POST['submit_grade'])) {
  $total = $_POST['total'];
  //var_dump($_POST);
  $curr_id = mysql_real_escape_string($_GET['curr']);
  $major_id = mysql_real_escape_string($_GET['major']);
  $batch_year_id = mysql_real_escape_string($_GET['batchid']);
  $level_no = 0;
  $course_ref_no = 0;
  $table_id = mysql_real_escape_string($_GET['table_id']);


  if ($curr_id == 1) {
    for ($i= 1; $i < $total; $i++) { 
    
     $mark_id = $_POST['mark_id'.$i];
     $attendence = $_POST['attendence_'.$i];
     $cw = $_POST['cw_'.$i];
     $me = $_POST['me_'.$i];
     $fe = $_POST['fe_'.$i];
     $reg_id = $_POST['reg_id'.$i]; 

     $numgrade = $attendence + $cw + $me + $fe;
   
      if (($numgrade >= 95) && ($numgrade <= 100)){
            $lg = 'A+';
          } else if( ($numgrade >= 90) && ($numgrade < 95)){
              $lg = 'A';
          } else if( ($numgrade >= 85) && ($numgrade < 90)){
              $lg = 'B+';
          } else if( ($numgrade >= 80) && ($numgrade < 85)){
              $lg = 'B';
          } else if( ($numgrade >= 75) && ($numgrade < 80)){
              $lg = 'C+';
          } else if( ($numgrade >= 70) && ($numgrade < 75)){
              $lg = 'C';
          } else if( ($numgrade >= 65) && ($numgrade < 70)){
              $lg = 'D+';   
          } else if( ($numgrade >= 60) && ($numgrade < 65)){
              $lg = 'D';
          } else {
              $lg = 'F';
      }
      
      if($numgrade < 60){
        $pass_fail = 'Fail';
        } else {
        $pass_fail = 'Passed';
      }
    //echo "Mark: ".$mark_id;
    if ($mark_id == 0 ) {
        //echo "Mark ID: ".$_POST['mark_id'.$i];
        
        
        if (!empty($cw) || !empty($me) || !empty($fe)) {
        $is_fresh = "Yes";
        $entry_user_full_name = 'Alvin Desalva';
        $entry_time = date("U");
        $batch_year_id = mysql_real_escape_string($_GET['batchid']);   
        $table_id = mysql_real_escape_string($_GET['table_id']);

        $sql = "INSERT INTO marks (course_ref_no, curr_table_id, reg_id, batch_year_id, level_no, major_id, curr_id, attendence, class_work, midterm, finalexam, num_grade, let_grade, pass_fail, is_fresh, entry_time, entry_user_full_name) 
        VALUES  (:course, :curr_table_id, :reg_id, :batchid, :level_no, :major_id, :curr_id, :attendence, :class_work, :midterm, :finalexam, :numgrade, :let_grade, :pass_fail, :is_fresh, :entry_time, :entry_user_full_name) ";      
        $stmt = $pdo -> prepare($sql);
        $stmt -> bindParam(":course", $course_ref_no);
        $stmt -> bindParam(":curr_table_id", $table_id);
        $stmt -> bindParam(":reg_id", $reg_id);
        $stmt -> bindParam(":batchid", $batch_year_id);
        $stmt -> bindParam(":level_no", $level_no);
        $stmt -> bindParam(":major_id", $major_id);
        $stmt -> bindParam(":curr_id", $curr_id);
        $stmt -> bindParam(":attendence", $attendence);
        $stmt -> bindParam(":class_work", $cw);
        $stmt -> bindParam(":midterm", $me);
        $stmt -> bindParam(":finalexam", $fe);
        $stmt -> bindParam(":numgrade", $numgrade);
        $stmt -> bindParam(":let_grade", $lg);
        $stmt -> bindParam(":pass_fail", $pass_fail);
        $stmt -> bindParam(":is_fresh", $is_fresh);
        $stmt -> bindParam(":entry_time", $entry_time);
        $stmt -> bindParam(":entry_user_full_name", $entry_user_full_name);
        $stmt -> execute();      
        }
         
    } else if ($mark_id > 0 && !empty($cw) || !empty($me) || !empty($fe) ) {
        //$mark_id = $_POST['mark_id'.$i] ?: 0;
        $sql = "SELECT * FROM marks WHERE table_id = :table_id AND attendence = :attendence AND class_work = :class_work AND midterm = :midterm AND finalexam = :finalexam AND num_grade = :numgrade AND let_grade = :let_grade AND pass_fail = :pass_fail";
        $stmt = $pdo -> prepare($sql);
        $stmt -> bindParam(":table_id", $mark_id);
        $stmt -> bindParam(":attendence", $attendence);
        $stmt -> bindParam(":class_work", $cw);
        $stmt -> bindParam(":midterm", $me);
        $stmt -> bindParam(":finalexam", $fe);
        $stmt -> bindParam(":numgrade", $numgrade);
        $stmt -> bindParam(":let_grade", $lg);
        $stmt -> bindParam(":pass_fail", $pass_fail);
        $stmt -> execute();
        $count = $stmt -> rowCount();
        $row = $stmt -> fetch();
        $table_id = $row['table_id'];
        $reg_id = $row['reg_id'];
        if ($count > 0) {
          //same grades        
        } else {
          //echo "UPDATE";
          $is_fresh = "Yes";
          //$exam_required = $testneed;                  
          $entry_user_full_name = 'Alvin Desalva';
          $entry_time = date("U");
          $batch_year_id = mysql_real_escape_string($_GET['batchid']);
        
          $sql = "UPDATE marks SET attendence = :attendence, class_work = :class_work, midterm = :midterm, finalexam = :finalexam, num_grade = :numgrade, let_grade = :let_grade, pass_fail = :pass_fail, is_fresh = :is_fresh WHERE table_id = :table_id ";  
          $pdo ->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING );
          $stmt = $pdo -> prepare($sql);
          $stmt -> bindParam(":attendence", $attendence);
          $stmt -> bindParam(":class_work", $cw);
          $stmt -> bindParam(":midterm", $me);
          $stmt -> bindParam(":finalexam", $fe);
          $stmt -> bindParam(":numgrade", $numgrade);
          $stmt -> bindParam(":let_grade", $lg);
          $stmt -> bindParam(":pass_fail", $pass_fail);
          $stmt -> bindParam(":is_fresh", $is_fresh);
          $stmt -> bindParam(":table_id", $mark_id);
          if ($stmt -> execute()) {
            # code...
          } else {
            //echo "something went wrong <br>";
             //print_r($pdo->errorInfo());
          }
        }    
        
    }
      
  } 
  } else if ($curr_id == 2) {
      for ($i= 1; $i < $total; $i++) { 
     $level_no = 20;
     $mark_id = $_POST['mark_id'.$i];
     $attendence = $_POST['attendence_'.$i];
     $cw = $_POST['cw_'.$i];
     $me = $_POST['me_'.$i];
     $fe = $_POST['fe_'.$i];
     $reg_id = $_POST['reg_id'.$i]; 

     $numgrade = $attendence + $cw + $me + $fe;
   
      if (($numgrade >= 95) && ($numgrade <= 100)){
            $lg = 'A+';
          } else if( ($numgrade >= 90) && ($numgrade < 95)){
              $lg = 'A';
          } else if( ($numgrade >= 85) && ($numgrade < 90)){
              $lg = 'B+';
          } else if( ($numgrade >= 80) && ($numgrade < 85)){
              $lg = 'B';
          } else if( ($numgrade >= 75) && ($numgrade < 80)){
              $lg = 'C+';
          } else if( ($numgrade >= 70) && ($numgrade < 75)){
              $lg = 'C';
          } else if( ($numgrade >= 65) && ($numgrade < 70)){
              $lg = 'D+';   
          } else if( ($numgrade >= 60) && ($numgrade < 65)){
              $lg = 'D';
          } else {
              $lg = 'F';
      }
      
      if($numgrade < 60){
        $pass_fail = 'Fail';
        } else {
        $pass_fail = 'Passed';
      }
    //echo "Mark: ".$mark_id;
    if ($mark_id == 0 ) {
        //echo "Mark ID: ".$_POST['mark_id'.$i];
        
        
        if (!empty($cw) || !empty($me) || !empty($fe)) {
        $is_fresh = "Yes";
        $entry_user_full_name = 'Alvin Desalva';
        $entry_time = date("U");
        $batch_year_id = mysql_real_escape_string($_GET['batchid']);   
        $table_id = mysql_real_escape_string($_GET['table_id']);

        $sql = "INSERT INTO marks (course_ref_no, curr_table_id, reg_id, batch_year_id, level_no, major_id, curr_id, attendence, class_work, midterm, finalexam, num_grade, let_grade, pass_fail, is_fresh, entry_time, entry_user_full_name) 
        VALUES  (:course, :curr_table_id, :reg_id, :batchid, :level_no, :major_id, :curr_id, :attendence, :class_work, :midterm, :finalexam, :numgrade, :let_grade, :pass_fail, :is_fresh, :entry_time, :entry_user_full_name) ";      
        $stmt = $pdo -> prepare($sql);
        $stmt -> bindParam(":course", $course_ref_no);
        $stmt -> bindParam(":curr_table_id", $table_id);
        $stmt -> bindParam(":reg_id", $reg_id);
        $stmt -> bindParam(":batchid", $batch_year_id);
        $stmt -> bindParam(":level_no", $level_no);
        $stmt -> bindParam(":major_id", $major_id);
        $stmt -> bindParam(":curr_id", $curr_id);
        $stmt -> bindParam(":attendence", $attendence);
        $stmt -> bindParam(":class_work", $cw);
        $stmt -> bindParam(":midterm", $me);
        $stmt -> bindParam(":finalexam", $fe);
        $stmt -> bindParam(":numgrade", $numgrade);
        $stmt -> bindParam(":let_grade", $lg);
        $stmt -> bindParam(":pass_fail", $pass_fail);
        $stmt -> bindParam(":is_fresh", $is_fresh);
        $stmt -> bindParam(":entry_time", $entry_time);
        $stmt -> bindParam(":entry_user_full_name", $entry_user_full_name);
        $stmt -> execute();      
        }         
    } else if ($mark_id > 0 && !empty($cw) || !empty($me) || !empty($fe) ) {
        //$mark_id = $_POST['mark_id'.$i] ?: 0;
        $sql = "SELECT * FROM marks WHERE table_id = :table_id AND level_no = :level_no AND attendence = :attendence AND class_work = :class_work AND midterm = :midterm AND finalexam = :finalexam AND num_grade = :numgrade AND let_grade = :let_grade AND pass_fail = :pass_fail";
        $stmt = $pdo -> prepare($sql);
        $stmt -> bindParam(":table_id", $mark_id);
        $stmt -> bindParam(":level_no", $level_no);
        $stmt -> bindParam(":attendence", $attendence);
        $stmt -> bindParam(":class_work", $cw);
        $stmt -> bindParam(":midterm", $me);
        $stmt -> bindParam(":finalexam", $fe);
        $stmt -> bindParam(":numgrade", $numgrade);
        $stmt -> bindParam(":let_grade", $lg);
        $stmt -> bindParam(":pass_fail", $pass_fail);
        $stmt -> execute();
        $count = $stmt -> rowCount();
        $row = $stmt -> fetch();
        $table_id = $row['table_id'];
        $reg_id = $row['reg_id'];
        if ($count > 0) {
          //same grades        
        } else {
          //echo "UPDATE";
          $is_fresh = "Yes";
          //$exam_required = $testneed;                  
          $entry_user_full_name = 'Alvin Desalva';
          $entry_time = date("U");
          $batch_year_id = mysql_real_escape_string($_GET['batchid']);
        
          $sql = "UPDATE marks SET attendence = :attendence, class_work = :class_work, midterm = :midterm, finalexam = :finalexam, num_grade = :numgrade, let_grade = :let_grade, pass_fail = :pass_fail, is_fresh = :is_fresh WHERE table_id = :table_id ";  
          $pdo ->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING );
          $stmt = $pdo -> prepare($sql);
          $stmt -> bindParam(":attendence", $attendence);
          $stmt -> bindParam(":class_work", $cw);
          $stmt -> bindParam(":midterm", $me);
          $stmt -> bindParam(":finalexam", $fe);
          $stmt -> bindParam(":numgrade", $numgrade);
          $stmt -> bindParam(":let_grade", $lg);
          $stmt -> bindParam(":pass_fail", $pass_fail);
          $stmt -> bindParam(":is_fresh", $is_fresh);
          $stmt -> bindParam(":table_id", $mark_id);
          if ($stmt -> execute()) {
            # code...
          } else {
            //echo "something went wrong <br>";
             //print_r($pdo->errorInfo());
          }
        }    
        
    }
      
  } 
  }
  

  $curr_id = mysql_real_escape_string($_GET['curr']);
  $major_id = mysql_real_escape_string($_GET['major']);
  $batch_year_id = mysql_real_escape_string($_GET['batchid']);  
  $course_ref_no = 0;
  $table_id = mysql_real_escape_string($_GET['table_id']);

  do_alert("Marks Entered.");
  nextpage("inputprep.php?table_id=$table_id&curr=$curr_id&major=$major_id&batchid=$batch_year_id.php");

}



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>
  
	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 

<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:10px;">

        <div class="col-xs-12" style="margin:0; padding:0;">
          <div class="boxback titlebox">
             <h4>PREP </h4><h5><?php echo 'Batch: '.batch_name_from_id($batch_year_id).', '.' Course Record'; ?></h5>
				
				</div>
        </div>
</div>
			 
<div class="row" style="margin-bottom:40px;">
                <div class="col-xs-12" style="margin:0; padding:0;">				 
				
				<div style="margin-bottom:10px;">
				
				

<table class="tg">
 <tr>
    <th class="tg-i9x5" colspan="2">Fresh Attempt</th>
    </tr>
  <tr>

    <th class="tg-i9x5">#</th>
    <th class="tg-i9x5" style="width:130px;">National ID</th>
    <th class="tg-i9x5">Student Name</th>
    <th class="tg-i9x5">CW</th>
    <th class="tg-i9x5">WA</th>
    <th class="tg-i9x5">ME</th>
    <th class="tg-i9x5">FE</th>
  </tr>
  <form method="POST">
   <?php 
   	  
       $sql = "SELECT * FROM students WHERE curr_table = :table AND major_id = :major_id AND batch_year_id = :batchid AND is_active = 'Yes'";
       $stmt = $pdo -> prepare($sql);
       $stmt -> bindParam(":table", $table_id);
       $stmt -> bindParam(":major_id", $major_id);
       //$stmt -> bindParam(":curr_id", $curr_id);
       $stmt -> bindParam(":batchid", $batch_year_id);
       $stmt -> execute();

       $i = 1;
       while($row = $stmt -> fetch()) {  
       $reg_id = $row['reg_id'];
       $std_name = $row['english_name'];
       $level_no = 0;
       $course_ref_no = 0;
    	 $stu_mar_query = mysql_query("SELECT * from marks where curr_table_id = '$table_id' AND reg_id = '$reg_id' and course_ref_no = '$course_ref_no' and curr_id = '$curr_id' and major_id = '$major_id' and is_fresh = 'Yes'");

    	$stu_mar = mysql_fetch_assoc($stu_mar_query);
       $attendence = $stu_mar['attendence'];
       $md = $stu_mar['midterm'];
       $fe = $stu_mar['finalexam'];       
       $class_work = $stu_mar['class_work'];
       $mark_id = $stu_mar['table_id'];
       echo "
          <tr>
            <input type='hidden' name='mark_id$i' value='$mark_id' /> 
            <td> $i </td>
            <td>$reg_id</td>
            <input type='hidden' name='reg_id$i' value='$reg_id' /> 
            <td>$std_name</td>
            <td> <input type='text' id='subject_$i' class='form-control' name='cw_$i' value='$class_work'  /> </td>
            <td> <input type='text' id='subject_$i' class='form-control' name='attendence_$i' value='$attendence'  /> </td>            
            <td> <input type='text' id='subject_$i' class='form-control' name='me_$i' value='$md'  /> </td>
            <td> <input type='text' id='subject_$i' class='form-control' name='fe_$i' value='$fe'  /> </td>     
          </tr>
       ";
       $i++;

       }
       echo "<input type='hidden' name='total' value='$i' /> ";
	?>


  </table>
  <br>
	<button class="btn btn-success pull-right btn-lg" name="submit_grade" type="submit"> Submit Grades</button>
</form>
<br>
 </div>
               
				
 <div class="col-xs-4" style="margin:0; padding:0;">
 <div style="margin-bottom:10px;">
 <table class="tg" style="margin:0; padding:0;">
  <tr>
    <th class="tg-i9x5" colspan="2">Legends</th>
    <th class="tg-i9x5">Max Marks</th>
  </tr>
  <tr>
    <td class="tg-yw4l">CW</td>
    <td class="tg-yw4l" style="text-align:left;">Attendence / Class Work</td>
    <td class="tg-yw4l">30</td>
  </tr>
  <tr>
    <td class="tg-yw4l">ME</td>
    <td class="tg-yw4l" style="text-align:left;">Midterm Exam</td>
    <td class="tg-yw4l">30</td>
  </tr>
  <tr>
    <td class="tg-yw4l">FE</td>
    <td class="tg-yw4l" style="text-align:left;">Final Exam</td>
    <td class="tg-yw4l">40</td>
  </tr>
  <tr>
    <td class="tg-yw4l">NG</td>
    <td class="tg-yw4l" style="text-align:left;">Numerical Grade</td>
    <td class="tg-yw4l">100</td>
  </tr>
   <tr>
    <td class="tg-yw4l">LG</td>
    <td class="tg-yw4l" style="text-align:left;">Letter Grade</td>
    <td class="tg-yw4l">A+</td>
  </tr>
</table>
</div>
 </div>

			   </div> 
                
                
				</div>


</div> 


<!-- Footer -->
<?php require('footer.php'); ?> 

</div>

  
</body>
</html>
