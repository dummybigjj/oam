-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2016 at 09:50 PM
-- Server version: 5.6.26
-- PHP Version: 5.5.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thiepapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `batch_year`
--

CREATE TABLE IF NOT EXISTS `batch_year` (
  `table_id` int(7) NOT NULL,
  `batch_year_id` int(7) NOT NULL,
  `batch_name` varchar(100) COLLATE utf8_bin NOT NULL,
  `is_open` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT 'Yes',
  `is_open_to_register` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT 'Yes',
  `level1_exam` varchar(256) COLLATE utf8_bin NOT NULL,
  `level2_exam` varchar(256) COLLATE utf8_bin NOT NULL,
  `level3_exam` varchar(256) COLLATE utf8_bin NOT NULL,
  `level4_exam` varchar(256) COLLATE utf8_bin NOT NULL,
  `level5_exam` varchar(256) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `batch_year`
--

INSERT INTO `batch_year` (`table_id`, `batch_year_id`, `batch_name`, `is_open`, `is_open_to_register`, `level1_exam`, `level2_exam`, `level3_exam`, `level4_exam`, `level5_exam`) VALUES
(1, 11, 'Jan 2014', 'Yes', 'Yes', '2/1/1462', '2/2/1463', '3/3/1464', '4/4/1466', '5/5/1467'),
(2, 12, 'Sep 2014', 'Yes', 'Yes', '4/4/1464', '5/5/1475', '6/6/1466', '7/7/1467', '8/8/1468'),
(4, 13, 'Jan 2015', 'Yes', 'Yes', '1/1/1479', '1/1/1480', '1/1/1480', '1/10/1480', '1/1/1479'),
(5, 14, 'Sep 2015', 'Yes', 'Yes', '2/1/1462', '2/2/1463', '3/3/1464', '4/4/1466', '5/5/1467'),
(6, 15, 'Jan 2016', 'Yes', 'Yes', '2/1/1462', '2/2/1463', '3/3/1464', '4/4/1466', '5/5/1467'),
(29, 16, 'Sep 2016', 'Yes', 'Yes', '1/1/1471', '2/2/1462', '3/3/1463', '4/4/1464', '5/5/1475'),
(30, 17, 'Jan 2017', 'Yes', 'Yes', '2/2/1472', '3/3/1473', '4/4/1474', '5/5/1475', '6/6/1476');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
  `table_id` int(14) NOT NULL,
  `course_ref_no` int(8) NOT NULL,
  `course_code` varchar(40) COLLATE utf8_bin NOT NULL,
  `course_name` varchar(100) COLLATE utf8_bin NOT NULL,
  `credit_hour` int(1) NOT NULL,
  `level_no` int(2) NOT NULL,
  `curr_id` int(4) NOT NULL,
  `major_id` int(2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`table_id`, `course_ref_no`, `course_code`, `course_name`, `credit_hour`, `level_no`, `curr_id`, `major_id`) VALUES
(59, 8, 'SBH 123', 'SUBJECT ONE', 8, 11, 1, 13),
(60, 9, 'SCI 3', 'SUBJECT TWO', 5, 11, 1, 13),
(61, 10, 'SUB 3', 'SUBJECT THREE', 3, 11, 1, 13),
(62, 11, 'SBH 123', 'SUBJECT ONE', 4, 11, 1, 14),
(63, 12, 'SCI 3', 'SUBJECT TWO', 5, 11, 1, 14),
(64, 13, 'SUB 3', 'SUBJECT THREE', 3, 11, 1, 14),
(65, 14, 'SBH 123', 'SUBJECT ONE', 4, 12, 1, 14),
(66, 15, 'SCI 3', 'SUBJECT TWO', 5, 12, 1, 14),
(67, 16, 'SUB 3', 'SUBJECT THREE', 3, 12, 1, 14),
(68, 17, 'SBH 123', 'SUBJECT ONE', 4, 14, 1, 14),
(69, 18, 'SCI 3', 'SUBJECT TWO', 5, 14, 1, 14),
(70, 19, 'SUB 3', 'SUBJECT THREE', 3, 14, 1, 14),
(71, 20, 'SBH 123', 'SUBJECT ONE', 1, 12, 1, 12),
(72, 21, 'SCI 3', 'SUBJECT TWO', 5, 12, 1, 12),
(73, 22, 'SUB 3', 'SUBJECT THREE', 3, 12, 1, 12),
(74, 23, 'SBH 123', 'SUBJECT ONE', 3, 11, 1, 12),
(75, 24, 'SCI 3', 'SUBJECT TWO', 5, 11, 1, 12),
(76, 25, 'SUB 3', 'SUBJECT THREE', 3, 11, 1, 12),
(77, 26, 'SBH 123', 'SUBJECT ONE', 4, 13, 1, 11),
(78, 27, 'SCI 3', 'SUBJECT TWO', 5, 13, 1, 11),
(79, 28, 'SUB 3', 'SUBJECT THREE', 3, 13, 1, 11),
(83, 32, 'SBH 123', 'SUBJECT ONE', 4, 13, 1, 13),
(84, 33, 'SCI 3', 'SUBJECT TWO', 5, 13, 1, 13),
(85, 34, 'SUB 3', 'SUBJECT THREE', 3, 13, 1, 13),
(86, 35, 'SBH 123', 'SUBJECT ONE', 4, 12, 1, 13),
(87, 36, 'SCI 3', 'SUBJECT TWO', 5, 12, 1, 13),
(88, 37, 'SUB 3', 'SUBJECT THREE', 3, 12, 1, 13),
(89, 38, 'SBH 123', 'SUBJECT ONE', 4, 13, 1, 14),
(90, 39, 'SCI 3', 'SUBJECT TWO', 5, 13, 1, 14),
(91, 40, 'SUB 3', 'SUBJECT THREE', 3, 13, 1, 14),
(92, 41, 'SBH 123', 'SUBJECT ONE', 4, 14, 1, 13),
(93, 42, 'SCI 3', 'SUBJECT TWO', 5, 14, 1, 13),
(94, 43, 'SUB 3', 'SUBJECT THREE', 3, 14, 1, 13),
(95, 44, 'SBH 123', 'SUBJECT ONE', 4, 13, 1, 12),
(96, 45, 'SUB 3', 'SUBJECT THREE', 3, 13, 1, 12),
(97, 46, 'CODE 10', 'SUBJECT TEN', 1, 13, 1, 12),
(98, 47, 'SCI 3', 'SUBJECT TWO', 5, 14, 1, 11),
(99, 48, 'SUB 3', 'SUBJECT THREE', 3, 14, 1, 11),
(100, 49, 'CODE 10', 'SUBJECT TEN', 2, 14, 1, 11),
(101, 50, 'SBH 123', 'SUBJECT ONE', 4, 14, 1, 12),
(102, 51, 'SCI 3', 'SUBJECT TWO', 5, 14, 1, 12),
(103, 52, 'SUB 3', 'SUBJECT THREE', 3, 14, 1, 12),
(104, 53, 'SBH 123', 'SUBJECT ONE', 3, 12, 1, 11),
(105, 54, 'SCI 3', 'SUBJECT TWO', 5, 12, 1, 11),
(106, 55, 'SUB 3', 'SUBJECT THREE', 3, 12, 1, 11),
(107, 56, 'SUB 09', 'SUBJECT 9', 5, 12, 1, 11),
(108, 57, 'SBH 123', 'SUBJECT ONE', 7, 11, 1, 11),
(109, 58, 'SCI 3', 'SUBJECT TWO', 5, 11, 1, 11),
(110, 59, 'SUB 3', 'SUBJECT THREE', 3, 11, 1, 11);

-- --------------------------------------------------------

--
-- Table structure for table `curr_detail`
--

CREATE TABLE IF NOT EXISTS `curr_detail` (
  `table_id` int(4) NOT NULL,
  `curr_name` varchar(100) COLLATE utf8_bin NOT NULL,
  `curr_id` int(4) NOT NULL,
  `levels` int(2) NOT NULL,
  `is_user_mark_entry` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT 'No',
  `is_open_to_register` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT 'No',
  `is_complete_data` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT 'No',
  `entry_time` int(16) NOT NULL,
  `entry_user_full_name` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `curr_detail`
--

INSERT INTO `curr_detail` (`table_id`, `curr_name`, `curr_id`, `levels`, `is_user_mark_entry`, `is_open_to_register`, `is_complete_data`, `entry_time`, `entry_user_full_name`) VALUES
(30, 'LEVEL 4 FOR NEW BATCH', 1, 4, 'Yes', 'Yes', 'Yes', 1454153232, 'Alvin Desalva'),
(32, 'Curr 5 Starts on 2016', 2, 5, 'Yes', 'Yes', 'Yes', 1455565549, 'Alvin Desalva');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE IF NOT EXISTS `marks` (
  `table_id` int(14) NOT NULL,
  `course_ref_no` int(8) NOT NULL,
  `reg_id` int(7) NOT NULL,
  `level_no` int(2) NOT NULL,
  `curr_id` int(4) NOT NULL,
  `major_id` int(2) NOT NULL,
  `batch_year_id` int(7) NOT NULL,
  `attendence` int(2) NOT NULL,
  `class_work` int(2) NOT NULL,
  `midterm` int(2) NOT NULL,
  `finalexam` int(2) NOT NULL,
  `num_grade` int(3) NOT NULL,
  `let_grade` varchar(5) COLLATE utf8_bin NOT NULL,
  `pass_fail` varchar(10) COLLATE utf8_bin NOT NULL,
  `is_fresh` varchar(10) COLLATE utf8_bin NOT NULL,
  `entry_time` int(16) NOT NULL,
  `edit_time` int(16) NOT NULL,
  `entry_user_full_name` varchar(100) COLLATE utf8_bin NOT NULL,
  `edit_user_full_name` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`table_id`, `course_ref_no`, `reg_id`, `level_no`, `curr_id`, `major_id`, `batch_year_id`, `attendence`, `class_work`, `midterm`, `finalexam`, `num_grade`, `let_grade`, `pass_fail`, `is_fresh`, `entry_time`, `edit_time`, `entry_user_full_name`, `edit_user_full_name`) VALUES
(18, 22, 1000004, 12, 1, 12, 14, 2, 5, 5, 6, 18, 'F', 'Fail', 'Yes', 1454695198, 0, 'Alvin Desalva', ''),
(23, 22, 1000003, 12, 1, 12, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'Yes', 1454709375, 0, 'Alvin Desalva', ''),
(24, 22, 1000006, 12, 1, 12, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1454709399, 0, 'Alvin Desalva', ''),
(25, 22, 1000007, 12, 1, 12, 14, 2, 5, 4, 40, 51, 'F', 'Fail', 'Yes', 1454709428, 0, 'Alvin Desalva', ''),
(26, 25, 1000006, 11, 1, 12, 14, 10, 20, 15, 30, 75, 'C+', 'Passed', 'Yes', 1454709482, 0, 'Alvin Desalva', ''),
(27, 25, 1000003, 11, 1, 12, 14, 10, 15, 20, 25, 70, 'C', 'Passed', 'Yes', 1454710027, 0, 'Alvin Desalva', ''),
(29, 25, 1000007, 11, 1, 12, 14, 2, 4, 5, 6, 17, 'F', 'Fail', 'Yes', 1454710125, 0, 'Alvin Desalva', ''),
(30, 23, 1000006, 11, 1, 12, 14, 2, 15, 20, 20, 57, 'F', 'Fail', 'Yes', 1454754497, 0, 'Alvin Desalva', ''),
(31, 23, 1000003, 11, 1, 12, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'Yes', 1454754553, 0, 'Alvin Desalva', ''),
(32, 24, 1000003, 11, 1, 12, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'Yes', 1454761902, 0, 'Alvin Desalva', ''),
(34, 23, 1000007, 11, 1, 12, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'Yes', 1454762208, 0, 'Alvin Desalva', ''),
(36, 58, 1000000, 11, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'Yes', 1454873325, 0, 'Alvin Desalva', ''),
(37, 59, 1000000, 11, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'Yes', 1454873342, 0, 'Alvin Desalva', ''),
(38, 53, 1000001, 12, 1, 11, 14, 5, 6, 7, 8, 26, 'F', 'Fail', 'Yes', 1454873973, 0, 'Alvin Desalva', ''),
(39, 54, 1000001, 12, 1, 11, 14, 10, 15, 20, 25, 70, 'C', 'Passed', 'Yes', 1454873997, 0, 'Alvin Desalva', ''),
(40, 55, 1000001, 12, 1, 11, 14, 1, 2, 3, 4, 10, 'F', 'Fail', 'Yes', 1454874018, 0, 'Alvin Desalva', ''),
(41, 56, 1000001, 12, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'Yes', 1454874035, 0, 'Alvin Desalva', ''),
(63, 59, 1000001, 11, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'Yes', 1455364869, 0, 'Alvin Desalva', ''),
(71, 59, 1000002, 11, 1, 11, 14, 2, 3, 4, 5, 14, 'F', 'Fail', 'No', 1455378455, 0, 'Alvin Desalva', ''),
(72, 59, 1000002, 11, 1, 11, 14, 3, 4, 5, 6, 18, 'F', 'Fail', 'No', 1455378460, 0, 'Alvin Desalva', ''),
(95, 0, 1000005, 10, 0, 0, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1455739493, 0, 'Alvin Desalva', ''),
(96, 0, 1000005, 10, 0, 0, 14, 10, 15, 20, 5, 50, 'F', 'Fail', 'No', 1455739675, 0, 'Alvin Desalva', ''),
(103, 0, 1000005, 10, 0, 0, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'No', 1455740944, 0, 'Alvin Desalva', ''),
(106, 0, 1000005, 10, 0, 0, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1455741187, 0, 'Alvin Desalva', ''),
(107, 0, 1000004, 10, 0, 0, 14, 5, 10, 20, 15, 50, 'F', 'Fail', 'Yes', 1455741285, 0, 'Alvin Desalva', ''),
(108, 0, 1000004, 10, 0, 0, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1455741293, 0, 'Alvin Desalva', ''),
(109, 23, 1000004, 11, 1, 12, 14, 5, 5, 17, 16, 43, 'F', 'Fail', 'Yes', 1455821703, 0, 'Alvin Desalva', ''),
(110, 57, 1000000, 11, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'Yes', 1455824313, 0, 'Alvin Desalva', ''),
(111, 57, 1000002, 11, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'Yes', 1455824350, 0, 'Alvin Desalva', ''),
(112, 57, 1000005, 11, 1, 11, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1455824360, 0, 'Alvin Desalva', ''),
(113, 57, 1000005, 11, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1455824372, 0, 'Alvin Desalva', ''),
(114, 57, 1000001, 11, 1, 11, 14, 5, 10, 20, 15, 50, 'F', 'Fail', 'Yes', 1455824470, 0, 'Alvin Desalva', ''),
(116, 58, 1000001, 11, 1, 11, 14, 5, 10, 20, 15, 50, 'F', 'Fail', 'Yes', 1455824554, 0, 'Alvin Desalva', ''),
(118, 58, 1000002, 11, 1, 11, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1455824575, 0, 'Alvin Desalva', ''),
(119, 58, 1000002, 11, 1, 11, 14, 5, 20, 30, 40, 95, 'A+', 'Passed', 'No', 1455824584, 0, 'Alvin Desalva', ''),
(120, 58, 1000005, 11, 1, 11, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1455824595, 0, 'Alvin Desalva', ''),
(121, 58, 1000005, 11, 1, 11, 14, 2, 3, 4, 5, 14, 'F', 'Fail', 'No', 1455824600, 0, 'Alvin Desalva', ''),
(122, 58, 1000005, 11, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1455824607, 0, 'Alvin Desalva', ''),
(123, 59, 1000002, 11, 1, 11, 14, 5, 10, 20, 30, 65, 'D+', 'Passed', 'Yes', 1455824637, 0, 'Alvin Desalva', ''),
(124, 59, 1000005, 11, 1, 11, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1455824646, 0, 'Alvin Desalva', ''),
(125, 59, 1000005, 11, 1, 11, 14, 10, 20, 30, 5, 65, 'D+', 'Passed', 'No', 1455824651, 0, 'Alvin Desalva', ''),
(127, 53, 1000000, 12, 1, 11, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1455824731, 0, 'Alvin Desalva', ''),
(128, 53, 1000000, 12, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1455824745, 0, 'Alvin Desalva', ''),
(129, 54, 1000000, 12, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'Yes', 1455824761, 0, 'Alvin Desalva', ''),
(130, 55, 1000000, 12, 1, 11, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1455824769, 0, 'Alvin Desalva', ''),
(131, 55, 1000000, 12, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1455824773, 0, 'Alvin Desalva', ''),
(132, 56, 1000000, 12, 1, 11, 14, 5, 10, 20, 30, 65, 'D+', 'Passed', 'Yes', 1455824785, 0, 'Alvin Desalva', ''),
(133, 53, 1000001, 12, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1455824815, 0, 'Alvin Desalva', ''),
(134, 53, 1000002, 12, 1, 11, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1455824824, 0, 'Alvin Desalva', ''),
(135, 53, 1000002, 12, 1, 11, 14, 1, 10, 20, 30, 61, 'D', 'Passed', 'No', 1455824832, 0, 'Alvin Desalva', ''),
(136, 53, 1000005, 12, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'Yes', 1455824840, 0, 'Alvin Desalva', ''),
(137, 54, 1000002, 12, 1, 11, 14, 5, 10, 23, 30, 68, 'D+', 'Passed', 'Yes', 1455824861, 0, 'Alvin Desalva', ''),
(138, 55, 1000002, 12, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'Yes', 1455824867, 0, 'Alvin Desalva', ''),
(139, 56, 1000002, 12, 1, 11, 14, 5, 20, 30, 40, 95, 'A+', 'Passed', 'Yes', 1455824880, 0, 'Alvin Desalva', ''),
(140, 54, 1000005, 12, 1, 11, 14, 5, 10, 20, 30, 65, 'D+', 'Passed', 'Yes', 1455824906, 0, 'Alvin Desalva', ''),
(141, 55, 1000005, 12, 1, 11, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1455824914, 0, 'Alvin Desalva', ''),
(142, 56, 1000005, 12, 1, 11, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1455824922, 0, 'Alvin Desalva', ''),
(143, 55, 1000001, 12, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1455824973, 0, 'Alvin Desalva', ''),
(144, 55, 1000005, 12, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1455824987, 0, 'Alvin Desalva', ''),
(145, 56, 1000005, 12, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1455824999, 0, 'Alvin Desalva', ''),
(146, 49, 1000002, 14, 1, 11, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1455827870, 0, 'Alvin Desalva', ''),
(147, 49, 1000002, 14, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1455827874, 0, 'Alvin Desalva', ''),
(148, 49, 1000001, 14, 1, 11, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1455828157, 0, 'Alvin Desalva', ''),
(149, 49, 1000001, 14, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1455828204, 0, 'Alvin Desalva', ''),
(150, 0, 1000001, 10, 0, 0, 14, 6, 3, 10, 15, 34, 'F', 'Fail', 'Yes', 1456085150, 0, 'Alvin Desalva', ''),
(151, 0, 1000001, 10, 0, 0, 14, 4, 4, 12, 10, 30, 'F', 'Fail', 'No', 1456085169, 0, 'Alvin Desalva', ''),
(152, 0, 1000001, 10, 0, 0, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1456085421, 0, 'Haleem Syed', ''),
(153, 57, 1000001, 11, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1456087280, 0, 'Alvin Desalva', ''),
(154, 26, 1000000, 13, 1, 11, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1456087436, 0, 'Alvin Desalva', ''),
(155, 26, 1000000, 13, 1, 11, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'No', 1456087616, 0, 'Alvin Desalva', ''),
(156, 26, 1000000, 13, 1, 11, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1456087690, 0, 'Alvin Desalva', ''),
(157, 0, 1000000, 10, 0, 0, 14, 5, 10, 15, 20, 50, 'F', 'Fail', 'Yes', 1456087761, 0, 'Haleem Syed', ''),
(158, 0, 1000000, 10, 0, 0, 14, 10, 20, 30, 40, 100, 'A+', 'Passed', 'No', 1456087787, 0, 'Haleem Syed', '');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `table_id` int(14) NOT NULL,
  `reg_id` int(7) NOT NULL,
  `national_id` int(10) NOT NULL,
  `mobile` varchar(15) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `english_name` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `arabic_name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `city` int(2) NOT NULL,
  `nationality` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `place_issue` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `date_issue` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `date_reg` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `date_exit` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `student_dob` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `batch_year_id` int(7) NOT NULL,
  `curr_id` int(4) NOT NULL,
  `major_id` int(2) NOT NULL,
  `is_active` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT 'Yes',
  `inactive_reason` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `entry_time` int(16) NOT NULL,
  `edit_time` int(16) NOT NULL,
  `entry_user_full_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `edit_user_full_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`table_id`, `reg_id`, `national_id`, `mobile`, `english_name`, `arabic_name`, `email`, `city`, `nationality`, `place_issue`, `date_issue`, `date_reg`, `date_exit`, `student_dob`, `batch_year_id`, `curr_id`, `major_id`, `is_active`, `inactive_reason`, `entry_time`, `edit_time`, `entry_user_full_name`, `edit_user_full_name`) VALUES
(1, 1000000, 123456790, '0568204755', 'syed abdul haleem syed abdul hakeem', 'سيد عبد الحليم سيد عبد ال', 'haleemfp@gmail.com', 14, 'SAU', 'سعودي جزيره العرب', '19/9/1420', '1/1/1436', '17/12/1439', '18/9/1999', 14, 1, 11, 'Yes', '', 1454257675, 0, 'Alvin Desalva', ''),
(23, 1000001, 2147483647, '0568204755', 'Haleem Syed', 'Haleem Syed', 'fuzailhs@gmail.com', 23, 'IND', 'سعودي جزيره العرب', '17/6/1421', '1/1/1436', '17/12/1439', '21/10/2000', 14, 1, 11, 'Yes', '', 1456077291, 1456086089, 'Haleem Syed', 'Haleem Syed'),
(24, 1000002, 2147483647, '9989957402', 'Syed Fuzail', 'سيد حليم حكيم', 'malihafh@gmail.com', 22, 'IND', 'مدينه الخبر', '24/1/1425', '1/1/1436', '17/12/1439', '20/1/2006', 14, 1, 11, 'Yes', '', 1454180897, 0, 'Alvin Desalva', ''),
(25, 1000003, 245874580, '0547854966', 'Othman Otaibi', 'othman in arabic', 'othman@gmail.com', 17, 'SAU', 'الجبيل', '12/31/1420', '1/1/1436', '17/12/1439', '12/31/2000', 14, 1, 12, 'Yes', '', 1454250223, 0, 'Alvin Desalva', ''),
(26, 1000004, 214578596, '0568204755', 'SYED HALEEM', 'SYED HALEEM', 'khalid@gmail.com', 27, 'IND', 'سعودي جزيره العرب', '31/10/1433', '1/1/1436', '', '26/10/2002', 14, 1, 12, 'Yes', '', 1456076232, 0, 'Alvin Desalva', ''),
(27, 1000005, 2147483647, '5632145879', 'Naaz khan', 'naaz arabic', 'naaz@gmail.com', 23, 'SAU', 'سعودي جزيره العرب', '19/8/1421', '1/1/1436', '17/12/1439', '16/12/1999', 14, 1, 11, 'Yes', '', 1454256898, 0, 'Alvin Desalva', ''),
(28, 1000006, 2145785412, '0415236544', 'Mariam Syed', 'Mariam Arabic Name', 'mariam@gmail.com', 23, 'SAU', 'سعودي جزيره العرب', '19/12/1419', '1/1/1436', '17/12/1439', '19/11/2000', 14, 1, 12, 'Yes', '', 1454441359, 0, 'Alvin Desalva', ''),
(29, 1000007, 2147483647, '0568204755', 'Asfiya Tajallum', 'Asfiya Tajallum', 'asdf@afda.com', 23, 'IND', 'saudi', '2/3/1435', '1/1/1436', '17/12/1439', '3/3/2015', 14, 1, 12, 'Yes', '', 1454708977, 0, 'Alvin Desalva', ''),
(30, 1000008, 2147483647, '0568204755', 'Haleem Syed', 'Haleem Syed', 'adfnl@gmail.com', 17, 'AZE', 'سعودي جزيره العرب', '3/3/1437', '2/2/1437', '17/12/1439', '17/11/1999', 16, 2, 11, 'Yes', '', 1455915647, 0, 'Alvin Desalva', ''),
(31, 1000009, 2147483647, '0541256244', 'Fawwaz ghamdi', 'fawwaz ghamdi', 'fawwaz@gmail.com', 23, 'BLM', 'الجبيل', '3/6/1435', '2/3/1477', '', '16/1/2000', 17, 0, 0, 'Yes', '', 1456077441, 0, 'Alvin Desalva', ''),
(32, 1000010, 2147483647, '5241563254', 'Hassan Mubarki', 'Hassan Mubarki', 'adfads@gmail.com', 18, 'ATG', 'مدينه الخبر', '5/6/1428', '6/6/1474', '', '6/6/2011', 17, 0, 0, 'Yes', '', 1456078299, 0, 'Haleem Syed', ''),
(33, 1000011, 2147483647, '5896547892', 'Waleed Anazi', 'Waleed Anazi', 'waleed@gmail.com', 23, 'SAU', 'مدينه الخبر', '2/2/1436', '2/2/1480', '', '2/1/2001', 17, 0, 0, 'Yes', '', 1456078457, 0, 'Haleem Syed', '');

-- --------------------------------------------------------

--
-- Table structure for table `uniqueid`
--

CREATE TABLE IF NOT EXISTS `uniqueid` (
  `table_id` int(14) NOT NULL,
  `last_reg_id` int(7) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `uniqueid`
--

INSERT INTO `uniqueid` (`table_id`, `last_reg_id`) VALUES
(1, 1000000),
(2, 15454),
(3, 4578);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `table_id` int(10) NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `full_name` varchar(100) COLLATE utf8_bin NOT NULL,
  `password` varchar(60) COLLATE utf8_bin NOT NULL,
  `profile` varchar(50) COLLATE utf8_bin NOT NULL,
  `del_marks` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT 'No'
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`table_id`, `email`, `full_name`, `password`, `profile`, `del_marks`) VALUES
(3, 'fuzailhs@gmail.com', 'fuzail syed', 'flatno45', 'admin', 'No'),
(4, 'naaz@gmail.com', 'naaz khan', '123456', 'faculty', 'No'),
(5, 'naazi@gmial.com', 'nazeer unnisa', '123456', 'faculty', 'No'),
(7, 'haleemfp@gmail.com', 'Haleem Syed', 'flatno45', 'faculty', 'Yes'),
(9, 'konsi@gmail.com', 'konki ki', 'flatno45', 'faculty', 'No');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `batch_year`
--
ALTER TABLE `batch_year`
  ADD PRIMARY KEY (`table_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`table_id`);

--
-- Indexes for table `curr_detail`
--
ALTER TABLE `curr_detail`
  ADD PRIMARY KEY (`table_id`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`table_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`table_id`),
  ADD UNIQUE KEY `table_id` (`table_id`),
  ADD UNIQUE KEY `reg_id` (`reg_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `uniqueid`
--
ALTER TABLE `uniqueid`
  ADD PRIMARY KEY (`table_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`table_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `batch_year`
--
ALTER TABLE `batch_year`
  MODIFY `table_id` int(7) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `table_id` int(14) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=114;
--
-- AUTO_INCREMENT for table `curr_detail`
--
ALTER TABLE `curr_detail`
  MODIFY `table_id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `table_id` int(14) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `table_id` int(14) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `uniqueid`
--
ALTER TABLE `uniqueid`
  MODIFY `table_id` int(14) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `table_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
