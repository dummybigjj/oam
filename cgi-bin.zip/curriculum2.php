<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}
//http://localhost:8012/thiepapp/Curriculum.php?curr=1&major=11 FOR NEW
//http://localhost:8012/thiepapp/Curriculum.php?curr=1&major=11&batchid=14 FOR FULL REGISTERED
if(count($_GET) < 2) {
	header("location: index.php");
	exit;
} else {

	if (isset($_GET['batchid']) ) {
		$batchid = mysql_real_escape_string($_GET['batchid']);
	}
	//$curr_id = mysql_real_escape_string($_GET['curr']);
	$major_id = mysql_real_escape_string($_GET['major']);
	$table_id = mysql_real_escape_string($_GET['table_id']);
	$curr_id = 1;
	// Check is it new curriculum
	if(mysql_num_rows(mysql_query("SELECT * from curr_detail where curr_id = '$curr_id' and is_complete_data = 'No'")) == 1) {
		$isnew = 'Yes';
	}
	
	if(mysql_num_rows(mysql_query("SELECT * from courses where curr_id = '$curr_id' and major_id = '$major_id'")) == 0) {
		do_alert("Still there is no record exist, please enter the record and try again");
		nextpage("CurriculumEntry.php");
		exit;
	}
	
	if(isset($isnew) != 'Yes'){
		if(mysql_num_rows(mysql_query("SELECT * FROM students WHERE curr_table = '$table_id' AND major_id = '$major_id' AND batch_year_id = '$batchid'")) == 0) {
		do_alert("Record not found, please try again");
		nextpage("input-grade.php");
		exit;
		}
	}
	
	$allcurrvar = mysql_fetch_assoc(mysql_query("SELECT * from curr_detail where curr_id = '$curr_id'"));
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>
  
	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 

<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:10px;">
				
                <div class="col-xs-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
                <?php if(isset($isnew) == 'Yes') { ?>
                <h4><?php echo $glomajor[$major_id]; ?></h5>
                <?php } else {?>
				<h4><?php echo $glomajor[$major_id]; ?></h4><h5><?php echo 'Batch: '.batch_name_from_id($batchid); ?></h5>
                <?php } ?>
				</div>
                </div>
</div>

<?php if(isset($isnew) != 'Yes') { ?>
<div class="row" style="margin-bottom:10px;">
				
                <div class="col-xs-12" style="margin:0; padding:0;">
                
                <div align="center" class="padding10">
                <div class="statstop">
                <?php echo 'Student Registered '.mysql_num_rows(mysql_query("select * from students where curr_id = '$curr_id' and batch_year_id = '$batchid' and major_id = '$major_id'")); ?>
				</div>
                
                <div class="statstop">
                <?php 
				$stuavail = mysql_num_rows(mysql_query("select * from students where curr_id = '$curr_id' and batch_year_id = '$batchid' and major_id = '$major_id' and is_active = 'Yes'"));
				echo 'Student Available: '.$stuavail;
				 ?>
				</div>
                
                <div class="statstop">
                <?php $totlvl = mysql_fetch_array(mysql_query("select levels from curr_detail where curr_id = '$curr_id'")); 
				echo 'Total Levels '.$totlvl[0];
				?>
				
				</div>
                </div>
                
                </div>
</div>
<?php } ?>


				 
<div class="row" style="margin-bottom:40px;">
                <div class="col-xs-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4><?php echo $curr5lvls['11']; ?></h4>
				 </div>
				
				<div class="boxback margin10">
	<?php 
	$allcoursesquery = mysql_query("select * from courses where curr_id = '$curr_id' and level_no = '11' and major_id = '$major_id'");
	?>
					 <h4><b><?php echo $curr5lvls['11'].' Status'; ?></b></h4>
                     <?php if(isset($isnew) != 'Yes') { 
					  echo 'Total Courses = '.mysql_num_rows($allcoursesquery).', <a href="LevelRecord.php?curr='.$curr_id.'&level=11&major='.$major_id.'&batchid='.$batchid.'"> View this level marks</a>'.'<br/>';
					 echo '<hr/>';
					 while($allcourses = mysql_fetch_assoc($allcoursesquery)) {  
					 ?>
                     <b><?php echo $allcourses['course_code'].' - '.$allcourses['course_name']; ?></b>
                     <br /><?php echo 'Credit Hour = '.$allcourses['credit_hour'].'.0,' ?>
                     <?php 
					 $course_ref_no =  $allcourses['course_ref_no'];
					 $countmarks = mysql_query("select * from marks where curr_id = '$curr_id' and level_no = '11' and major_id = '$major_id' and batch_year_id = '$batchid' and course_ref_no = '$course_ref_no' and is_fresh = 'Yes' ");
					 ?>
                     <br /><?php
					 if(mysql_num_rows($countmarks) <= 0) {
						  echo 'Marks Enter = Not Entered Yet';
					 } else {
						  echo 'Marks Enter = '.mysql_num_rows($countmarks);
					 }
					 ?>
                     <br />
					 <?php
					  $marrem = $stuavail - mysql_num_rows($countmarks);
					  if($marrem <= 0) {
						   echo 'Marks Remaining = All Entered';
					  } else {
						  echo 'Marks Remaining = '.$marrem;  } ?>
                     <br />
                     <?php  
					 echo '<a href="inputgrade.php?table_id='.$table_id.'&curr='.$curr_id.'&level=11&major='.$major_id.'&batchid='.$batchid.'&courid='.$course_ref_no.'"> View course record</a>';
					 ?>

                     <hr />
                     <?php }
					 ?>
                     <h6><em><b>Note: </b>If the number of entered marks is more than the available students, means the student has left the school after writing the exam</em></h6>
					 
                     <?php } else { 
					 echo '<br />';
					 while($allcourses = mysql_fetch_assoc($allcoursesquery)) {  
					 ?>
                     <h5><b><?php echo $allcourses['course_code'].' - '.$allcourses['course_name']; ?></b>
                     <br /><?php echo 'Credit Hour = '.$allcourses['credit_hour'].'.0'; ?></h5><hr />
                     <?php } } ?>
					 
                </div>
                </div> 
                
                <div class="col-xs-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4><?php echo $curr5lvls['12']; ?></h4>
				 </div>
				
				<div class="boxback margin10">
	<?php 
	$allcoursesquery = mysql_query("select * from courses where curr_id = '$curr_id' and level_no = '12' and major_id = '$major_id'");
	?>
					 <h4><b><?php echo $curr5lvls['12'].' Status'; ?></b></h4>
                     <?php if(isset($isnew) != 'Yes') { 
					  echo 'Total Courses = '.mysql_num_rows($allcoursesquery).', <a  href="LevelRecord.php?curr='.$curr_id.'&level=12&major='.$major_id.'&batchid='.$batchid.'"> View this level marks</a>'.'<br/>';
					 echo '<hr/>';
					 while($allcourses = mysql_fetch_assoc($allcoursesquery)) {  
					 ?>
                     <b><?php echo $allcourses['course_code'].' - '.$allcourses['course_name']; ?></b>
                     <br /><?php echo 'Credit Hour = '.$allcourses['credit_hour'].'.0,' ?>
                     <?php 
					 $course_ref_no =  $allcourses['course_ref_no'];
					 $countmarks = mysql_query("select * from marks where curr_id = '$curr_id' and level_no = '12' and major_id = '$major_id' and batch_year_id = '$batchid' and course_ref_no = '$course_ref_no' and is_fresh = 'Yes' ");
					 ?>
                     <br /><?php
					 if(mysql_num_rows($countmarks) <= 0) {
						  echo 'Marks Enter = Not Entered Yet';
					 } else {
						  echo 'Marks Enter = '.mysql_num_rows($countmarks);
					 }
					 ?>
                     <br />
					 <?php
					  $marrem = $stuavail - mysql_num_rows($countmarks);
					  if($marrem <= 0) {
						  echo 'Marks Remaining = All Entered';
					  } else {
						  echo 'Marks Remaining = '.$marrem;  } ?>
                     <br />
                     <?php  
					 echo '<a href="inputgrade.php?table_id='.$table_id.'&curr='.$curr_id.'&level=12&major='.$major_id.'&batchid='.$batchid.'&courid='.$course_ref_no.'"> View course record</a>';
					 ?>

                     <hr />
                     <?php }
					 ?>
                     <h6><em><b>Note: </b>If the number of entered marks is more than the available students, means the student has left the school after writing the exam</em></h6>
					 
                     <?php } else { 
					 echo '<br />';
					 while($allcourses = mysql_fetch_assoc($allcoursesquery)) {  
					 ?>
                     <h5><b><?php echo $allcourses['course_code'].' - '.$allcourses['course_name']; ?></b>
                     <br /><?php echo 'Credit Hour = '.$allcourses['credit_hour'].'.0'; ?></h5>
                     <?php } } ?>
					 
                </div>
                </div>             
</div>

<div class="row" style="margin-bottom:40px;">
				<div class="col-xs-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4><?php echo $curr5lvls['13']; ?></h4>
				 </div>
				
				<div class="boxback margin10">
	<?php 
	$allcoursesquery = mysql_query("select * from courses where curr_id = '$curr_id' and level_no = '13' and major_id = '$major_id'");
	?>
					 <h5><b><?php echo $curr5lvls['13'].' Status'; ?></b></h5>
                     <?php if(isset($isnew) != 'Yes') { 
					  echo 'Total Courses = '.mysql_num_rows($allcoursesquery).', <a href="LevelRecord.php?curr='.$curr_id.'&level=13&major='.$major_id.'&batchid='.$batchid.'"> View this level marks</a>'.'<br/>';
					 echo '<hr/>';
					 while($allcourses = mysql_fetch_assoc($allcoursesquery)) {  
					 ?>
                     <b><?php echo $allcourses['course_code'].' - '.$allcourses['course_name']; ?></b>
                     <br /><?php echo 'Credit Hour = '.$allcourses['credit_hour'].'.0,' ?>
                     <?php 
					 $course_ref_no =  $allcourses['course_ref_no'];
					 $countmarks = mysql_query("select * from marks where curr_id = '$curr_id' and level_no = '13' and major_id = '$major_id' and batch_year_id = '$batchid' and course_ref_no = '$course_ref_no' and is_fresh = 'Yes' ");
					 ?>
                     <br /><?php
					 if(mysql_num_rows($countmarks) <= 0) {
						  echo 'Marks Enter = Not Entered Yet';
					 } else {
						  echo 'Marks Enter = '.mysql_num_rows($countmarks);
					 }
					 ?>
                     <br />
					 <?php
					  $marrem = $stuavail - mysql_num_rows($countmarks);
					  if($marrem <= 0) {
						   echo 'Marks Remaining = All Entered';
					  } else {
						  echo 'Marks Remaining = '.$marrem;  } ?>
                     <br />
                     <?php  
					 echo '<a href="inputgrade.php?table_id='.$table_id.'&curr='.$curr_id.'&level=13&major='.$major_id.'&batchid='.$batchid.'&courid='.$course_ref_no.'"> View course record</a>';
					 ?>

                     <hr />
                     <?php }
					 ?>
                     <h6><em><b>Note: </b>If the number of entered marks is more than the available students, means the student has left the school after writing the exam</em></h6>
					 
                     <?php } else { 
					 echo '<br />';
					 while($allcourses = mysql_fetch_assoc($allcoursesquery)) {  
					 ?>
                     <h5><b><?php echo $allcourses['course_code'].' - '.$allcourses['course_name']; ?></b>
                     <br /><?php echo 'Credit Hour = '.$allcourses['credit_hour'].'.0'; ?></h5>
                     <?php } } ?>
					 
                </div>
                </div> 
                
                <div class="col-xs-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4><?php echo $curr5lvls['14']; ?></h4>
				 </div>
				
				<div class="boxback margin10">
	<?php 
	$allcoursesquery = mysql_query("select * from courses where curr_id = '$curr_id' and level_no = '14' and major_id = '$major_id'");
	?>
					 <h5><b><?php echo $curr5lvls['14'].' Status'; ?></b></h5>
                     <?php if(isset($isnew) != 'Yes') { 
					  echo 'Total Courses = '.mysql_num_rows($allcoursesquery).', <a href="LevelRecord.php?curr='.$curr_id.'&level=14&major='.$major_id.'&batchid='.$batchid.'"> View this level marks</a>'.'<br/>';
					 echo '<hr/>';
					 while($allcourses = mysql_fetch_assoc($allcoursesquery)) {  
					 ?>
                     <b><?php echo $allcourses['course_code'].' - '.$allcourses['course_name']; ?></b>
                     <br /><?php echo 'Credit Hour = '.$allcourses['credit_hour'].'.0,' ?>
                     <?php 
					 $course_ref_no =  $allcourses['course_ref_no'];
					 $countmarks = mysql_query("select * from marks where curr_id = '$curr_id' and level_no = '14' and major_id = '$major_id' and batch_year_id = '$batchid' and course_ref_no = '$course_ref_no' and is_fresh = 'Yes' ");
					 ?>
                     <br /><?php
					 if(mysql_num_rows($countmarks) <= 0) {
						  echo 'Marks Enter = Not Entered Yet';
					 } else {
						  echo 'Marks Enter = '.mysql_num_rows($countmarks);
					 }
					 ?>
                     <br />
					 <?php
					  $marrem = $stuavail - mysql_num_rows($countmarks);
					  if($marrem <= 0) {
						   echo 'Marks Remaining = All Entered';
					  } else {
						  echo 'Marks Remaining = '.$marrem;  } ?>
                     <br />
                     <?php  
					 echo '<a href="inputgrade.php?table_id='.$table_id.'&curr='.$curr_id.'&level=14&major='.$major_id.'&batchid='.$batchid.'&courid='.$course_ref_no.'"> View course record</a>';
					 ?>

                     <hr />
                     <?php }
					 ?>
                     <h6><em><b>Note: </b>If the number of entered marks is more than the available students, means the student has left the school after writing the exam</em></h6>
					 
                     <?php } else { 
					 echo '<br />';
					 while($allcourses = mysql_fetch_assoc($allcoursesquery)) {  
					 ?>
                     <h5><b><?php echo $allcourses['course_code'].' - '.$allcourses['course_name']; ?></b>
                     <br /><?php echo 'Credit Hour = '.$allcourses['credit_hour'].'.0'; ?></h5>
                     <?php } } ?>
					 
                </div>
                </div> 
</div>

<?php if($allcurrvar['levels'] == 5) { ?>
<div class="row" style="margin-bottom:40px;">
                <div class="col-xs-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4><?php echo $curr5lvls['15']; ?></h4>
				 </div>
				
				<div class="boxback margin10">
	<?php 
	$allcoursesquery = mysql_query("select * from courses where curr_id = '$curr_id' and level_no = '15' and major_id = '$major_id'");
	?>
					 <h5><b><?php echo $curr5lvls['15'].' Status'; ?></b></h5>
                     <?php if($isnew != 'Yes') { 
					  echo 'Total Courses = '.mysql_num_rows($allcoursesquery).', <a href="LevelRecord.php?curr='.$curr_id.'&level=15&major='.$major_id.'&batchid='.$batchid.'"> View this level marks</a>'.'<br/>';
					 echo '<hr/>';
					 while($allcourses = mysql_fetch_assoc($allcoursesquery)) {  
					 ?>
                     <b><?php echo $allcourses['course_code'].' - '.$allcourses['course_name']; ?></b>
                     <br /><?php echo 'Credit Hour = '.$allcourses['credit_hour'].'.0,' ?>
                     <?php 
					 $course_ref_no =  $allcourses['course_ref_no'];
					 $countmarks = mysql_query("select * from marks where curr_id = '$curr_id' and level_no = '15' and major_id = '$major_id' and batch_year_id = '$batchid' and course_ref_no = '$course_ref_no' and is_fresh = 'Yes' ");
					 ?>
                     <br /><?php
					 if(mysql_num_rows($countmarks) <= 0) {
						  echo 'Marks Enter = Not Entered Yet';
					 } else {
						  echo 'Marks Enter = '.mysql_num_rows($countmarks);
					 }
					 ?>
                     <br />
					 <?php
					  $marrem = $stuavail - mysql_num_rows($countmarks);
					  if($marrem <= 0) {
						   echo 'Marks Remaining = All Entered';
					  } else {
						  echo 'Marks Remaining = '.$marrem;  } ?>
                     <br />
                     <?php  
					 echo '<a href="inputgrade.php?table_id='.$table_id.'&curr='.$curr_id.'&level=15&major='.$major_id.'&batchid='.$batchid.'&courid='.$course_ref_no.'"> View course record</a>';
					 ?>

                     <hr />
                     <?php }
					 ?>
                     <h6><em><b>Note: </b>If the number of entered marks is more than the available students, means the student has left the school after writing the exam</em></h6>
					 
                     <?php } else { 
					 echo '<br />';
					 while($allcourses = mysql_fetch_assoc($allcoursesquery)) {  
					 ?>
                     <h5><b><?php echo $allcourses['course_code'].' - '.$allcourses['course_name']; ?></b>
                     <br /><?php echo 'Credit Hour = '.$allcourses['credit_hour'].'.0'; ?></h5>
                     <?php } } ?>
					 
                </div>
                </div>
</div>
<?php } ?>

</div> 


<!-- Footer -->
<?php require('menu.php'); ?> 

</div>
</body>
</html>
