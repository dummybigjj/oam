<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}

//print_r($allvar);
$openbatches = array();
$completedcurr = array();

	$allbatches = all_batches_open();

	// Checking if any batch is ready for registraion else not possible to register
	//$allbatches = all_batches_to_register();
	if(empty($allbatches)){
		do_alert("There is no batch register until yet or not activated. Please ask admin to either register or activate the batch year");
		nextpage("index.php");
		exit;
	}

if (isset($_POST['enterstudent']) || isset($_POST['pofilestudent']))
	{
		$errors = array();
		//var_dump($_POST);
		$english_name = trim(implode(' ', preg_split('/\s+/', $_POST['english_name'])));
		$arabic_name = trim($_POST['arabic_name']);
		$mobile = trim($_POST['mobile']);
	
		//$city = $_POST['city'];
		$nationality = $_POST['nationality'];
		$national_id = trim(implode(' ', preg_split('/\s+/', $_POST['national_id'])));
		//$place_issue = $_POST['place_issue'];
		
		//$dob_day = $_POST["dob_day"];
		//$dob_month = $_POST["dob_month"];
		//$dob_year = $_POST["dob_year"];
		//$student_dob = $dob_day."/".$dob_month."/".$dob_year;
		//$email = trim($_POST['email']);
		//$doi_day = $_POST["doi_day"];
		//$doi_month = $_POST["doi_month"];
		//$doi_year = $_POST["doi_year"];
		//$date_issue = $doi_day."/".$doi_month."/".$doi_year;
		
		$dor_day = $_POST["dor_day"];
		$dor_month = $_POST["dor_month"];
		$dor_year = $_POST["dor_year"];
		$date_reg = $dor_day."/".$dor_month."/".$dor_year;

		$batch_year_id = $_POST['batch_year_id'];
		$curr_id = $_POST['curr_id'];
		$major_id = $_POST['major_id'];
		//..........
		if(empty($english_name)) {
			$errors[] = 'Please enter the Full English Name.'; 
		} else {
			if(!preg_match('/^[a-zA-Z ]{8,40}$/', $english_name)) {
				$errors[] = 'Name shall be between 8 - 40 char in English.';
			}
		}

		/**
		if (empty($curr_id)) {
			$errors[] = 'Please select curriculum.'; 
		}

		if (empty($major_id)) {
			$errors[] = 'Please select major.'; 
		}
		**/
		//..........
		if(empty($arabic_name)) {
			$errors[] = 'Please enter the Full Arabic Name.'; 
		} 
				

		//.........
		if(empty($mobile)) {
			$errors[] = 'Please enter the Mobile Number.'; 
		} else {
			$mobile = trim(implode(' ', preg_split('/\s+/', $_POST['mobile'])));
			if(!(preg_match('/^[0-9]{10,10}$/', $mobile))) {
				$errors[] = 'Mobile Number shall be of 10 Digits.';
			}
		}
		
		/**
		
		if (!(filter_var($email, FILTER_VALIDATE_EMAIL))) {
			$errors[] = "Enter valid email address.";
		} else 	
**/
		/**if(mysql_num_rows(mysql_query("SELECT * FROM students where email = '".mysql_real_escape_string($email)."'")) > 0) {
			$errors[] = "Email already exist, Please change the email if the student is student another major.";
			} **/
		//.........
			/**
		if(empty($_POST['city'])) {
			$errors[] = 'Please choose the city where student living.'; 
		} else {
			$city  = $_POST['city']; 
			if( !array_key_exists($city, $city_list) ) {
				$errors[] = 'Invalid city selected, Contact Developer.';
			}
		}		
		**/	
		
		//.........
		if(empty($nationality)) {
			$errors[] = 'Please Select the Nationality.'; 
		} else { 
			if(!array_key_exists($nationality, $country_list)) {
				$errors[] = 'Invalid Country Selection, Contact Developer.';
			}
		}
		
		//.........
		if(empty($national_id)) {
			$errors[] = 'Please enter the National ID.'; 
		} else {
			if(!(preg_match('/^[0-9]{10,10}$/', $national_id))) {
				$errors[] = 'National ID shall be of 10 Digits.';
			}
		}
		
		//.........
	/**	if(empty($_POST['place_issue'])) {
			$errors[] = 'Please choose the place of issue of ID.'; 
		} else {
			if( !array_key_exists($place_issue, $city_list) ) {
				$errors[] = 'Invalid city selected, Contact Developer.';
			}
		}
**/
		//.........
		/**
		if(empty($dob_day) || empty($dob_month) || empty($dob_year) || empty($doi_day) || empty($doi_month) || empty($doi_year) || empty($dor_day) || empty($dor_month) || empty($dor_year) )
				{
					$errors[]= "Date, Month & Years has to be selected.";
				}
				
		**/
		//.........
		if (empty($dor_day) || empty($dor_month) || empty($dor_year) ) {
			$errors[]= "Date, Month & Years has to be selected.";
		}
		if(empty($_POST['batch_year_id'])) {
			$errors[] = 'Please choose the batch start for the student.'; 
		} else {
			$batch_year_id  = $_POST['batch_year_id']; 
			if( !array_key_exists($batch_year_id, $allbatches) ) {
				$errors[] = 'Invalid batch selected, Contact Developer.';
			}
		}		
	
		//print_r($_POST);
		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){
		if(mysql_num_rows(mysql_query("SELECT reg_id FROM students")) == 0) {
			$reg_id = 1000001;
		} else {
			$last_reg_id = mysql_fetch_array(mysql_query("SELECT reg_id FROM students ORDER BY reg_id DESC"));
			$reg_id = $last_reg_id[0] + 1;
		}
		
		$entry_user_full_name = $loginvar['full_name'];		
		$entry_time = date("U");			
		$english_name = mysql_real_escape_string($english_name);
		$arabic_name = mysql_real_escape_string($arabic_name);
		$mobile = mysql_real_escape_string($mobile);
		//$email = mysql_real_escape_string($email);
		//$city = mysql_real_escape_string($city);
		$nationality = mysql_real_escape_string($nationality);
		$national_id = mysql_real_escape_string($national_id);
		//$place_issue = mysql_real_escape_string($place_issue);
		//$student_dob = mysql_real_escape_string($student_dob);
		//$date_issue = mysql_real_escape_string($date_issue);
		$batch_year_id = mysql_real_escape_string($batch_year_id);
		$date_reg = mysql_real_escape_string($date_reg);
		

		//$isdone = mysql_query("INSERT INTO students (english_name, arabic_name, mobile, city, nationality, national_id, place_issue, student_dob, date_reg,  date_issue, batch_year_id, entry_time, entry_user_full_name, reg_id, email, curr_id, major_id) VALUES ('$english_name', '$arabic_name', '$mobile', '$city', '$nationality', '$national_id', '$place_issue', '$student_dob', '$date_reg', '$date_issue', '$batch_year_id', '$entry_time', '$entry_user_full_name', '$reg_id', '$email', '$curr_id', '$major_id')") or die(mysql_error());
		$curr_table_id = $_POST['curr_id'];
		$isdone = mysql_query("INSERT INTO students (english_name, curr_table, arabic_name, mobile,  nationality, national_id, date_reg, batch_year_id, entry_time, entry_user_full_name, reg_id, curr_id, major_id) VALUES ('$english_name', '$curr_table_id', '$arabic_name', '$mobile', '$nationality', '$national_id', '$date_reg', '$batch_year_id', '$entry_time', '$entry_user_full_name', '$reg_id', '$curr_id', '$major_id')") or die(mysql_error());
		if($isdone) {
			if(isset($_POST['enterstudent'])) {
				do_alert("Student Information has been saved");
				nextpage("StudentEntry.php");
				
				exit;
			} else if ( isset($_POST['pofilestudent']) ) {
				header("Location:StudentProfile.php?regid=$reg_id");
				exit;
			}
		}
		
	}

	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>

	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 
<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:30px;">
				
                <div class="col-sm-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
				<h4>Student Registration <em style="font-size:12px; color:red;">(NEW)</em>تسجيل الطالب 

 </h4>
				</div>
                </div>
</div>

<div class="row" style="margin-bottom:40px;">
                
                 <?php 
				if(isset($errors))
				{
					echo '<div class="padding10" style="color:red; font-weight:bold;">';
					echo 'ERRORS';
					echo '<div style="color:red; font-weight:normal;">';
				foreach ($errors as $msg) 
				{ ?>
                    <?php echo ">> $msg<br />\n"; ?>
				<?php }
					echo '</div>';
					echo '</div>';
				}
				?>
                
                <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="studentregsiter">
                
                <div class="col-xs-6" style="margin:0; padding:0;">

				 <div class="boxback margin10 formtitle">
					 <h4>Personal Information  المعلومات الشخصيه</h4>
				 </div>
				<div class="boxback margin10">
					
					 
					 <div class="form-group">
						 <label for="fullname">Full Name in English الاسم الكامل بالانجليزي
					</label>
                     <input class="form-control" required="required"  name="english_name"   type="text" value="<?php if (isset($english_name)){ echo htmlspecialchars($english_name); } ?>" placeholder="Enter Full Name in English">
					 </div>
					 
					 <div class="form-group">
					 <label for="fullname">Full Name in Arabic</label>
                     <input class="form-control" required="required"  name="arabic_name"   type="text" value="<?php if (isset($arabic_name)){ echo htmlspecialchars($arabic_name); } ?>"  placeholder="Enter Full Name in Arabic">
					 </div>
					<?php if(!empty($allinfo['curr_id']) ) {
						
						} else {
							$allcurr = all_curr_to_register();
						}
					?>
					 <div class="form-group">
					 	<label>Curriculum</label>
					 	<select class="form-control" name="curr_id">
					 		<?php 
					 			$sql = "SELECT * FROM curr_detail WHERE is_open_to_register = 'Yes' ";
					 			$stmt = $pdo -> prepare($sql);
					 			$stmt -> execute();
					 			while ($row = $stmt -> fetch()) {
					 				$id = $row['curr_id'];
					 				$t = $row['table_id'];
					 				$name = $row['curr_name'];
					 				echo "<option value='$t'> $name </option>";
					 			}

					 		?>

					 	</select>
					 </div>
					 <!--
					 <div class="form-group">
                     <label for="curr_id"><?php echo 'Curriculum'; ?></label>
                     <?php if(empty($allcurr)) {echo '<em style="font-size:12px; color:red;">Please ask admin to activate the curriculum</em>';} else { ?>
                     <?php } ?>
                     <select class="form-control" name="curr_id" >
                    <?php 
					if(isset($curr_id))
					{
						echo '<option selected="selected" value="'.$curr_id.'">'.$allcurr[$curr_id].'</option>';
					} else {
					?>
                  <option selected="selected" disabled="disabled"><?php echo 'Select Curriculum'; ?></option>
					<?php }

						foreach($allcurr as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>
                    </select>
				</div>
			-->

					 <div class="form-group">
					 <label for="course">Select Major</label>
                  
                     <select class="form-control" name="major_id" required="required">
                     	<?php
                     		if(isset($maj_id))	{
							echo '<option selected="selected" value="'.$maj_id.'">'.$glomajor[$maj_id].'</option>';
							} else {
						?>
                  <option selected="selected" disabled="disabled"><?php echo 'Select Major'; ?></option>
					<?php }

						foreach($glomajor as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}

                     	?>
                     </select>
					 </div>
					 
					  <!--div class="form-group">
					 <label for="email">Email</label>
                     <input class="form-control" required="required"  name="email" type="email" value="<?php if (isset($email)){ echo htmlspecialchars($email); } ?>" placeholder="Enter Email">
					 </div>-->

					 
					 
					<div class="form-group">
                     <label for="batch_year_id"><?php echo 'Batch Start'; ?></label><em style="font-size:12px; color:red;"> cannot change later</em>
                     <select class="form-control"  name="batch_year_id" required>
                    <?php 
					if(isset($batch_year_id))
					{
						echo '<option selected="selected" value="'.$batch_year_id.'">'.$allbatches[$batch_year_id].'</option>';
					} else {
					?>
                  <option selected="selected" value="" disabled="disabled"><?php echo 'Batch Start'; ?></option>
					<?php }

						foreach($allbatches as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>
                    </select>
				</div>
                     
                     				 
					 
                </div>
                </div>              
				
				<div class="col-md-6" style="margin:0; padding:0;">

                <div class="boxback margin10 formtitle">
					 <h4>Official Information معلومات رسمية 
</h4>
				     </div>
				<div class="boxback margin10">
					 
					 
                     
                     <div class="form-group">
					 <label for="nationality"><?php echo 'Nationality'; ?> الجنسية
</label>
                     <select class="form-control" required name="nationality" >
                    <?php 
					if(isset($nationality))
					{
						echo '<option selected="selected" value="'.$nationality.'">'.$country_list[$nationality].'</option>';
					} else {
					?>
                    <option selected="selected" value="" disabled="disabled"><?php echo 'Nationality'; ?></option>
					<?php }
						foreach($country_list as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>
                    </select>
				</div>

					 <div class="form-group">
					 <label for="fullname">National ID رقم الهوية
</label>
                     <input class="form-control" required="required"  name="national_id"   type="text" value="<?php if (isset($national_id)){ echo htmlspecialchars($national_id); } ?>"  placeholder="Enter National ID">
					 </div>
					 <div class="form-group">
					 <label for="fullname">Mobile Number رقم الجوال 
</label>

                     <input class="form-control" required="required"  name="mobile"   type="text" value="<?php if (isset($mobile)){ echo htmlspecialchars($mobile); } ?>" placeholder="Enter Mobile Number">
					 </div>
					 <!--
					 <div class="form-group" style="">
					 <label for="city"><?php echo 'City of Living'; ?> اسم المدينة 
</label>
                     <select class="form-control" required name="city" >
                    <?php 
					if(isset($city))
					{
						echo '<option selected="selected" value="'.$city.'">'.$city_list[$city].'</option>';
					} else {
					?>
                    <option selected="selected" value="" disabled="disabled"><?php echo 'Select Close City of Living'; ?></option>
					<?php }
						foreach($city_list as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>
                    </select>
				</div>
			-->
				  <div class="form-group">
					 <label for="fullname">Date of Registration in Arabic تاريخ تسجيل بالهجري
</label><br />
                     
                     <select class="form-control" required name="dor_day" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($dor_day)){?>
      <option value="<?php echo $dor_day; ?>" selected="selected"><?php echo $dor_day;?></option>
      <?php }else{ ?>
      <option value="" disabled="disabled" selected="selected">Day اليوم
</option>
      <?php } ?>
      <?php
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" required name="dor_month" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($dor_month)){?>
      <option value="<?php echo $dor_month; ?>" selected="selected"><?php echo $dor_month;?></option>
      <?php }else{ ?>
      <option value="" disabled="disabled" selected="selected">Month الشهر
</option>
      <?php } ?>
      <?php
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" required name="dor_year"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($dor_year)){?>
        <option value="<?php echo $dor_year; ?>" selected="selected"><?php echo $dor_year;?></option>
        <?php }else{ ?>
        <option value="" disabled="disabled" selected="selected">Year السنة
</option>
        <?php } ?>
        <?php 
	for ($i=2017; $i<= 2022; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
	 </div>
	

<!--				 
					 <div class="form-group">
					 <label for="fullname">Place of Issue مكان الاصدار 
</label>
                     <select class="form-control" required name="place_issue" >
                    <?php 
					if(isset($place_issue))
					{
						echo '<option selected="selected" value="'.$place_issue.'">'.$city_list[$place_issue].'</option>';
					} else {
					?>
                    <option selected="selected" value="" disabled="disabled"><?php echo 'Select Place of Issue'; ?></option>
					<?php }
						foreach($city_list as $key => $val)
						{
							echo '<option value="'.$key.'">'.$val.'</option>';
						}
                    ?>-->
                    </select>
					 </div>	
					 
					 <!--
					 <div class="form-group">
					 <label for="fullname">Date of ID Expires in Arabic تاريخ انتهاء الهوية بالهجري
</label><br />
                     
                     <select class="form-control" required name="doi_day" style="display:inline-block; width:32%;">
					      <?php 
						  if(isset($doi_day)){?>
					      <option value="<?php echo $doi_day; ?>" selected="selected"><?php echo $doi_day;?></option>
					      <?php }else{ ?>
					      <option value="" disabled="disabled" selected="selected">Day اليوم
</option>
					      <?php } ?>
					      <?php
							 for ($i=1; $i<=31; $i++)
							 {
								echo '<option value="'.$i.'">'.$i.'</option>';
							 }
							?>
					    </select>
      				 <select class="form-control" required name="doi_month" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($doi_month)){?>
      <option value="<?php echo $doi_month; ?>" selected="selected"><?php echo $doi_month;?></option>
      <?php }else{ ?>
      <option value="" disabled="disabled" selected="selected">Month الشهر
</option>
      <?php } ?>
      <?php
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      				 <select class="form-control" required name="doi_year"  style="display:inline-block; width:32%;">
        <?php 
	  if(isset($doi_year)){?>
        <option value="<?php echo $doi_year; ?>" selected="selected"><?php echo $doi_year;?></option>
        <?php }else{ ?>
        <option value="" disabled="disabled" selected="selected">Year السنة
</option>
        <?php } ?>
        <?php 
	for ($i=1490; $i>=1435; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>
					 </div>	
                     -->
                   
<!--
					 
					 
					 <div class="form-group">
					 <label for="fullname">Date of Birth in Arabic تاريخ الميلاد بالهجري
</label><br />

      <select class="form-control" required name="dob_day" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($dob_day)){?>
      <option value="<?php echo $dob_day; ?>" selected="selected"><?php echo $dob_day;?></option>
      <?php }else{ ?>
      <option value="" disabled="disabled" selected="selected">Day اليوم
</option>
      <?php } ?>
      <?php
		 for ($i=1; $i<=31; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      <select class="form-control" required name="dob_month" style="display:inline-block; width:32%;">
      <?php 
	  if(isset($dob_month)){?>
      <option value="<?php echo $dob_month; ?>" selected="selected"><?php echo $dob_month;?></option>
      <?php }else{ ?>
      <option value="" disabled="disabled" selected="selected">Month الشهر
</option>
      <?php } ?>
      <?php
		 for ($i=1; $i<=12; $i++)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
		?>
    </select>
      <select class="form-control" required name="dob_year" id="dob_year" style="display:inline-block; width:32%;">
        <?php 
	  if(isset($dob_year)){?>
        <option value="<?php echo $dob_year; ?>" selected="selected"><?php echo $dob_year;?></option>
        <?php }else{ ?>
        <option value="" disabled="disabled" selected="selected">Year السنة
</option>
        <?php } ?>
        <?php 
	for ($i=1437; $i>=1380; $i--)
		 {
			echo '<option value="'.$i.'">'.$i.'</option>';
		 }
     ?>
      </select>

					 </div>
                </div>
                </div>              
                </div>    

			

		</div>
		</div>
				<div class="col-xs-6" style="margin:0; padding:0;">

                
				<div class="boxback margin10 formtitle">
					 <h4>THIEP Information معلومات عن المعهد الفني العالي للهندسة والبترول
</h4>
				     </div>
				<div class="boxback margin10">
					 <h4>Note:</h4>
                     <ul>
                     <li>By Default, the student will register to PREP course. Once the student completed PREP, the admin can assigned him the Major.</li>
                     <li>Batch Start is the start of the student to THIEP. Make sure you select correct batch year, later you cannot change</li>
                     </ul>
					 
                     
                     
                     
                     

               
-->
 </div>
                </div>  
				<div class="col-xs-6" style="margin:0; padding-bottom: 40px;">

                
				<div class="boxback margin10 formtitle">
					 <h4>Submission تسليم 
</h4>
				     </div>
					<div class="boxback margin10  text-center">
					 <!--
					 <h4>Before you save the application, make sure the below are done</h4>
					 <ul>
					 <li style="color:red;">You have selected the correct Batch. All calculation is as per these options.</li>
                     <li style="color:red;">If you want to change later, you have to delete the student record and enter new record</li>
					 <li>You Physically varify all the documents</li>					 
					 </ul>

					<h4>قبل حفظ هذه المعلومات، تأكد من أكمال التالي:</h4>
					<ul>
					 <li style="color:red;"> تأكد من اختيارك الدفعة الصحيحة من قائمة الخيارات. </li>
					 <li style="color:red;"> لا تستطيع تغير بعد الحفظ إلا عند حذف كل المعلومات وتسجيل من جديد  </li>
					 <li style="color:red;"> عليك التأكد من كل المستندات.   </li>
					</ul>
 



					 </br>
					 -->
			<button style="margin-bottom:4px;" type="submit" class="btn btn-success btn-csuccess" name="enterstudent">Save and Register New Student حفظ و تسجيل طالب جديد 
</button>
<br>
            <button style="margin-bottom:4px;" type="submit" class="btn btn-success btn-csuccess" name="pofilestudent">Save and go to Student Profile حفظ و ذهاب الى ملف الطالب 
</button>
					 
                </div>
                </div> 
                
                </form>
				
	</div>
</div> 

<!-- Footer -->
<?php require('footer.php'); ?> 

</div>
</body>
</html>
