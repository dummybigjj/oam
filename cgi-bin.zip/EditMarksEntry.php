<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}
//print_r($allvar);
//MarksEntry.php?regid=1000004&courseid=20&levelid=12
	
	if(!$_GET['regid'])
	{
		header("location: index.php");
		exit;
	} else {
		$allinfoquery = mysql_query("select * from students where reg_id=".mysql_real_escape_string($_GET['regid'])." and is_active = 'Yes'");
		if(mysql_num_rows($allinfoquery)!= 1)
		{
			header("location: index.php");
			exit;
		}
		
		$reg_id = $_GET['regid'];
		$allinfo = mysql_fetch_assoc($allinfoquery);
	}
	
	if(!$_GET['courseid'] || !$_GET['levelid'] ){
		header("location: index.php");
		exit;
	} else {
		$course_ref_no = mysql_real_escape_string($_GET['courseid']);
		$level_no = mysql_real_escape_string($_GET['levelid']);
		$curr_id = $allinfo['curr_id'];
		$major_id = $allinfo['major_id'];
		$checkcourse = mysql_query("select * from courses where course_ref_no = '$course_ref_no' and level_no = '$level_no' and curr_id = '$curr_id' and major_id = '$major_id'");
		
		
		if( mysql_num_rows($checkcourse)!= 1) {
			header("location: index.php");
			exit;
		} else {
			$fullcourse = mysql_fetch_assoc($checkcourse);
		}
	}
	
	//Check pass fail before
	$passed_before = mysql_query("select * from marks where reg_id = '$reg_id' and course_ref_no = '$course_ref_no' and level_no = '$level_no' and curr_id = '$curr_id' and major_id = '$major_id' and pass_fail = 'Passed'");
	
	if(mysql_num_rows($passed_before) == 1) {
		do_alert("This student has already completed and passed the exam. You cannot edit the marks");
		nextpage("index.php");
		exit;
	} 
	
	$fail_before = mysql_query("select * from marks where reg_id = '$reg_id' and course_ref_no = '$course_ref_no' and level_no = '$level_no' and curr_id = '$curr_id' and major_id = '$major_id' and is_fresh = 'Yes'");
	
	
	if(mysql_num_rows($fail_before) == 1) {
		$fresh_supp = "Supplementary Marks Entry";
		$is_fresh = 'No';
	} else {
		$fresh_supp = "First Time Marks Entry";
		$is_fresh = 'Yes';
	}

	if(isset($_GET['edit'])) {
			$table_id = $_GET['edit'];

			$query = mysql_query("SELECT *  FROM marks WHERE table_id = '$table_id'  AND edit_num !=2 ");
			$numrows = mysql_num_rows($query);
			if ($numrows > 0) {
				$row = mysql_fetch_assoc($query);
				$edit_num_old = $row['edit_num'];
				$old_grade = $row['let_grade'];
			} else {
				do_alert("Please enter marks before editing.");
				nextpage("StudentProfile.php?regid=".$_GET['regid']."&level=10");
			}
		}
	
	
if (isset($_POST['submitmarks'])) {
		$errors = array();
		$subject_1 = $_POST['subject_1'];
		$subject_2 = $_POST['subject_2'];
		$subject_3 = $_POST['subject_3'];
		//$subject_4 = $_POST['subject_4'];	
		
		if($subject_1 == '') {
			$errors[] = "Attendence should not be empty";
		} else if(!preg_match('/^[0-9]{0,10}$/', $subject_1)) {
			$errors[] = "Wrong selection for attendence";
		}

		/**
		if($subject_2 == '') {
			$errors[] = "Class Work should not be empty";
		} else if(!preg_match('/^[0-9]{0,10}$/', $subject_2)) {
			$errors[] = "Wrong selection for Class Work";
		}
		**/
		
		
		if($subject_2 == '') {
			$errors[] = "Mid Term should not be empty";
		} else if(!preg_match('/^[0-9]{0,10}$/', $subject_2)) {
			$errors[] = "Wrong selection for Mid Term";
		}

		if($subject_3 == '') {
			$errors[] = "Final Term should not be empty";
		} else if(!preg_match('/^[0-9]{0,10}$/', $subject_3)) {
			$errors[] = "Wrong selection for Final Term";
		}
		

		//print_r($_POST);
		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){
			$numgrade = $subject_1 + $subject_2 + $subject_3;
			
			if( ($numgrade >= 95) && ($numgrade <= 100)){
				$lg = 'A+';
			} else if( ($numgrade >= 90) && ($numgrade < 95)){
				$lg = 'A';
			} else if( ($numgrade >= 85) && ($numgrade < 90)){
				$lg = 'B+';
			} else if( ($numgrade >= 80) && ($numgrade < 85)){
				$lg = 'B';
			} else if( ($numgrade >= 75) && ($numgrade < 80)){
				$lg = 'C+';
			} else if( ($numgrade >= 70) && ($numgrade < 75)){
				$lg = 'C';
			} else if( ($numgrade >= 65) && ($numgrade < 70)){
				$lg = 'D+';		
			} else if( ($numgrade >= 60) && ($numgrade < 65)){
				$lg = 'D';
			} else {
				$lg = 'F';
			}
			
			if($numgrade < 60){
				$pass_fail = 'Fail';
			} else {
				$pass_fail = 'Passed';
			}

			$table_id = $_GET['edit'];
			//$exam_required = $testneed;
			$entry_user_full_name =  $loginvar['full_name'];						
			$batch_year_id = $allinfo['batch_year_id'];
			$edit_time = date("U");
			$edit_num = $edit_num_old + 1;
			//$isenter = mysql_query("insert into marks (course_ref_no, reg_id, batch_year_id, level_no, major_id, curr_id, attendence, midterm, finalexam, num_grade, let_grade, pass_fail, is_fresh, entry_time, entry_user_full_name) values ('$course_ref_no', '$reg_id', '$batch_year_id', '$level_no', '$major_id', '$curr_id', '$subject_1', '$subject_2', '$subject_3', '$numgrade', '$lg', '$pass_fail', '$is_fresh', '$entry_time', '$entry_user_full_name')");
			//$isenter = mysql_query("UPDATE marks SET attendence = '$subject_1', midterm = '$subject_2', finalexam = '$subject_3', num_grade = '$numgrade', let_grade = '$lg', pass_fail = '$pass_fail', is_fresh = '$is_fresh', edit_time = '$edit_time', edit_num = '$edit_num', edit_user_full_name = '$entry_user_full_name' WHERE table_id = '$table_id' ") or die(mysql_error());
			$isenter = mysql_query("UPDATE marks SET attendence = '$subject_1', midterm = '$subject_2', finalexam = '$subject_3', num_grade = '$numgrade', let_grade = '$lg', pass_fail = '$pass_fail', edit_time = '$edit_time', edit_num = '$edit_num', edit_user_full_name = '$entry_user_full_name' WHERE table_id = '$table_id' ") or die(mysql_error());
			if($isenter){				
					$username = $entry_user_full_name;					
					$type_of_change = "GRADE";
					$orig_data = $old_grade;
					$new_data = $lg;
					$log = mysql_query("INSERT INTO log_entry (username, type_of_change, orig_data, new_data) VALUES ('$username', '$type_of_change', '$orig_data', '$new_data' ) ") or die(mysql_error());
					do_alert("Marks Entered");
					nextpage("StudentProfile.php?regid=".$reg_id);
					exit;				
			} else {
				echo 'Data not entered, contact developer';
			}
						
		}
		
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>

	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

	<script>
		  function sum() {
		  var $ = document.getElementById,
			  f, ddlist, sval, mval,
			  result = 0, maxtotal = 0, percent, lg, remark;
		
		  // try 'ddlist1', 'ddlist2', .. and so on
		  f = 1;
		  while (ddlist = document.getElementById('subject_' + f++)) {
			
			sval = ddlist.options[ddlist.selectedIndex].value;
			mval = ddlist.options[ddlist.options.length - 1].value;
		
			if ( !isNaN(sval) && !isNaN(mval) ) {
			  result += parseFloat(sval);
			  maxtotal += parseFloat(mval);
			}
		  }
		
		  percent = (maxtotal > 0) ? result / maxtotal * 100 : 0;
			
			if( (percent >= 95) && (percent <= 100)){
				lg = 'A+';
			} else if( (percent >= 90) && (percent < 95)){
				lg = 'A';
			} else if( (percent >= 85) && (percent < 90)){
				lg = 'B+';
			} else if( (percent >= 80) && (percent < 85)){
				lg = 'B';
			} else if( (percent >= 75) && (percent < 80)){
				lg = 'C+';
			} else if( (percent >= 70) && (percent < 75)){
				lg = 'C';
			} else if( (percent >= 65) && (percent < 70)){
				lg = 'D+';		
			} else if( (percent >= 60) && (percent < 65)){
				lg = 'D';
			} else {
				lg = 'F';
			}
			
			if(percent < 60){
				remark = 'Fail';
			} else {
				remark = 'Passed';
			}
			
		  document.getElementById('maxtotal').innerHTML = result + ' of ' + maxtotal;
		  document.getElementById('totalper').innerHTML = lg;
		  document.getElementById('allres').innerHTML = remark;
		  //document.getElementById('totalper').innerHTML = percent.toFixed(2) + ' %';
		}

		window.onload = sum;
		</script>
	
</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->
<?php require('menu.php'); ?>   
<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:30px;">
				
                <div class="col-sm-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
				<h4>Marks Entry</h4>
				</div>
                </div>
</div>

<div class="row" style="margin-bottom:40px;">
               <?php 
				if(isset($errors))
				{
					echo '<div class="padding10" style="color:red; font-weight:bold;">';
					echo 'ERRORS';
					echo '<div style="color:red; font-weight:normal;">';
				foreach ($errors as $msg) 
				{ ?>
                    <?php echo ">> $msg<br />\n"; ?>
				<?php }
					echo '</div>';
					echo '</div>';
				}
				?>
                <div class="col-xs-6" style="margin:0; padding:0;">

				 <div class="boxback margin10 formtitle">
					 <h4>Course and Student Information</h4>
				 </div>
				<div class="margin10">
					
<table class="tg">

	 <tr>
    <th class="tg-i9x5 centertext" colspan="2">Course Details</th>
  </tr> 
	<tr>
    <th class="tg-i9x5" style=" text-align:left;">Course Details</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $fullcourse['course_name'].' - '.$fullcourse['course_code']; ?></td>
  </tr>
  <tr>
    <th class="tg-i9x5" style=" text-align:left;">Major</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $glomajor[$fullcourse['major_id']]; ?></td>
  </tr>
  	<tr>
    <th class="tg-i9x5" style=" text-align:left;">Level</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $curr5lvls[$fullcourse['level_no']]; ?></td>
  </tr>
  <tr>
    <th class="tg-i9x5" style=" text-align:left;">Batch Start</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo batch_name_from_id($allinfo['batch_year_id']); ?></td>
  </tr>
  <tr>
    <th class="tg-i9x5" style=" text-align:left;">Curriculum</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo curr_name_from_id($allinfo['curr_id']); ?></td>
  </tr>
   <tr>
    <th class="tg-i9x5 centertext" colspan="2">Students Details</th>
  </tr> 
	<tr>
    <th class="tg-i9x5" style=" text-align:left;">English Name</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $allinfo['english_name']; ?></td>
  </tr>
  
  <tr>
    <th class="tg-i9x5" style=" text-align:left;">National ID</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo '<a href="StudentProfile.php?regid='.$reg_id.'">'.$allinfo['national_id'].'</a>'; ?></td>
  </tr>
  <tr>
    <th class="tg-i9x5" style=" text-align:left; width:150px;">Reg. No</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;"><?php echo $allinfo['reg_id']; ?></td>
  </tr>

</table>

                </div>
                </div>              
				
				<div class="col-xs-6" style="margin:0; padding:0;">

				
                <div class="boxback margin10 formtitle">
					 <h4>Marks Entry</h4>
				     </div>
				<div class="margin10">
     <form action="" method="post" name="marksentry">
<table class="tg">

<tr>
    <th class="tg-i9x5" style=" text-align:left; width:150px;">Classwork/Attendence</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;">
	 <select name="subject_1" id="subject_1" style="min-width:200px" onchange="sum();">
          <option disabled="disabled" selected="selected">Classwork/Attendence</option>
          <?php
		   if($subject_1 != '') {
			   echo '<option selected="selected" value="'.$subject_1.'">'.$subject_1.'</option>';
		   }
		  ?>
          <?php 
		  for($i=0; $i<=30; $i++) {
          echo '<option value="'.$i.'">'.$i.'</option>';
		  } ?>
	</td>
  </tr>
  <!--
	<tr>
    <th class="tg-i9x5" style=" text-align:left;">Class Work</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;">
	<select name="subject_2" id="subject_2" style="min-width:200px" onchange="sum();">
          <option disabled="disabled" selected="selected">Class Work</option>
          <?php
		   if($subject_2 != '') {
			   echo '<option selected="selected" value="'.$subject_2.'">'.$subject_2.'</option>';
		   }
		  ?>
		  <?php 
		  for($i=0; $i<=20; $i++) {
          echo '<option value="'.$i.'">'.$i.'</option>';
		  } ?>     
	</td>
  </tr>
-->
  

  <tr>
    <th class="tg-i9x5" style=" text-align:left;">Mid Term</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;">
	<select name="subject_2" id="subject_2" style="min-width:200px" onchange="sum();">
          <option  disabled="disabled" selected="selected">Mid Term</option>
          <?php
		   if($subject_2 != '') {
			   echo '<option selected="selected" value="'.$subject_2.'">'.$subject_2.'</option>';
		   }
		  ?>
		  <?php 
		  for($i=0; $i<=30; $i++) {
          echo '<option value="'.$i.'">'.$i.'</option>';
		  } ?>
	</td>
  </tr>
  <tr>
    <th class="tg-i9x5" style=" text-align:left;">Final Term</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;">
	<select name="subject_3" id="subject_3" style="min-width:200px" onchange="sum();">
         <option  disabled="disabled" selected="selected">Final Term</option>
         <?php
		   if($subject_3 != '') {
			   echo '<option selected="selected" value="'.$subject_3.'">'.$subject_3.'</option>';
		   }
		  ?>
		 <?php 
		  for($i=0; $i<=40; $i++) {
          echo '<option value="'.$i.'">'.$i.'</option>';
		  } ?>
	</td>
  </tr>
  <tr>
    <th class="tg-i9x5"  style=" text-align:left;">Numerical Grade</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;">
	<span id="maxtotal" style="color:#06F; font-weight:bold;"></span>
	</td>
  </tr>
  <tr>
    <th class="tg-i9x5"  style=" text-align:left;">Letter Grade</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;">
	<span id="totalper" style="color:#06F; font-weight:bold;"></span>
	</td>
  </tr>
  <tr>
    <th class="tg-i9x5"  style=" text-align:left;">Result</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;">
	<span id="allres" style="color:#06F; font-weight:bold;"></span>
	</td>
  </tr>
   <tr>
    <th class="tg-i9x5"  style=" text-align:left;">Exam Detail</th>
	<td class="tg-yw4l" style="padding:10px; text-align:left;">
    
    
<?php echo '<b>'.$fresh_supp.'</b>'; ?>
    
    </td>
  </tr>
  
  <tr>
    <th class="tg-yw4l" colspan="2" style=" text-align:left;">

	<ul>
					 <li>Make sure the information in the left colom is correct. And the result is same as the excel sheet you got from teacher</li>
					 </ul>
					 
<button type="submit" class="btn btn-success btn-csuccess" name="submitmarks">Complete and Save</button>
	
	</th>
  </tr>

</table>
</select>
					
                </div>
                </div>              
				

	</div>
</div> 


<!-- Footer -->
<?php require('footer.php'); ?> 

</div>
</body>
</html>
