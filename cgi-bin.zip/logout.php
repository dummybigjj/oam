<?php
session_start();
require("includes/allincludes.php");
session_destroy();
$_SESSION = NULL;
header("Location:login.php");
?>