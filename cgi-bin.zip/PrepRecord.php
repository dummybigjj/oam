<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}
//http://localhost:8012/thiepapp/PrepRecord.php?regid=1000000&level=10
//http://localhost:8012/thiepapp/PrepRecord.php?regid=1000005&level=10&del=95
$is_edit = $loginvar['del_marks'];

if( (count($_GET) < 2) || empty($_GET['regid']) || ($_GET['level'] != 10) ) {
	header("location: index.php");
	exit;
	
} else if (!empty($_GET['del'])) {
	
	 if( ($is_edit != 'Yes') || (count($_GET) < 3) ) {
		 header("Location: index.php");
		 exit;
	 } 
	 
	 $table_id = mysql_real_escape_string($_GET['del']);
	 $marvarquery = mysql_query("select * from marks where table_id = '$table_id'");
	 
	 if(mysql_num_rows($marvarquery) != 1) {
		header("Location: index.php");
		exit;
	 }
	
	 $marvar = mysql_fetch_assoc($marvarquery);

	 if( mysql_num_rows(mysql_query("select * from marks where reg_id = '".$marvar['reg_id']."' and level_no = '10' and pass_fail = 'Passed'  and table_id != $table_id")) == 1) {
		 do_alert("Student has already passed the exam, you cannot delete the student record. If you want to delete, you have to delete the record which student has already passed");
		 nextpage("PrepRecord.php?regid=".$_GET['regid']."&level=10");
		 exit;
	 }
	 
	
	else {
		$is_del = mysql_query("delete from marks where table_id = '$table_id'");
		if($is_del) {
			header("Location: PrepRecord.php?regid=".$_GET['regid']."&level=10");
			exit;
		} else {
			do_alert("Cannot able to delete, contact developer");
			nextpage("index.php");
			exit;
		}
	}
	
}

 else {
	$reg_id = mysql_real_escape_string($_GET['regid']);
	$level_no = mysql_real_escape_string($_GET['level']);
	$allstu_query = mysql_query("select * from students where reg_id = '$reg_id'");

	if(mysql_num_rows($allstu_query) != 1) {
		nextpage("index.php");
		exit;
		
	} else {
		$stuinfo = mysql_fetch_assoc($allstu_query);
		$curr_id = $stuinfo['curr_id'];
		$major_id = $stuinfo['major_id'];
		$batch_year_id = $stuinfo['batch_year_id'];
	}

  if (isset($_GET['view'])) {
    $view = $_GET['view'];
  } else {
    $view = "Yes";
  }
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>
  
	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="css/font-awesome.min.css" rel="stylesheet">
  <style type="text/css">
    @media print
    {    
        .no-print, .no-print *
        {
            display: none !important;
        }
    }
  </style>

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 

<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:10px;">
				
                <div class="col-xs-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
                <h4><?php echo 'Preparatory Record'; ?></h4><h5><?php echo 'Batch: '.batch_name_from_id($batch_year_id); ?></h5>
				</div>
                </div>
</div>
			 
<div class="row" style="margin-bottom:40px;" id="printableArea">
<div class="col-xs-12" style="margin:0; padding:0;">				 				
<div style="margin-bottom:10px;">	
<table class="tg">
 <tr>
    <th class="tg-i9x5" colspan="2">Fresh Attempt</th>
    </tr>
  <tr>
    <th class="tg-i9x5">#</th>
    <th class="tg-i9x5" style="width:130px;">National ID</th>
    <th class="tg-i9x5">Student Name</th>
    <th class="tg-i9x5 no-print">AT / CW</th>   
    <th class="tg-i9x5 no-print">ME</th>
    <th class="tg-i9x5 no-print">FE</th>
    <th class="tg-i9x5">NG</th>
    <th class="tg-i9x5">LG</th>
    <th class="tg-i9x5">Remarks</th>
    
    <?php  if($is_edit == 'Yes'){
      if ($view == "Yes") {
        
      } else if($view == "No") {
          echo " 
            <th class='tg-i9x5 no-print'>Edit</th>
            <th class='tg-i9x5 no-print'>Delete</th> 
          ";
      }
    
    }
    { ?> <?php } ?>
   
    
  </tr>
  
   <?php 
   $i = 1; 
   $stu_mar_query = mysql_query("select * from marks where reg_id = '$reg_id' and level_no = '10'");
   $numrows = mysql_num_rows($stu_mar_query);
   
   while($stu_mar = mysql_fetch_assoc($stu_mar_query)) {  

	?>
	<tr>
    <td class="tg-yw4l"><?php echo $i; ?></td>
    <td class="tg-yw4l" style="text-align:left;"><?php echo '<a href="StudentProfile.php?regid='.$stuinfo['reg_id'].'">'.$stuinfo['national_id'].'</a>'; ?></td>
    <td class="tg-yw4l" style="text-align:left;"><?php echo $stuinfo['english_name'];?></td>
    <td class="tg-yw4l no-print"><?php if ($stu_mar['attendence']) {
      echo $stu_mar['attendence'];
    } 
    ?></td>
    <!--  <td class="tg-yw4l"><?php // echo $stu_mar['class_work'];?></td>-->
    <td class="tg-yw4l no-print">
      <?php 
        if ($stu_mar['midterm']) {
            echo $stu_mar['midterm'];
        }
      ?>      
    </td>
    <td class="tg-yw4l no-print"><?php echo $stu_mar['finalexam'];?></td>
    <td class="tg-yw4l"><?php echo $stu_mar['num_grade'];?></td>
    <td class="tg-yw4l"><?php echo $stu_mar['let_grade'];?></td>
    <td class="tg-yw4l">
    	<?php 
    		if(empty($stu_mar['pass_fail'])) { 
    			echo '<a class="no-print" href="PrepEntry.php?regid='.$stuinfo['reg_id'].'&prep=entry">Enter Marks</a>'; 
    			}  
    		else if($stu_mar['pass_fail'] == 'Passed'){ 
    			echo $stu_mar['pass_fail']; 
    			}
    		else if($stu_mar['pass_fail'] == 'Fail'){
    			if(mysql_num_rows(mysql_query("select * from marks where reg_id = '$reg_id'  and level_no = '10' and pass_fail = 'Passed'")) == 1 ){
    				echo 'Fail';
    			} else {
    				echo "Fail ".'<a class="no-print" href="PrepEntry.php?regid='.$stuinfo['reg_id'].'&prep=entry">, Enter Marks</a>';
    			} 
    		} 
    		
    		?>
    </td>
    
    
    <?php if($is_edit == 'Yes' && $view == "No") { ?>
    
    <td class="tg-yw4l no-print"> <a href="EditPrepEntry.php?regid=<?php echo $reg_id; ?>&edit_time= <?php echo $stu_mar['edit_num']; ?>&edit=<?php echo $stu_mar['table_id']; ?>">Edit</a> </td>
     <td class="tg-yw4l no-print"><a onclick="return confirm('Are you sure you want to continue?')" href="PrepRecord.php?regid=<?php echo $reg_id; ?>&level=<?php echo $level_no; ?>&del=<?php echo $stu_mar['table_id']; ?>">Delete</a> </td>
     
    
    

    <?php } ?>
   
    
  
    </tr>
   <?php 
   $i++;
   }
  ?>

  </table>
				 
 </div>
               
				
 <div class="col-xs-4" style="margin:0; padding:0;" >
 <div style="margin-bottom:10px;">
     <table class="tg" style="margin:0; padding:0;">
        <tr>
          <th class="tg-i9x5" colspan="2">Legends</th>
          <th class="tg-i9x5">Max Marks</th>
        </tr>
        <tr>
          <td class="tg-yw4l">CW</td>
          <td class="tg-yw4l" style="text-align:left;">Attendence / Class Work</td>
          <td class="tg-yw4l">30</td>
        </tr>
        <tr>
          <td class="tg-yw4l">ME</td>
          <td class="tg-yw4l" style="text-align:left;">Midterm Exam</td>
          <td class="tg-yw4l">30</td>
        </tr>
        <tr>
          <td class="tg-yw4l">FE</td>
          <td class="tg-yw4l" style="text-align:left;">Final Exam</td>
          <td class="tg-yw4l">40</td>
        </tr>
        <tr>
          <td class="tg-yw4l">NG</td>
          <td class="tg-yw4l" style="text-align:left;">Numerical Grade</td>
          <td class="tg-yw4l">100</td>
        </tr>
         <tr>
          <td class="tg-yw4l">LG</td>
          <td class="tg-yw4l" style="text-align:left;">Letter Grade</td>
          <td class="tg-yw4l">A+</td>
        </tr>
      </table>
  </div>
 </div>
 <div class="" style="margin:0; padding:0;">   
      <br><br><br><br><br><br>      
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="button" class="btn btn-success no-print pull-right" onclick="myFunction()" value="PRINT" />   
 </div>      
  
	</div>                 
	</div>
</div> 

<script type="text/javascript">
 function myFunction() {
    window.print();
}
</script>

<!-- Footer -->
<?php require('footer.php'); ?> 

</div>
</body>
</html>
