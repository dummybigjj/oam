<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}


if(count($_GET) < 3) {
	header("location: index.php");
	exit;
} else {
	$curr_id = mysql_real_escape_string($_GET['curr']);
	$major_id = mysql_real_escape_string($_GET['major']);
	$level_no = mysql_real_escape_string($_GET['level']);
	
	
	$currvalquery = mysql_query("select * from curr_detail where curr_id = '$curr_id' and is_complete_data = 'No'");
	if(mysql_num_rows($currvalquery) != 1) {
		header("location: index.php");
		exit;
	}
	
	if(!array_key_exists($major_id, $glomajor)) {
		header("location: index.php");
		exit;
	}
	
	$currval = mysql_fetch_assoc($currvalquery);
	if($currval['levels'] == 4){
		if(!array_key_exists($level_no, $curr4lvls)) {
		header("location: index.php");
		exit;
		}
	} else {
		if(!array_key_exists($level_no, $curr5lvls)) {
		header("location: index.php");
		exit;
		}
	}
	
	
	if(mysql_num_rows(mysql_query("select * from courses where curr_id = '$curr_id' and level_no = '$level_no' and major_id = '$major_id'")) != 0) {
		header("location: index.php");
		exit;
	}
}

$errors = array();
$coursesall = array();
$codesall = array();
$creditall = array();
$j = 0;
if (isset($_POST['submitcourse']) || isset($_POST['checkall']) ) {	
	for($i = 1; $i<=10; $i++)
	{
		${'course'.$i} = trim(implode(' ', preg_split('/\s+/', $_POST['course'.$i])));
		${'code'.$i} = trim(implode(' ', preg_split('/\s+/', $_POST['code'.$i])));
		${'credit'.$i} = trim($_POST['credit'.$i]);
		
		//..........
		if(!empty(${'course'.$i})) {
			if(!preg_match('/^[a-zA-Z0-9 ]{4,40}$/', ${'course'.$i})) {
			$errors[] = 'FullName to be from 4-40 char or digits for Course '.$i;
			}
				$coursesall[] = ${'course'.$i};
		}
		
		//..........
		if(!empty(${'code'.$i})) {
			if(!preg_match('/^[a-zA-Z0-9 ]{3,16}$/', ${'code'.$i})) {
				$errors[] = 'Code to be from 3-16 char or digits for Course '.$i;
			}
				$codesall[] = ${'code'.$i};
		}
		
		//..........
		if(${'credit'.$i} != '') {
			if(!preg_match('/^[1-9]{1}$/', ${'credit'.$i})) {
				$errors[] = 'Credit to be only 1 digit from 1-9 for Course '.$i;
			} 
				$creditall[] = ${'credit'.$i};
		}
				
		//..........
		if($i == 10){
			if( (count($coursesall) != count($codesall)) || (count($codesall) != count($creditall)) ) {
				$errors[] = 'All the three fields course, code and credit has to be filled';
			}
		}
		
		//..........
		if( ((count($coursesall) < 3) || (count($codesall) < 3) || (count($creditall) < 3)) && ($i == 10) )
		{
			$errors[] = "You have to enter minimum 3 courses";
		}
		
		$errors = array_filter($errors, 'strlen');
		if(empty($errors) && isset($_POST['submitcourse']) && !empty(${'course'.$i}) && !empty(${'code'.$i}) && !empty(${'credit'.$i}) ){
			$course_no = mysql_fetch_array(mysql_query("SELECT course_ref_no FROM courses ORDER BY course_ref_no DESC"));
			$course_ref_no = $course_no[0] + 1;
			$course_code = mysql_real_escape_string(${'code'.$i});
			$course_name = mysql_real_escape_string(${'course'.$i});
			$credit_hour = mysql_real_escape_string(${'credit'.$i});
			
			
			$isenter = mysql_query("INSERT INTO courses (course_ref_no, course_code, course_name, credit_hour, level_no, curr_id, major_id) VALUES ('$course_ref_no', '$course_code', '$course_name', '$credit_hour', '$level_no', '$curr_id', '$major_id')");
			
			if(!$isenter){
				exit;
				do_alert("Data cannot enter, contact developer");
				nextpage("CurriculumEntry.php");
				exit;
			}
			
			if(isset($isenter)) {
				$j++;
				$countcourses = $j;
			}
		}
	}
	
	//$i ==1 because its $i++ in the for loop
	if(isset($countcourses)) {
		do_alert("You have register $countcourses courses, you'll go back to curriculumentry.php");
		nextpage("CurriculumEntry.php");
		exit; 
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>

	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>


<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 

<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:30px;">
				
                <div class="col-sm-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
				<h4><?php echo $glomajor[$major_id]; ?></h4>
				</div>
                </div>
</div>

<div class="row" style="margin-bottom:10px;">
                <div class="col-sm-12 col-md-12" style="margin:0; padding:0;">

				 
				 
				 <div class="boxback margin10">

					 <h4>Follow the below steps to Register a Curriculum</h4>
					 <ul>
					 <li style="color:red;">You cannot make any changes in the future. Please enter carefully</li>
					 <li>Proceed to Colom 1 first if required than proceed to colom 2</li>
					 <li>Enter the Correct Full name, Code and the Credit Hours of Course as mentioned in the TVTC Curriculum</li>
					 <li>Once done click Register</li>
					 </ul>
					 </div>
			</div>
		</div>
				 
<div class="row" style="margin-bottom:40px;">
               
               	 <div class="col-xs-12" style="margin:0; padding:0;">	
                 <div class="boxback margin10 formtitle">
			     <h4><?php echo $curr5lvls[$level_no].' Course Registration'; ?></h4>
				 </div>
                 </div>
                 
                <?php 
				if(isset($errors) && !empty($errors))
				{

					echo '<div class="padding10" style="color:red; font-weight:bold;">';
					echo 'ERRORS';
					echo '<div style="color:red; font-weight:normal;">';
				foreach ($errors as $msg) 
				{ ?>
                    <?php echo ">> $msg<br />\n"; ?>
				<?php }
					echo '</div>';
					echo '</div>';
				}
				
				if(empty($errors) && isset($_POST['checkall']) ){
					echo '<div class="padding10" style="color:#fff; margin:10px;  background-color:green; font-weight:bold;">';
					echo "PERFECT: Now you can click 'Save Courses'. if you want to make changes you have to click 'Check for Errors' first before you finish. After you click 'Save Courses' you cannot edit, its fixed. So make sure all is well written";
					echo '</div>';
				}
				?>
                 
                <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])).'?curr='.$_GET['curr'].'&major='.$_GET['major'].'&level='.$_GET['level']; ?>" method="post" name="levelentry">
                <div class="col-xs-6" style="margin:0; padding:0;">				 
				<div class="boxback margin10">
					<div class="form-group">
						<label>Curriculum Name: </label>
						<input type="text" name="currname" class="form-control">
					</div>
					<?php for($i = 1; $i<=5; $i++) { ?>
                     
                     <div class="form-group">
					 <label for="fullname"><?php echo "Course ".$i; ?></label>
					 <input class="form-control" style="margin-bottom:4px; color:#C0F;" type="text" name="<?php echo "course".$i; ?>" value="<?php if(isset(${'course'.$i})){
					 	 	echo ${'course'.$i}; }
					 ?>" placeholder="<?php echo 'Enter Full Name of Course '.$i; ?>"/>
					 <div class="input-group">
						<input type="text" class="form-control" style="color:#C0F;" name="<?php echo "code".$i; ?>" value="<?php if(isset(${'code'.$i})){
					 	 	echo ${'code'.$i}; } ?>" placeholder="<?php echo 'TVTC code for Course '.$i; ?>"/>
						<span class="input-group-addon">-</span>
						<input type="text" class="form-control" style="color:#C0F;" name="<?php echo "credit".$i; ?>" value="<?php if (isset(${'credit'.$i})) {
							echo ${'credit'.$i};
						}
						  ?>" placeholder="<?php echo 'TVTC Credit Hour for Course '.$i; ?>"/>
					</div>
					</div>
                    <?php } ?>
                </div>
                </div> 
                             
				<div class="col-xs-6 " style="margin:0; padding:0;">				 
				<div class="boxback margin10">
					<?php for($i = 6; $i<=10; $i++) { ?>
                     
                     <div class="form-group">
					 <label for="fullname"><?php echo "Course ".$i; ?></label>
					 <input class="form-control" style="margin-bottom:4px; color:#C0F;" type="text" name="<?php echo "course".$i; ?>" value="<?php if(isset(${'course'.$i})){
					 	 	echo ${'course'.$i}; }
					 ?>" placeholder="<?php echo 'Enter Full Name of Course '.$i; ?>"/>
					 <div class="input-group">
						<input type="text" class="form-control" style="color:#C0F;" name="<?php echo "code".$i; ?>" value="<?php if(isset(${'code'.$i})){
					 	 	echo ${'code'.$i}; } ?>" placeholder="<?php echo 'TVTC code for Course '.$i; ?>"/>
						<span class="input-group-addon">-</span>
						<input type="text" class="form-control" style="color:#C0F;" name="<?php echo "credit".$i; ?>" value="<?php if (isset(${'credit'.$i})) {
							echo ${'credit'.$i};
						}
						  ?>" placeholder="<?php echo 'TVTC Credit Hour for Course '.$i; ?>"/>
					</div>
					</div>
                    <?php } ?>
					 <button type="submit" class="btn btn-success btn-csuccess" style="background-color:#C60;" name="checkall">Check for Errors</button>
                     <?php if(empty($errors) && isset($_POST['checkall'])) { ?>
                     <button type="submit" class="btn btn-success btn-csuccess" name="submitcourse">Save Courses</button>
                     <?php } ?>
                </div>
                </div> 
                </form>             
			
	</div>
</div> 


<!-- Footer -->
<?php require('footer.php'); ?> 

</div>
</body>
</html>
