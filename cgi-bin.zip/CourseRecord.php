<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}
//http://localhost:8012/thiepapp/CourseRecord.php?need=enter&curr=1&level=12&major=12&batchid=14&courid=20

if( count($_GET) < 5 ) {
	header("location: index.php");
	exit;
} else {
	$curr_id = mysql_real_escape_string($_GET['curr']);
	$major_id = mysql_real_escape_string($_GET['major']);
	$batch_year_id = mysql_real_escape_string($_GET['batchid']);
	$level_no = mysql_real_escape_string($_GET['level']);
	$course_ref_no = mysql_real_escape_string($_GET['courid']);
	
	$allstu_query = mysql_query("select * from students where curr_id = '$curr_id' and major_id = '$major_id' and batch_year_id = '$batch_year_id' and is_active = 'Yes'");
	
	if(mysql_num_rows($allstu_query) < 1) {
		do_alert("No student registered yet or information doesn't exist");
		nextpage("index.php");
		exit;
	}
	$allcoursesquery = mysql_query("select * from courses where curr_id = '$curr_id' and level_no = '$level_no' and major_id = '$major_id' and course_ref_no = '$course_ref_no'");
	if(mysql_num_rows($allcoursesquery) != 1){
		header("location: index.php");
		exit;
	} else {
		$allcourses = mysql_fetch_assoc($allcoursesquery);
	}
	
	
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>
  
	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 

<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:10px;">
				
                <div class="col-xs-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
                <h4><?php echo $glomajor[$major_id]; ?></h4><h5><?php echo 'Batch: '.batch_name_from_id($batch_year_id).', '.$curr5lvls[$level_no].', Course Record'; ?></h5>
				<h5><?php echo $allcourses['course_name'].', ('.$allcourses['course_code'].')'; ?></h5>
				</div>
                </div>
</div>
			 
<div class="row" style="margin-bottom:40px;">
                <div class="col-xs-12" style="margin:0; padding:0;">				 

				
				<div style="margin-bottom:10px;">
				
				

<table class="tg">
 <tr>
    <th class="tg-i9x5" colspan="2">Fresh Attempt</th>
    </tr>
  <tr>
    <th class="tg-i9x5">#</th>
    <th class="tg-i9x5" style="width:130px;">National ID</th>
    <th class="tg-i9x5">Student Name</th>
    <th class="tg-i9x5">CW</th>
    <th class="tg-i9x5">ME</th>
    <th class="tg-i9x5">FE</th>
    <th class="tg-i9x5">NG</th>
    <th class="tg-i9x5">LG</th>
    <th class="tg-i9x5">Remarks</th>
  </tr>
  
   <?php 
   $i = 1; 
   while($allstudents = mysql_fetch_assoc($allstu_query)) {  
	$reg_id = $allstudents['reg_id'];
		$stu_mar_query = mysql_query("select * from marks where reg_id = '$reg_id' and course_ref_no = '$course_ref_no' and level_no = '$level_no' and curr_id = '$curr_id' and major_id = '$major_id' and is_fresh = 'Yes'");
	$stu_mar = mysql_fetch_assoc($stu_mar_query);
	?>
	<tr>
    <td class="tg-yw4l"><?php echo $i; ?></td>
<td class="tg-yw4l" style="text-align:left;"><?php echo '<a href="StudentProfile.php?regid='.$allstudents['reg_id'].'">'.$allstudents['national_id'].'</a>'; ?></td>
    <td class="tg-yw4l" style="text-align:left;"><?php echo $allstudents['english_name'];?></td>
    <td class="tg-yw4l"><?php echo $stu_mar['attendence'];?></td>
    <td class="tg-yw4l"><?php echo $stu_mar['midterm'];?></td>
    <td class="tg-yw4l"><?php echo $stu_mar['finalexam'];?></td>
    <td class="tg-yw4l"><?php echo $stu_mar['num_grade'];?></td>
    <td class="tg-yw4l"><?php echo $stu_mar['let_grade'];?></td>
    <td class="tg-yw4l">
	<?php 
		if(empty($stu_mar['pass_fail'])) { 
			echo '<a href="MarksEntry.php?regid='.$allstudents['reg_id'].'&courseid='.$course_ref_no.'&levelid='.$level_no.'" >Enter Marks</a>'; 
			}  
		else if($stu_mar['pass_fail'] == 'Passed'){ 
			echo $stu_mar['pass_fail']; 
			}
		else if($stu_mar['pass_fail'] == 'Fail'){
			if(mysql_num_rows(mysql_query("select * from marks where reg_id = '$reg_id'  and course_ref_no = '$course_ref_no' and level_no = '$level_no' and curr_id = '$curr_id'  and major_id = '$major_id' and pass_fail = 'Passed'")) == 1 ){
				echo 'Fail, Passed';
			} else {
				echo "Fail, ".'<a href="MarksEntry.php?regid='.$allstudents['reg_id'].'&courseid='.$course_ref_no.'&levelid='.$level_no.'" >Enter Marks</a>';
			}
		}
		
		?>
    </td>
    </tr>
   <?php 
   $i++;
   }
  ?>

  </table>
				 
                </div>
               
				
 <div class="col-xs-4" style="margin:0; padding:0;">
 <div style="margin-bottom:10px;">
 <table class="tg" style="margin:0; padding:0;">
  <tr>
    <th class="tg-i9x5" colspan="2">Legends</th>
    <th class="tg-i9x5">Max Marks</th>
  </tr>
  <tr>
    <td class="tg-yw4l">CW</td>
    <td class="tg-yw4l" style="text-align:left;">Attenence / Class Work</td>
    <td class="tg-yw4l">30</td>
  </tr>
  <tr>
    <td class="tg-yw4l">ME</td>
    <td class="tg-yw4l" style="text-align:left;">Midterm Exam</td>
    <td class="tg-yw4l">30</td>
  </tr>
  <tr>
    <td class="tg-yw4l">FE</td>
    <td class="tg-yw4l" style="text-align:left;">Final Exam</td>
    <td class="tg-yw4l">40</td>
  </tr>
  <tr>
    <td class="tg-yw4l">NG</td>
    <td class="tg-yw4l" style="text-align:left;">Numerical Grade</td>
    <td class="tg-yw4l">100</td>
  </tr>
   <tr>
    <td class="tg-yw4l">LG</td>
    <td class="tg-yw4l" style="text-align:left;">Letter Grade</td>
    <td class="tg-yw4l">A+</td>
  </tr>
</table>
</div>
 </div>

			   </div> 
                
                
				</div>


</div> 


<!-- Footer -->
<?php require('footer.php'); ?> 

</div>
</body>
</html>
