<?php 
if (isset($_POST['submit'])) {
	
	$name = "<u>".strtoupper($_POST['sname'])."</u>";
	
	$course = "<u>".strtoupper($_POST['course'])."</u>";
	$ds = "<u>".date("F d\<\s\u\p\>S\<\/\s\u\p\>, Y", strtotime($_POST['ds']))."</u>";
	$df = "<u>".date("F d\<\s\u\p\>S\<\/\s\u\p\>, Y", strtotime($_POST['df']))."</u>";
	$dg = "<u>".date("F d\<\s\u\p\>S\<\/\s\u\p\>, Y", strtotime($_POST['dg']))."</u>";
	
} else {
	header("location: create-certificate.php");
}
	
?>


<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Print Certificate</title>	
	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    
    <link href="css/font-awesome.min.css" rel="stylesheet">
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">    
    <link href="https://fonts.googleapis.com/css?family=Asar" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Diplomata" rel="stylesheet">
	<style type="text/css">
		div sup{
			text-decoration: none !important;
			padding-bottom: 0px;			
		}
	</style>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>
<body>	
	<div class="row" style="padding-top: 20px;">
		<div class="col-xs-4 text-center" style="font-size: 20px;" >
			<h5 style="padding:0; margin:0px;">Technical Higher Institute for</h5>
			<h5 style="padding:0; margin:0px;">Engineering and Petroleum (THIEP)</h5>
			<h6 style="padding:0; margin:0px;">Under the supervision of</h6>
			<h6 style="padding:0; margin:0px;">The General Organization for Technical and</h6>
			<h6 style="padding:0; margin:0px;">Vocational Training</h6>
			<h6 style="padding:0; margin:0px;">Lic, No: 214/6777</h6>
		</div>

		<div class="col-xs-4">
			<img class="img-responsive imagecenter" src="img/logo.png" />
		</div>

		<div class="col-xs-4 text-center" style="font-size: 20px;">
			<h5 style="padding:0; margin:0px;">المعهد التقني العالي</h5>
			<h5 style="padding:0; margin:0px;">(للهندسة والبترول (ذيـب</h5>
			<h6 style="padding:0; margin:0px;">تحت اشراف</h6>
			<h6 style="padding:0; margin:0px;">المؤسسة العامة</h6>
			<h6 style="padding:0; margin:0px;">للتدريب التقني والمهني</h6>
			<h6 style="padding:0; margin:0px;">ترخيص رقم: 6775/214</h6>
		</div>
	</div>

	<div class="container">
		<h3 class="text-center" style="color: blue; font-weight: bold;">TECHNICAL HIGHER INSTITUTE <br>
		FOR ENGINEERING AND PETROLEUM</h3>

		<h1 class="text-center" style="font-weight: bold; color: red;"> CERTIFICATE OF COMPLETION </h1>
		<br>
		<p class="text-center text-justify" style="font-size: 28px; font-family: 'Asar', 'serif'; "> <i> This is to certify that <?php echo $name; ?> has already 
			completed the training for <?php echo $course;  ?> from <?php echo $ds; ?>
			to <?php echo $df; ?>.
			Given this <?php echo $dg; ?> at the THIEP Auditorium on Dharan, Dammam, Kingdom Saudi Arabia </i>
	</div>
	<br><br><br>
		<div class="row">
			<div class="col-sm-4 text-center">
				___________________________<BR>
				<b> Engr. Abdullah Busaidi Aziz </b> <br>
				Trainer
			</div>
			<div class="col-sm-4">
			</div>
			<div class="col-sm-3 text-center">
				___________________________<BR>
				<b> Dr. Ali Sullaiman Khamis </b> <br>
				Institute Manager
			</div>
		</div>
		<div class="container" style="padding: 30px;">
				<button type="button" onclick="myFunction();" class="btn btn-success no-print pull-right" > Print</button>
		</div>
	

	<script type="text/javascript">
 function myFunction() {
    window.print();
}
</script>
</body>
</html>