<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}
//print_r($allvar);


if (isset($_POST['reglev4']))
	{
		$errors = array();
		
		$curr_name4 = trim(implode(' ', preg_split('/\s+/', $_POST['curr_name4'])));
		
		$lvl41 = trim(implode(' ', preg_split('/\s+/', $_POST['lvl41'])));
		$lvl42 = trim(implode(' ', preg_split('/\s+/', $_POST['lvl42'])));
		$lvl43 = trim(implode(' ', preg_split('/\s+/', $_POST['lvl43'])));
		$lvl44 = trim(implode(' ', preg_split('/\s+/', $_POST['lvl44'])));
		
		$code41 = trim(implode(' ', preg_split('/\s+/', $_POST['code41'])));
		$code42 = trim(implode(' ', preg_split('/\s+/', $_POST['code42'])));
		$code43 = trim(implode(' ', preg_split('/\s+/', $_POST['code43'])));
		$code44 = trim(implode(' ', preg_split('/\s+/', $_POST['code44'])));
		
		//..........
		if(empty($curr_name4)) {
			$errors[] = 'Please enter the Full Name of Curriculum.'; 
		} else {
			if(!preg_match('/^[a-zA-Z0-9 ]{4,20}$/', $curr_name4)) {
				$errors[] = 'Curriculum name shall be between 4 - 20 char';
			}
		}
		
		//..........
		if(empty($lvl41)) {
			$errors[] = 'Please enter the Full Name of Level 1.'; 
		} else {
			if(!preg_match('/^[a-zA-Z0-9 ]{4,20}$/', $lvl41)) {
				$errors[] = 'Level 1 name shall be between 4 - 20 char.';
			}
		}
		
		//..........
		if(empty($lvl42)) {
			$errors[] = 'Please enter the Full Name of Level 2.'; 
		} else {
			if(!preg_match('/^[a-zA-Z0-9 ]{4,20}$/', $lvl42)) {
				$errors[] = 'Level 2 name shall be between 4 - 20 char.';
			}
		}
		
		//..........
		if(empty($lvl43)) {
			$errors[] = 'Please enter the Full Name of Level 3.'; 
		} else {
			if(!preg_match('/^[a-zA-Z0-9 ]{4,20}$/', $lvl43)) {
				$errors[] = 'Level 3 name shall be between 4 - 20 char.';
			}
		}
		
		//..........
		if(empty($lvl44)) {
			$errors[] = 'Please enter the Full Name of Level 4.'; 
		} else {
			if(!preg_match('/^[a-zA-Z0-9 ]{4,20}$/', $lvl44)) {
				$errors[] = 'Level 4 name shall be between 4 - 20 char';
			}
		}
		
		
		//..........
		if(empty($code41)) {
			$errors[] = 'Please enter the Level 1 Code.'; 
		} else {
			if(!preg_match('/^[a-zA-Z0-9 ]{4,20}$/', $code41)) {
				$errors[] = 'Level 1 code to be min of 3-9 char';
			}
		}
		
		//..........
		if(empty($code41)) {
			$errors[] = 'Please enter the Level 1 Code.'; 
		} else {
			if(!preg_match('/^[a-zA-Z0-9 ]{4,20}$/', $code41)) {
				$errors[] = 'Level 1 code to be of 3-9 char';
			}
		}
		
		//..........
		if(empty($code42)) {
			$errors[] = 'Please enter the Level 2 Code.'; 
		} else {
			if(!preg_match('/^[a-zA-Z0-9 ]{4,20}$/', $code41)) {
				$errors[] = 'Level 2 code to be of 3-9 char';
			}
		}
		
		//..........
		if(empty($code43)) {
			$errors[] = 'Please enter the Level 3 Code.'; 
		} else {
			if(!preg_match('/^[a-zA-Z0-9 ]{4,20}$/', $code41)) {
				$errors[] = 'Level 3 code to be of 3-9 char';
			}
		}
		
		//..........
		if(empty($code44)) {
			$errors[] = 'Please enter the Level 4 Code.'; 
		} else {
			if(!preg_match('/^[a-zA-Z0-9 ]{4,20}$/', $code41)) {
				$errors[] = 'Level 4 code to be of 3-9 char';
			}
		}
		
		//print_r($_POST);
		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){
			$curr_reg_id = mysql_fetch_array(mysql_query("SELECT curr_id FROM curr_detail ORDER BY curr_id DESC"));
			$curr_id = $curr_reg_id[0] + 1;
			$entry_user_full_name = 'Alvin Desalva';
			$entry_time = date("U");
			
			
		}
		
	}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>

	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 

<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:30px;">
				
                <div class="col-sm-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
				<h4>Curriculum Registration</h4>
				</div>
                </div>
</div>

<div class="row" style="margin-bottom:10px;">
                <div class="col-sm-12 col-md-12" style="margin:0; padding:0;">

				 
				 
				 <div class="boxback margin10">

					 <h4>Follow the below steps to Register a Curriculum</h4>
					 <ul>
					 <li style="color:red;">You cannot make any changes in the future. Please enter carefully</li>
					 <li>Proceed to only the colom which you need, either 4 or 5 levels of Curriculum</li>
					 <li>Define any name to the Curriculum in "Full Name of Curriculum" field only for your referance in future.Example, "4 Level Curriculum" or "Curriculum for 2015-2016" etc</li>
					 <li>Enter the Level Name and the Code Name like Full Name is "Level 1" and Code is "LVL1"</li>
					 <li>Once done click Register</li>
					 </ul>
					 </div>
			</div>
		</div>
				 
<div class="row" style="margin-bottom:40px;">
                
                <?php 
				if($errors)
				{
					echo '<div class="padding10" style="color:red; font-weight:bold;">';
				foreach ($errors as $msg) 
				{ ?>
                    <?php echo "- $msg<br />\n"; ?>
				<?php }
					echo '</div>';
				}
				?>
                
                <div class="col-sm-6 col-md-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4>4 Level Curriculum Registration</h4>
				 </div>
				
                <form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="level4currreg">
				<div class="boxback margin10">
					 
					 <div class="form-group">
					 <label for="fullname">Full Name of Curriculum</label>
                     <input class="form-control"  type="text" name="curr_name4" value="<?php echo htmlspecialchars($curr_name4); ?>" placeholder="Enter Full Name of Curriculum">
					 </div>
					 
					 <div class="form-group">
					 <label for="fullname">Level 1</label>
					 <div class="input-group">
						<input type="text" class="form-control" placeholder="Enter Full Name of Level" name="lvl41" value="<?php echo htmlspecialchars($lvl41); ?>"/>
						<span class="input-group-addon">-</span>
						<input type="text" class="form-control" placeholder="Enter the Code of Level" name="code41" value="<?php echo htmlspecialchars($code41); ?>"/>
					</div>
					</div>

					 <div class="form-group">
					 <label for="fullname">Level 2</label>
					 <div class="input-group">
						<input type="text" class="form-control" placeholder="Enter Full Name of Level" name="lvl42" value="<?php echo htmlspecialchars($lvl42); ?>"/>
						<span class="input-group-addon">-</span>
						<input type="text" class="form-control" placeholder="Enter the Code of Level" name="code42" value="<?php echo htmlspecialchars($code42); ?>"/>
					</div>
					</div>
					
					<div class="form-group">
					 <label for="fullname">Level 3</label>
					 <div class="input-group">
						<input type="text" class="form-control" placeholder="Enter Full Name of Level" name="lvl43" value="<?php echo htmlspecialchars($lvl43); ?>"/>
						<span class="input-group-addon">-</span>
						<input type="text" class="form-control" placeholder="Enter the Code of Level" name="code43" value="<?php echo htmlspecialchars($code43); ?>"/>
					</div>
					</div>

					 <div class="form-group">
					 <label for="fullname">Level 4</label>
					 <div class="input-group">
						<input type="text" class="form-control" placeholder="Enter Full Name of Level" name="lvl44" value="<?php echo htmlspecialchars($lvl44); ?>"/>
						<span class="input-group-addon">-</span>
						<input type="text" class="form-control" placeholder="Enter the Code of Level" name="code44" value="<?php echo htmlspecialchars($code44); ?>"/>
					</div>
					</div>			
					 
					 <br><br>
					 <button type="submit" class="btn btn-success btn-csuccess" name="reglev4">Register 4 Level Curriculum</button>
					 
                </div>
                </form>
                </div>              
				
				 <div class="col-sm-6 col-md-6" style="margin:0; padding:0;">				 
				 
				
				<div class="boxback margin10 formtitle">
					 <h4>5 Level Curriculum Registration</h4>
				 </div>
				<form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="level5currreg">
				<div class="boxback margin10">
					 
					 <div class="form-group">
					 <label for="fullname">Full Name of Curriculum</label>
                     <input class="form-control" type="text" name="curr_name5" value="<?php echo htmlspecialchars($curr_name5); ?>" placeholder="Enter Full Name of Curriculum">
					 </div>
					 
					 <div class="form-group">
					 <label for="fullname">Level 1</label>
					 <div class="input-group">
						<input type="text" class="form-control" placeholder="Enter Full Name of Level" name="lvl51" value="<?php echo htmlspecialchars($lvl51); ?>"/>
						<span class="input-group-addon">-</span>
						<input type="text" class="form-control" placeholder="Enter the Code of Level" name="code51" value="<?php echo htmlspecialchars($code51); ?>"/>
					</div>
					</div>

					 <div class="form-group">
					 <label for="fullname">Level 2</label>
					 <div class="input-group">
						<input type="text" class="form-control" placeholder="Enter Full Name of Level" name="lvl52" value="<?php echo htmlspecialchars($lvl52); ?>"/>
						<span class="input-group-addon">-</span>
						<input type="text" class="form-control" placeholder="Enter the Code of Level" name="code52" value="<?php echo htmlspecialchars($code52); ?>"/>
					</div>
					</div>
					
					<div class="form-group">
					 <label for="fullname">Level 3</label>
					 <div class="input-group">
						<input type="text" class="form-control" placeholder="Enter Full Name of Level" name="lvl53" value="<?php echo htmlspecialchars($lvl53); ?>"/>
						<span class="input-group-addon">-</span>
						<input type="text" class="form-control" placeholder="Enter the Code of Level" name="code53" value="<?php echo htmlspecialchars($code53); ?>"/>
					</div>
					</div>

					 <div class="form-group">
					 <label for="fullname">Level 4</label>
					 <div class="input-group">
						<input type="text" class="form-control" placeholder="Enter Full Name of Level" name="lvl54" value="<?php echo htmlspecialchars($lvl54); ?>"/>
						<span class="input-group-addon">-</span>
						<input type="text" class="form-control" placeholder="Enter the Code of Level" name="code54" value="<?php echo htmlspecialchars($code54); ?>"/>
					</div>
					</div>

					<div class="form-group">
					 <label for="fullname">Level 5</label>
					 <div class="input-group">
						<input type="text" class="form-control" placeholder="Enter Full Name of Level" name="lvl55" value="<?php echo htmlspecialchars($lvl55); ?>"/>
						<span class="input-group-addon">-</span>
						<input type="text" class="form-control" placeholder="Enter the Code of Level" name="code55" value="<?php echo htmlspecialchars($code55); ?>"/>
					</div>
					</div>
					 
					 <br>
					 <button type="submit" class="btn btn-success btn-csuccess" name="reglev5">Register 5 Level Curriculum</button>
					 
                </div>
                </form>
                </div>              		
	</div>
</div> 


<!-- Footer -->
<?php require('footer.php'); ?> 

</div>
</body>
</html>
