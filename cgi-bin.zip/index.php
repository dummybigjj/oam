<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>

	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
    
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

    

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body hold-transition skin-blue layout-top-nav>
<div class="container-fluid">
<!-- NAVBAR HEADER -->

<!-- All Bottom of the Header -->
<?php require('menu.php'); ?>

<div class="width1200">
<div class="row" style="margin-bottom:30px;">

                <div class="col-sm-12" style="margin:0; padding:0; margin:0 auto; text-align:center;">
                <div style="padding:0 4px;">

                <img src="img/logo.png" />
				</div>
                </div>
</div>
<div class="row" style="margin-bottom:30px;">

                <div class="col-sm-12" style="margin:0; padding:0; margin:0 auto; text-align:center;">
                <div style="padding:0 4px;">
                <form action="<?php echo htmlspecialchars('SearchStudents.php'); ?>" method="get" autocomplete="off">
				<input type="search" name="stuneed" style="min-width:600px; padding:10px;" placeholder="Enter Reg ID or National ID or Part of Name to Search Record"/>
				<input type="submit" value="Search" style="padding:10px;" autocomplete="off">
                </form>
				</div>
                </div>
</div>

<div class="row" style="margin-bottom:10px;">
                <div class="col-xs-3" style="margin:0; padding:0;">
                <div class="optionimg">
                <a href="PrintRecord.php" title="Print Level Record and All Student Information" style="display:block; text-decoration:none; color:blue; font-weight:bold; margin:0 auto;" class="padding10 centertext"> <img class="img-responsive imagecenter" src="systemimages/Student.png" />Print Record</a>
                </div>
                </div>
                <div class="col-xs-3" style="margin:0; padding:0;">
                <div class="optionimg">
                <a href="StudentEntry.php" title="To Register New Student" style="display:block; text-decoration:none; color:blue; font-weight:bold; margin:0 auto;" class="padding10 centertext"> <img class="img-responsive imagecenter" src="systemimages/Student.png" />Register Student</a>
                </div>
                </div>
                <div class="col-xs-3" style="margin:0; padding:0;">
                <div class="optionimg">
                <a href="CurriculumEntry.php" title="You can Register New Curriculum" style="display:block; text-decoration:none; color:blue; font-weight:bold; margin:0 auto;" class="padding10 centertext"> <img class="img-responsive imagecenter" src="systemimages/Student.png" />Register Curriculum</a>
                </div>
                </div>

                <div class="col-xs-3" style="margin:0; padding:0;">
                <div class="optionimg">
                <a href="logout.php" title="To Register New Student" style="display:block; text-decoration:none; color:blue; font-weight:bold; margin:0 auto;" class="padding10 centertext"> <img class="img-responsive imagecenter" src="systemimages/Student.png" />Logout</a>
                </div>
                </div>
                </div>
</div>



<!-- Footer -->
<?php require('footer.php'); ?>

</div>
</body>
</html>
