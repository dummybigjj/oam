<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}


if (isset($_POST['changemypass'])) {
	
	$errors = array();
	
	$oldpass = mysql_real_escape_string($_POST['oldpass']);
	$newpass = mysql_real_escape_string($_POST['newpass']);
	$connewpass = mysql_real_escape_string($_POST['connewpass']);
	
		//..........
		if(mysql_num_rows(mysql_query("select * from users where email = '$emaillogin' and password = '$oldpass'")) != 1) {
			$errors[] = 'Current password is wrong'; 
		}
				
		//..........
		if(empty($newpass)) {
			$errors[] = 'Please enter new password.'; 
		} else {
			if(!preg_match('/^[a-zA-Z0-9]{8,20}$/', $newpass)) {
				$errors[] = 'New Password should be digits or alphabets of min 8 and max 20 char';
			}
		}
				
		//..........
		if($newpass != $connewpass) {
			$errors[] = 'New password and Confirm Password should be same';
		}
		
		$errors = array_filter($errors, 'strlen');
		if(empty($errors)){ 
			$isenter = mysql_query("update users set password = '$newpass' where email = '$emaillogin'");
			if($isenter) {
				do_alert("Infomration Saved");
				nextpage("index.php");
				exit;
			} else {
				do_alert("There is some issue in saving the information, contact developer");
				nextpage("index.php");
				exit;
			}
		} 
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>

	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 

<!-- All Bottom of the Header -->   
<div class="width1200" style="margin-top:60px;">
<div class="row" style="margin-bottom:30px;">
				
                <div class="col-sm-12" style="margin:0; padding:0; margin:0 auto; text-align:center;">
                <div style="padding:0 4px;">
				
                <img src="img/logo.png" />
				</div>
                </div>
</div>

<div class="row" style="margin-bottom:10px;">
                <div class="col-md-12" style="margin:0; padding:0;">
                	<div style="width:500px; margin:0 auto; background-color:#fff; padding:20px; border:2px solid #CCCCCC;">
                 <?php 
				if(isset($errors))
				{
					echo '<div style="color:red; font-weight:normal;">';
				foreach ($errors as $msg) 
				{ ?>
                    <?php echo "$msg<br />\n"; ?>
				<?php }
					echo '</div>';
				}
				?>
                	<form action="<?php echo htmlspecialchars(basename($_SERVER['PHP_SELF'])); ?>" method="post" name="changemypassform">
				
               <div class="form-group">
					 <label for="oldpass"><?php echo 'Old Password'; ?></label>
                     
                     <input type="password" class="form-control" name="oldpass" id="oldpass" required="required" value="" placeholder="<?php echo 'Old Password'; ?>"/>
                     
				</div>
                
                <div class="form-group">
					 <label for="newpass"><?php echo 'New Password'; ?></label>
                     
                     <input type="password" class="form-control" name="newpass" id="newpass" required="required" value="" placeholder="<?php echo 'New Password'; ?>"/>
                     
				</div>
                
                <div class="form-group">
					 <label for="connewpass"><?php echo 'Confirm New Password'; ?></label>
                     
                     <input type="password" class="form-control" name="connewpass" id="connewpass" required="required" value="" placeholder="<?php echo 'Confirm New Password'; ?>"/>
                     
                      
				</div>
                
                <button type="submit" class="btn btn-default success" name="changemypass"><?php echo 'Change My Password'; ?></button>

			</form>
            		</div>
                </div>
                </div>

</div> 



<!-- Footer -->
<div>
<nav class="navbar-inverse navbar-default navbar-fixed-bottom"  role="navigation" style="background-color:#16212D; border-top:2px solid #FFFFFF; height:36px; color:#fff;">
        <div class="width1200">
            <div class="navbar-header" style="padding-left:10px;">
            <h5>Copyright &copy; THIEP. All Rights Reserved</h5>
            </div>
            
            <div class="navbar-header navbar-right" style="padding-right:10px;">
                <h5>Made by <a href="http://www.fedri.com" target="_blank">Fedri</a></h5>

            </div>
        </div>
    </nav>
</div>

</div>
</body>
</html>
