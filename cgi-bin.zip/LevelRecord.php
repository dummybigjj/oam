<?php
session_start();
require('includes/allincludes.php');
//http://localhost:8012/thiepapp/CourseRecord.php?need=enter&curr=1&level=12&major=12&batchid=14&courid=20

if( count($_GET) < 4 ) {
	header("location: index.php");
	exit;
} else {
	$curr_id = mysql_real_escape_string($_GET['curr']);
	$major_id = mysql_real_escape_string($_GET['major']);
	$batch_year_id = mysql_real_escape_string($_GET['batchid']);
	$level_no = mysql_real_escape_string($_GET['level']);
	
	$allstu_query = mysql_query("select * from students where curr_id = '$curr_id' and major_id = '$major_id' and batch_year_id = '$batch_year_id' and is_active = 'Yes'");
	
	if(mysql_num_rows($allstu_query) < 1) {
		do_alert("No student registered yet or information doesn't exist");
		nextpage("index.php");
		exit;
	}
	
	$allcoursesquery = mysql_query("select * from courses where curr_id = '$curr_id' and level_no = '$level_no' and major_id = '$major_id'");
	if(mysql_num_rows($allcoursesquery) < 1){
		header("location: index.php");
		exit;
	} else {
		$totalcourse = mysql_num_rows($allcoursesquery);
	}
	
	/*$allmarksquery = mysql_query("select * from marks where course_ref_no = '$course_ref_no' and level_no = '$level_no' and curr_id = '$curr_id' and major_id = '$major_id' and batch_year_id = '$batch_year_id' and is_fresh = 'Yes'");
	
	if(mysql_num_rows($allmarksquery) < 1){
		do_alert("No marks enter until now");
		nextpage("index.php");
		exit;
	}*/
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>
  
	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 
<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:10px;">
				
                <div class="col-xs-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
                <h4><?php echo $glomajor[$major_id]; ?></h4><h5><?php echo 'Batch: '.batch_name_from_id($batch_year_id).', '.$curr5lvls[$level_no].', Level Record'; ?></h5>
				</div>
                </div>
</div>


				 
<div class="row" style="margin-bottom:40px;">
                <div class="col-xs-12" style="margin:0; padding:0;">				 

				
				<div style="margin-bottom:10px;">
				
				

<table class="tg">
  <tr>
    <th class="tg-i9x5">#</th>
    <th class="tg-i9x5">Student Info</th>
    <th class="tg-i9x5">Course</th>
    <th class="tg-i9x5">Code</th>
    <th class="tg-i9x5">NG</th>
    <th class="tg-i9x5">LG</th>
  </tr>
  
   <?php 
   $i = 1; 
   while($allstudents = mysql_fetch_assoc($allstu_query)) {  
	$reg_id = $allstudents['reg_id'];
	?>
  <tr>
  
    <td class="tg-yw4l" rowspan="<?php echo $totalcourse; ?>"><?php echo $i; ?></td>
    <td class="tg-yw4l" rowspan="<?php echo $totalcourse; ?>" style="text-align:left;">
    <?php echo $allstudents['english_name'];?> <br />
    <?php echo 'National ID: <a href="StudentProfile.php?regid='.$allstudents['reg_id'].'">'.$allstudents['national_id'].'</a>'; ?> <br />
    <?php echo 'Nationality: '.$country_list[$allstudents['nationality']];?> <br />
    </td>
    <?php 
	$coursesquery = mysql_query("select * from courses where curr_id = '$curr_id' and level_no = '$level_no' and major_id = '$major_id'");
	while($allcourses = mysql_fetch_assoc($coursesquery)) {  
	      echo '<td style="text-align:left;" class="tg-yw4l">'.$allcourses['course_name'].'</td>'; ?>
    <?php echo '<td style="text-align:left;" class="tg-yw4l">'.$allcourses['course_code'].'</td>'; 
	$stu_mar = mysql_fetch_array(mysql_query("select num_grade, let_grade from marks where reg_id = '$reg_id' and course_ref_no = '".$allcourses['course_ref_no']."' and level_no = '$level_no' and curr_id = '$curr_id' and major_id = '$major_id' and is_fresh = 'Yes'"));		 
	
	echo '<td class="tg-yw4l">'.$stu_mar[0].'</td>'; 
	
	if(empty($stu_mar[1])) { 
		echo '<td class="tg-yw4l"> <a href="MarksEntry.php?regid='.$allstudents['reg_id'].'&courseid='.$allcourses['course_ref_no'].'&levelid='.$level_no.'">Enter Marks</a> </td>'; 
		} else {
			echo '<td class="tg-yw4l">'.$stu_mar[1].'</td>'; 
		}
	 echo '</tr><tr>'; ?>
    <?php } 
	echo '</tr>';
	$i++;
	} ?>
  </table>
					 
                </div>
               
				
 <div class="col-xs-4" style="margin:0; padding:0;">
 <div style="margin-bottom:10px;">
 <table class="tg" style="margin:0; padding:0;">
  <tr>
    <th class="tg-i9x5" colspan="2">Legends</th>
    <th class="tg-i9x5">Max Marks</th>
  </tr>
  <tr>
    <td class="tg-yw4l">NG</td>
    <td class="tg-yw4l" style="text-align:left;">Numerical Grade</td>
    <td class="tg-yw4l">100</td>
  </tr>
   <tr>
    <td class="tg-yw4l">LG</td>
    <td class="tg-yw4l" style="text-align:left;">Letter Grade</td>
    <td class="tg-yw4l">A+</td>
  </tr>
</table>
</div>
 </div>

			   </div> 
                
                
				</div>


</div> 


<!-- Footer -->
<?php require('footer.php'); ?> 

</div>
</body>
</html>
