<?php
session_start();
require('includes/allincludes.php');
if($loginas != 'faculty') {
	header("Location:logout.php");
	exit; 
}
//print_r($allvar);
//http://localhost:8012/thiepapp/SearchStudents.php?stuneed=1000004
//http://localhost:8012/thiepapp/SearchStudents.php?curr=1&major=12&batchid=14


	
	if(!$_GET)
	{
		header("location: index.php");
		exit;
	} else {
		if (isset($_GET['stuneed'])) {
			$indexinfo = mysql_real_escape_string(strtoupper($_GET['stuneed']));
		}
	
			

		if (isset($_GET['major']) && isset($_GET['batchid'])) {	
			$curr_id = mysql_real_escape_string($_GET['curr']);	
			$major_id = mysql_real_escape_string($_GET['major']);
			$batch_year_id = mysql_real_escape_string($_GET['batchid']);		
		}
		
			
		if(!empty($indexinfo)){
			$allinfoquery = mysql_query("SELECT * FROM students WHERE ( (reg_id LIKE '%$indexinfo%') OR (national_id LIKE '%$indexinfo%') OR (mobile LIKE '%$indexinfo%') OR (UPPER(english_name) LIKE '%$indexinfo%') and (is_active != 'Deleted') )") or die(mysql_error());
			
			if(mysql_num_rows($allinfoquery) <  1) {
				do_alert("There is no record exist for your search query. Please search again");
				nextpage("index.php");
				exit;
			} 
			
		} 
		
		
		else if (!empty($curr_id) || !empty($major_id) || !empty($batch_year_id)) {
			
			if(!empty($curr_id)) {
				$curr_string = "curr_id = $curr_id AND";
			}
			/**
			if(!empty($major_id)) {
				$maj_string = "major_id = $major_id AND";
			}
			$allinfoquery = mysql_query("SELECT * from students WHERE $curr_string $maj_string batch_year_id = $batch_year_id AND is_active != 'Deleted'");

			**/

			$allinfoquery = mysql_query("SELECT * from students WHERE $curr_string AND batch_year_id = $batch_year_id AND is_active != 'Deleted'");
			
			if(mysql_num_rows($allinfoquery) <  1) {
				do_alert("There is no record exist for your search query. Please search again");
				nextpage("PrintRecord.php");
				exit;
			} 
		} 
		
		else {
			header("location: index.php");
			exit;
		}
	}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Students Record Book</title>
  
	<!-- HEAD ATTACHMENTS STARTS -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<!--link rel="stylesheet/less" href="less/bootstrap.less" type="text/css" /-->
	<!--link rel="stylesheet/less" href="less/responsive.less" type="text/css" /-->
	<!--script src="js/less-1.3.3.min.js"></script-->
	<!--append ‘#!watch’ to the brow clearfixser URL, then refresh the page. -->
	
	<link href="css/bootstrap-ltr.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

  	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
  	<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
  	<![endif]-->

 	<!-- Fav and touch icons -->
  	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
 	<link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  	<link rel="shortcut icon" href="img/favicon.png">
    
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
<script>
function selectElementContents(el) {
    var body = document.body, range, sel;
    if (document.createRange && window.getSelection) {
        range = document.createRange();
        sel = window.getSelection();
        sel.removeAllRanges();
        try {
            range.selectNodeContents(el);
            sel.addRange(range);
        } catch (e) {
            range.selectNode(el);
            sel.addRange(range);
        }
    } else if (body.createTextRange) {
        range = body.createTextRange();
        range.moveToElementText(el);
        range.select();
    }
}
</script>
	
</head>

<body>
<div class="container-fluid">
<!-- NAVBAR HEADER -->  
<?php require('menu.php'); ?> 

<!-- All Bottom of the Header -->   
<div class="width1200">
<div class="row" style="margin-bottom:10px;">
				
                <div class="col-xs-12" style="margin:0; padding:0;">
                <div class="boxback titlebox">
				<?php 
				if(!empty($indexinfo)) { ?>
                <h4>Student Information</h4>
				<?php } else  { ?>
                <h4>Students Record</h4><h5><?php echo 'Batch: '.batch_name_from_id($batch_year_id); ?><br /><?php if(!empty($major_id)) { echo 'Major: '.$glomajor[$major_id]; } ?></h5>
                <?php } ?>
				</div>
                </div>
</div>


				 
<div class="row" style="margin-bottom:40px;">
                <div class="col-xs-12" style="margin:0; padding:0;">				 

	<input type="button" value="Select Table"
   onclick="selectElementContents( document.getElementById('table') );">			

   <div  style="margin:10px 0;">						
<table id="table" class="tg">
  <tr>
    <th class="tg-i9x5">#</th>
	<th class="tg-i9x5">Reg. No.</th>
    <th class="tg-i9x5">English Name</th>
    <th class="tg-i9x5">Arabic Name</th>
	<th class="tg-i9x5" style="width:130px;">Nationality</th>
	<th class="tg-i9x5" style="width:130px;">National ID</th>
	<!--
	<th class="tg-i9x5" style="width:130px;">Place of Issue</th>

	<th class="tg-i9x5" style="width:130px;">Date of Expires</th>
	<th class="tg-i9x5" style="width:130px;">Date of Birth</th>-->
    <th class="tg-i9x5" style="width:130px;">Mobile</th>
    <!-- <th class="tg-i9x5">Email</th>-->
    <!-- <th class="tg-i9x5" style="width:130px;">City</th>-->
	<th class="tg-i9x5" style="width:130px;">Batch</th>
	<th class="tg-i9x5">Major</th>
	<th class="tg-i9x5">Status</th>
	<th class="tg-i9x5">Edit</th>
	</tr>
  
  <?php 
  $i = 1;
  while($allinfo = mysql_fetch_assoc($allinfoquery)) { ?>
  
   <tr>
    <td class="tg-yw4l"><?php echo $i; ?></td>
	<td class="tg-yw4l" style="text-align:left;"><?php echo $allinfo['reg_id']; ?></td>
    <td class="tg-yw4l" style="text-align:left;"><?php echo $allinfo['english_name']; ?></td>
    <td class="tg-yw4l"><?php echo $allinfo['arabic_name']; ?></td>
    <td class="tg-yw4l"><?php echo $country_list[$allinfo['nationality']]; ?></td>
    <td class="tg-yw4l"><?php echo '<a href="StudentProfile.php?regid='.$allinfo['reg_id'].'">'.$allinfo['national_id'].'</a>'; ?></td>
    <!--<td class="tg-yw4l"><?php echo $allinfo['place_issue']; ?></td>
    <td class="tg-yw4l"><?php echo $allinfo['date_issue']; ?></td>
    <td class="tg-yw4l"><?php echo $allinfo['student_dob']; ?></td>-->
    <td class="tg-yw4l"><?php echo $allinfo['mobile']; ?></td>
    <!--	<td class="tg-yw4l"><?php echo $allinfo['email']; ?></td> 
	<td class="tg-yw4l"><?php echo $city_list[$allinfo['city']]; ?></td>-->
	<td class="tg-yw4l"><?php echo batch_name_from_id($allinfo['batch_year_id']); ?></td>
	<td class="tg-yw4l"><?php echo $glomajor[$allinfo['major_id']]; ?></td>
	<td class="tg-yw4l"><?php if($allinfo['is_active'] == 'Yes' ) {echo "Active";} else { echo $allinfo['is_active']; } ?></td>
	<td class="tg-yw4l"> <a href="<?php echo 'StudentProfileEdit.php?regid='.$allinfo['reg_id']; ?>"> Edit </a></td>
  </tr>

  <?php $i++; } ?>
  
  
  </table>				 
  </div>

			   </div> 
                
                
				</div>


</div> 


<!-- Footer -->
<?php require('footer.php'); ?> 

</div>
</body>
</html>
